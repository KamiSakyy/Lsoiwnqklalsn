#include <jni.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static pthread_mutex_t g_mutex = PTHREAD_MUTEX_INITIALIZER;
static volatile int g_counter = 0;

static const char *const PROTECTED_PATHS[] = {
    "/system/bin/su",
    "/system/xbin/su",
    "/sbin/su",
    "/data/local/tmp/frida-server",
    "/tame/stmtus/tmp"
};

static int check_tracer(void) {
    int fd = open("/proc/self/status", O_RDONLY);
    if (fd < 0) return 0;
    char buf[1024];
    ssize_t len = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (len <= 0) return 0;
    buf[len] = '\0';
    const char *tracer = strstr(buf, "TracerPid:");
    if (!tracer) return 0;
    return atoi(tracer + 10) != 0;
}

static jboolean native_check(JNIEnv *env, jclass clazz) {
    (void)env;
    (void)clazz;
    for (size_t i = 0; i < sizeof(PROTECTED_PATHS) / sizeof(PROTECTED_PATHS[0]); ++i) {
        struct stat st;
        if (stat(PROTECTED_PATHS[i], &st) == 0) return JNI_FALSE;
    }
    return check_tracer() ? JNI_FALSE : JNI_TRUE;
}

static const JNINativeMethod METHODS[] = {
    {"c", "()Z", (void *)native_check}
};

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void)reserved;
    JNIEnv *env = NULL;
    if ((*vm)->GetEnv(vm, (void **)&env, JNI_VERSION_1_6) != JNI_OK) {
        return JNI_VERSION_1_6;
    }
    jclass cls = (*env)->FindClass(env, "com/tsuyu/line/NativeChecks");
    if (cls != NULL) {
        (*env)->RegisterNatives(env, cls, METHODS, sizeof(METHODS) / sizeof(METHODS[0]));
        (*env)->DeleteLocalRef(env, cls);
    }
    pthread_mutex_lock(&g_mutex);
    g_counter++;
    pthread_mutex_unlock(&g_mutex);
    return JNI_VERSION_1_6;
}
