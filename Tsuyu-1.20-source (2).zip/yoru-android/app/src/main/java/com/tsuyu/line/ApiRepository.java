package com.tsuyu.line;

import android.content.Context;
import android.net.Uri;
import android.text.Html;
import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import java.time.*;

public final class ApiRepository {
    private static final String CHROME="Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36";
    private static final String ANIX_UA="Anixart/8.5.2 (Android 13; Pixel 7)";
    private static final String[] ANIX_BASES={"https://api-s.anixsekai.com","https://api.anixsekai.com"};
    private static final String[] SHIKI_GRAPH={"https://shikimori.io/api/graphql","https://shikimori.one/api/graphql","https://shikimori.me/api/graphql"};
    private static final String[] SHIKI_REST={"https://shikimori.io","https://shikimori.one","https://shikimori.me"};
    private static final String ANILIST_GRAPH="https://graphql.anilist.co";
    private static final String ANI_FIELDS = AniListApi.ANI_FIELDS;
    public static final LinkedHashMap<String,String> sourceNames=new LinkedHashMap<>();
    private static final String[] REAL_SOURCES={"yummy","anilibria","animevost","animelib","animedia","animetka","shikimori"};
    static {
        sourceNames.put("all","Все источники");
        sourceNames.put("yoru","Yoru");
        sourceNames.put("yummy","YummyAnime");
        sourceNames.put("anilibria","AniLibria");
        sourceNames.put("animevost","AnimeVost");
        sourceNames.put("animelib","AniLib");
        sourceNames.put("animelib4k","AniLib 4K");
        sourceNames.put("animedia","AniMedia");
        sourceNames.put("animetka","Animetka");
        sourceNames.put("anidub","AniDUB");
        sourceNames.put("shikimori","Shikimori");
        sourceNames.put("anilist","AniList");
        sourceNames.put("kodik","Kodik");
        sourceNames.put("anixsekai","AnixSekai");
        sourceNames.put("hanime","Hanime");
        if(HentaiEngine.isHenta())sourceNames.put("henta","Hentai");
    }
    public static final String[] VOICE_PREF_VALUES={"","AniDUB","AniLibria.TV","AniMaunt","AnimeVost","AniStar & DEEP","Beyond:Studio","Dream Cast","AniMedia","StudioBand","JAM","SHIZA Project","AniRise","AniStar","DEEP","AniFilm","AniPlay","Animedia","Amazing Dubbing","AniMaunt Team","AniLibria Online","Anilibria","AniDub Online","AniDUB Online","SHIZA","JAM Club","Kansai","AniJoy","AniUtopia","AniPlague","AniMedia Online","NewStation","OnWave","Crunchyroll","Wakanim","Netflix","TVShows","Flarrow Films","Freedub Studio","AniMaat","AnimeVibes","DubClub","Persona99","Reanimedia","MC Entertainment","2x2","СТС","Куба77","Cuba77","Студийная Банда","Anything Group","White Media","СВ-Дубль","AniFilm UA","FanVoxUA","Bamboo Anime","InariOkami","Glass Building","Колонія","DniproFilm","HDrezka Studio","AniLibria.TV + Sub","AniDUB + Sub","AniLame","AniMaunt Dub","AniPlay Dub","AniRise Dub","AniJoy Dub","AniUtopia Dub","AniFilm Dub","SHIZA Dub","JAM Dub","Kansai Dub","NewStation Dub","OnWave Dub","AniSerials","AniMedia Dub","Animaunt UA","Amanogawa","Amber Studio","Anything Group Dub","SHIZA Project Sub","AniBaza","AniBoom","AniCosmic","AniFamily","AniFate","AniGalaxy","AniLords","AniMagic","AniMur","AniNova","AniPanda","AniVerse","AniWave Dub","AniZone","AniZona","AniStar Online","AniDub Classics","AniLibria Classics","AniFilm Classics","AniPlay Online"};
    public static final String[] VOICE_PREF_NAMES={"Авто","AniDUB","AniLibria.TV","AniMaunt","AnimeVost","AniStar & DEEP","Beyond:Studio","Dream Cast","AniMedia","StudioBand","JAM","SHIZA Project","AniRise","AniStar","DEEP","AniFilm","AniPlay","Animedia","Amazing Dubbing","AniMaunt Team","AniLibria Online","Anilibria","AniDub Online","AniDUB Online","SHIZA","JAM Club","Kansai","AniJoy","AniUtopia","AniPlague","AniMedia Online","NewStation","OnWave","Crunchyroll","Wakanim","Netflix","TVShows","Flarrow Films","Freedub Studio","AniMaat","AnimeVibes","DubClub","Persona99","Reanimedia","MC Entertainment","2x2","СТС","Куба77","Cuba77","Студийная Банда","Anything Group","White Media","СВ-Дубль","AniFilm UA","FanVoxUA","Bamboo Anime","InariOkami","Glass Building","Колонія","DniproFilm","HDrezka Studio","AniLibria.TV + Sub","AniDUB + Sub","AniLame","AniMaunt Dub","AniPlay Dub","AniRise Dub","AniJoy Dub","AniUtopia Dub","AniFilm Dub","SHIZA Dub","JAM Dub","Kansai Dub","NewStation Dub","OnWave Dub","AniSerials","AniMedia Dub","Animaunt UA","Amanogawa","Amber Studio","Anything Group Dub","SHIZA Project Sub","AniBaza","AniBoom","AniCosmic","AniFamily","AniFate","AniGalaxy","AniLords","AniMagic","AniMur","AniNova","AniPanda","AniVerse","AniWave Dub","AniZone","AniZona","AniStar Online","AniDub Classics","AniLibria Classics","AniFilm Classics","AniPlay Online"};
    private static boolean routeLabel(String value){
        String v=value==null?"":value.toLowerCase(Locale.ROOT).replace('ё','е').trim();
        return v.contains("yoru")||v.contains("yummy")||v.contains("yani")||v.contains("kodik")||v.contains("aniqit")||v.contains("cdnvideohub")||v.contains("anix")||v.contains("sekai")||v.contains("sibnet")||v.contains("stormo")||v.contains("aksor")||v.contains("alloha")||v.contains("zedfilm")||v.contains("hlamer")||v.contains("rutube")||v.equals("vk")||v.contains("vkvideo")||v.equals("player")||v.equals("iframe")||v.equals("плеер")||v.equals("вариант")||v.equals("оригинал")||v.equals("original")||v.equals("tsuyu")||v.equals("animetka")||v.replace(" ","").contains("anilib")||v.equals("hanime")||v.equals("hentai")||v.equals("henta")||v.equals("shikimori")||v.equals("source")||v.equals("источник");
    }
    public static String sourceVoice(String source){String s=source==null?"":source.toLowerCase(Locale.ROOT);if(s.contains("anilibria")||s.contains("aniliberty")||s.contains("cdnlibs"))return "AniLibria.TV";if(s.contains("animevost"))return "AnimeVost";if(s.contains("anidub"))return "AniDUB";if(s.contains("animedia"))return "AniMedia";return "";}
    public static String voiceKey(String value){String v=fixText(value==null?"":value).toLowerCase(Locale.ROOT).replace('ё','е').trim();v=v.replaceFirst("\\s*[·|]\\s*(?:вариант|variant)\\s*[0-9]+\\s*$","").trim();v=v.replace("анилибрия","anilibria").replace("анилиберт","aniliberty").replace("анимаунт","animaunt").replace("анимевост","animevost").replace("анимедиа","animedia").replace("субтитры","subtitles").replace("сабы","subtitles");if(genericVoiceLabel(v))return "";if(v.contains("anilibria")||v.contains("aniliberty")||v.contains("cdnlibs")){if(v.contains("classic"))return "anilibria-classic";if(v.contains("dub"))return "anilibria-dub";if(v.contains("hd")||v.contains("hiq"))return "anilibria-hd";return "anilibria";}if(v.contains("animaunt")||v.contains("ani maunt"))return "animaunt";if(v.contains("anirise")||v.contains("ani rise"))return "anirise";if(v.contains("anifilm")||v.contains("ani film"))return "anifilm";if(v.contains("aniplay")||v.contains("ani play"))return "aniplay";if(v.contains("amazing")&&v.contains("dubbing"))return "amazing-dubbing";if(v.contains("animevost")||v.contains("anime vost"))return "animevost";if(v.contains("anirise")||v.contains("ani rise"))return "anirise";if(v.contains("anifilm")||v.contains("ani film"))return "anifilm";if(v.contains("aniplay")||v.contains("ani play"))return "aniplay";if(v.contains("amazing")&&v.contains("dubbing"))return "amazing-dubbing";if(v.contains("newstation")||v.contains("new station"))return "newstation";if(v.contains("onwave")||v.contains("on wave"))return "onwave";if(v.contains("anistar")&&v.contains("deep"))return "anistar-deep";if(v.contains("beyond")&&v.contains("studio"))return "beyond-studio";if(v.contains("dream")&&v.contains("cast"))return "dreamcast";if(v.contains("anidub")||v.contains("ani dub"))return "anidub";if(v.contains("animedia")||v.contains("ani media"))return "animedia";if(v.contains("studioband")||v.contains("studio band"))return "studio-band";if(v.matches(".*\bjam\b.*"))return "jam";if(v.contains("kansai"))return "kansai";if(v.contains("newstation")||v.contains("new station"))return "newstation";if(v.contains("onwave")||v.contains("on wave"))return "onwave";if(v.contains("crunchyroll"))return "crunchyroll";if(v.contains("wakanim"))return "wakanim";if(v.contains("netflix"))return "netflix";if(v.contains("shiza"))return "shiza";if(v.contains("subtitles")||v.contains("subtitle")||v.contains("sub ")||v.contains(" subs")||v.contains("суб"))return "subtitles";if(routeLabel(v))return "";String plain=plainName(v);if(plain.isEmpty()||plain.equals("auto")||plain.equals("avto")||plain.equals("ozvuchka")||plain.equals("perevod"))return "";return plain.replaceAll("\\s+","");}
    public static String voiceSaveKey(Anime.Variant v){return variantVoiceLabel(v);}
    public static String voiceTitle(String value){value=fixText(value);if(value==null||value.trim().isEmpty())return "";String trimmed=value.trim();if(trimmed.startsWith("src:")){String src=trimmed.substring(4).trim();if(src.isEmpty())return "";String cleaned=cleanLabel(src);if(!cleaned.isEmpty()&&!routeLabel(cleaned))return cleaned;return ""; }String key=voiceKey(value);if(key.equals("anilibria-classic"))return "AniLibria Classic";if(key.equals("anilibria-dub"))return "AniLibria Dub";if(key.equals("anilibria-hd"))return "AniLibria HD";if(key.equals("anilibria"))return "AniLibria.TV";if(key.equals("animaunt"))return "AniMaunt";if(key.equals("anirise"))return "AniRise";if(key.equals("anifilm"))return "AniFilm";if(key.equals("aniplay"))return "AniPlay";if(key.equals("amazing-dubbing"))return "Amazing Dubbing";if(key.equals("animevost"))return "AnimeVost";if(key.equals("anirise"))return "AniRise";if(key.equals("anifilm"))return "AniFilm";if(key.equals("aniplay"))return "AniPlay";if(key.equals("amazing-dubbing"))return "Amazing Dubbing";if(key.equals("newstation"))return "NewStation";if(key.equals("onwave"))return "OnWave";if(key.equals("anistar-deep"))return "AniStar & DEEP";if(key.equals("beyond-studio"))return "Beyond:Studio";if(key.equals("dreamcast"))return "Dream Cast";if(key.equals("anidub"))return "AniDUB";if(key.equals("animedia"))return "AniMedia";if(key.equals("studio-band"))return "StudioBand";if(key.equals("jam"))return "JAM";if(key.equals("kansai"))return "Kansai";if(key.equals("newstation"))return "NewStation";if(key.equals("onwave"))return "OnWave";if(key.equals("crunchyroll"))return "Crunchyroll";if(key.equals("wakanim"))return "Wakanim";if(key.equals("netflix"))return "Netflix";if(key.equals("shiza"))return "SHIZA Project";String label=cleanLabel(value);if(label.isEmpty()||routeLabel(label)||genericVoiceLabel(label))return "";label=label.replaceAll("(?i)\\b(player|iframe|hls|dash|mp4|kodik|yummy|yani|aniqit|cdnvideohub|yoru)\\b","").replaceAll("\\s+"," ").trim();return label.isEmpty()?"":label;}
    /** Repairs text that was decoded as ISO-8859-1 instead of UTF-8 by a provider. */
    public static String fixText(String value){
        if(value==null||value.isEmpty())return value==null?"":value;
        String current=value;
        for(int pass=0;pass<2;pass++){
            int before=mojibakeScore(current);
            if(before==0)break;
            boolean latinOnly=true;
            for(int i=0;i<current.length();i++)if(current.charAt(i)>255){latinOnly=false;break;}
            if(!latinOnly)break;
            try{
                String candidate=new String(current.getBytes(StandardCharsets.ISO_8859_1),StandardCharsets.UTF_8);
                if(mojibakeScore(candidate)>=before)break;
                current=candidate;
            }catch(Exception ignored){break;}
        }
        return current;
    }

    private static int mojibakeScore(String value){
        int score=0;
        for(int i=0;i<value.length();i++){
            char c=value.charAt(i);
            if(c=='\u00D0'||c=='\u00D1'||c=='\u00C2'||c=='\u00C3'||c=='\u00E2'||c=='\uFFFD')score++;
        }
        return score;
    }

    public static void normalize(Anime a){
        if(a==null)return;
        a.title=fixText(a.title);a.original=fixText(a.original);a.description=fixText(a.description);a.type=fixText(a.type);a.status=fixText(a.status);a.age=fixText(a.age);a.studio=fixText(a.studio);a.countries=fixText(a.countries);a.cast=fixText(a.cast);a.crew=fixText(a.crew);a.ratings=fixText(a.ratings);a.franchise=fixText(a.franchise);a.airedDate=fixText(a.airedDate);a.nextEpisodeAt=fixText(a.nextEpisodeAt);
        for(int i=0;i<a.genres.size();i++)a.genres.set(i,fixText(a.genres.get(i)));
        for(Anime.Episode e:a.episodeList)normalizeEpisode(e);
    }

    public static void normalizeEpisode(Anime.Episode e){
        if(e==null)return;
        e.name=fixText(e.name);e.airDate=fixText(e.airDate);
        for(Anime.Variant v:e.variants)if(v!=null){v.name=fixText(v.name);v.player=fixText(v.player);v.displayName=fixText(v.displayName);}
    }

    /** Returns only a real dubbing or audio-track name. Provider/player and generic
     * metadata are deliberately not promoted to a voice label. */
    public static String voiceLabel(String value){return actualVoiceLabel(value);}

    public static boolean genericVoiceLabel(String value){
        String v=fixText(value==null?"":value).toLowerCase(Locale.ROOT).replace('ё','е').trim();
        if(v.isEmpty())return true;
        String compact=v.replaceAll("[\\s_\\-\\|,;:·]+"," ").trim();
        if(compact.equals("озвучка")||compact.equals("дорожка озвучки")||compact.equals("аудиодорожка")||compact.equals("аудио дорожка")||compact.equals("audio")||compact.equals("audio track")||compact.equals("track")||compact.equals("default")||compact.equals("main")||compact.equals("дорожка")||compact.equals("вариант")||compact.equals("original")||compact.equals("original audio")||compact.equals("оригинал")||compact.equals("оригинальная дорожка")||compact.equals("перевод")||compact.equals("translation")||compact.equals("dub")||compact.equals("dubbing")||compact.equals("voice")||compact.equals("studio")||compact.equals("language")||compact.equals("role")||compact.equals("commentary")||compact.equals("descriptive")||compact.equals("forced")||compact.equals("unknown")||compact.equals("unk")||compact.equals("none")||compact.equals("null")||compact.equals("n/a")||compact.equals("na")||compact.equals("source")||compact.equals("provider")||compact.equals("player")||compact.equals("host")||compact.equals("server")||compact.equals("источник")||compact.equals("провайдер")||compact.equals("плеер")||compact.equals("сервер")||compact.equals("hearing impaired")||compact.equals("visually impaired")||compact.equals("sign language")||compact.equals("дубляж"))return true;
        if(compact.startsWith("дорожка ")||compact.startsWith("аудиодорожка ")||compact.startsWith("audio track ")||compact.startsWith("track ")||compact.startsWith("audio ")||compact.startsWith("voice ")||compact.startsWith("dubbing ")||compact.startsWith("translation ")||compact.startsWith("commentary ")||compact.startsWith("descriptive ")||compact.startsWith("default ")||compact.startsWith("main ")||compact.startsWith("source ")||compact.startsWith("provider ")||compact.startsWith("player ")||compact.startsWith("host ")||compact.startsWith("server ")||compact.startsWith("источник ")||compact.startsWith("провайдер ")||compact.startsWith("плеер ")||compact.startsWith("аудио "))return true;
        if(compact.matches("(?:audio|track|voice|dub|dubbing|commentary|translation)[0-9]+"))return true;
        if(compact.contains("без озвучки")||compact.contains("без перевода")||compact.contains("без дубляжа")||compact.contains("оригинал")||compact.contains("original"))return true;
        if(compact.contains("субтитр")||compact.contains("subtitle"))return true;
        if(compact.startsWith("перевод ")||compact.startsWith("translation ")||compact.startsWith("translated "))return true;
        if(compact.equals("суб")||compact.equals("sub")||compact.equals("файл")||compact.equals("file")||compact.equals("stereo")||compact.equals("mono")||compact.equals("surround")||compact.equals("commentary")||compact.equals("descriptive")||compact.matches("[0-9]{1,4}(?:[.]?[0-9]+)?")||compact.matches("[0-9]{3,4}p")||compact.matches("[0-9]{3,4} [pi]"))return true;
        if(compact.matches("(?:ru|rus|ru-ru|russian|русский|русская|русское|en|eng|en-us|english|английский|английская|английское|ja|jpn|ja-jp|japanese|японский|японская|японское|zh|zho|zh-cn|chinese|中文|китайский|китайская|ko|kor|ko-kr|korean|한국어|корейский|корейская|de|ger|de-de|german|немецкий|немецкая|fr|fre|fra|fr-fr|french|французский|французская|es|spa|es-es|spanish|испанский|испанская|it|ita|it-it|italian|итальянский|итальянская|pt|por|pt-pt|portuguese|португальский|португальская|pl|pol|pl-pl|polish|польский|польская|uk|ukr|uk-ua|ukrainian|украинский|украинская|be|bel|belarusian|белорусский|tr|tur|turkish|турецкий|ar|ara|arabic|арабский|hi|hin|hindi|хинди|vi|vie|vietnamese|вьетнамский|th|tha|thai|тайский|id|ind|indonesian|индонезийский|nl|nld|dutch|нидерландский|sv|swe|swedish|шведский|no|nor|norwegian|норвежский|fi|fin|finnish|финский|da|dan|danish|датский|cs|ces|czech|чешский|hu|hun|hungarian|венгерский|ro|ron|romanian|румынский)(?:[ ._()/-].*)?"))return true;
        return compact.equals("und")||compact.equals("unknown language")||compact.equals("язык")||compact.equals("language");
    }

    private static String actualVoiceLabel(String value){
        value=fixText(value);
        if(value==null||value.trim().isEmpty())return "";
        value=value.trim().replaceFirst("\\s*[·|]\\s*(?:вариант|variant)\\s*[0-9]+\\s*$","").trim();
        if(value.isEmpty())return "";
        String title=voiceTitle(value);
        if(!title.isEmpty()&&!genericVoiceLabel(title))return title;
        String label=cleanLabel(value);
        if(label.isEmpty()||routeLabel(label))return "";
        if(genericVoiceLabel(label)){
            for(String part:label.split("[·|,;/()\\[\\]]+")){
                String candidate=part.trim();
                if(candidate.isEmpty()||candidate.equalsIgnoreCase(label))continue;
                String recovered=actualVoiceLabel(candidate);
                if(!recovered.isEmpty())return recovered;
            }
            String lower=label.toLowerCase(Locale.ROOT).replace('ё','е');
            String[] prefixes={"original","original audio","оригинал","аудио","audio","track","дорожка","voice","озвучка","translation","перевод","dubbing","dub","language","язык","ru","rus","russian","русский","русская","en","eng","english","английский","английская","ja","jpn","japanese","японский","японская","zh","zho","chinese","китайский","ko","kor","korean","корейский","de","ger","german","немецкий","fr","fre","fra","french","французский","es","spa","spanish","испанский","it","ita","italian","итальянский","pt","por","portuguese","португальский","pl","pol","polish","польский","uk","ukr","ukrainian","украинский"};
            for(String prefix:prefixes)if(lower.startsWith(prefix+" ")||lower.startsWith(prefix+"-")){String recovered=actualVoiceLabel(label.substring(prefix.length()).trim());if(!recovered.isEmpty())return recovered;}
            return "";
        }
        return label;
    }

    public static String variantVoiceLabel(Anime.Variant variant){
        if(variant==null)return "";
        String label=actualVoiceLabel(variant.name);
        if(!label.isEmpty())return label;
        String display=variant.displayName==null?"":variant.displayName.trim();
        if(display.isEmpty())return "";
        String player=cleanLabel(variant.player);
        for(String part:display.split("\\s·\\s")){
            String candidate=part.trim();
            if(candidate.isEmpty()||(!player.isEmpty()&&candidate.equalsIgnoreCase(player)))continue;
            candidate=actualVoiceLabel(candidate);
            if(!candidate.isEmpty())return candidate;
        }
        return "";
    }

    public static boolean voiceMatches(String wanted,String actual){String rawWanted=fixText(wanted==null?"":wanted).trim();if(rawWanted.isEmpty())return true;String w=voiceKey(rawWanted);if(w.isEmpty())return false;String a=voiceKey(actual);if(w.equals(a))return true;String wt=plainName(rawWanted),at=plainName(actual);return !wt.isEmpty()&&!at.isEmpty()&&!routeLabel(actual)&&(at.contains(wt)||wt.contains(at));}
    private static final ZoneId MSK_ZONE=ZoneId.of("Europe/Moscow");
    private static final String SH_FIELDS = ShikimoriApi.SH_FIELDS + " studios{name}";
    public static final String[][] SHIKI_GENRE_ROWS={{"" ,"Все жанры"},{"1","Экшен"},{"2","Приключения"},{"3","Машины"},{"4","Комедия"},{"5","Безумие"},{"6","Демоны"},{"7","Детектив"},{"8","Драма"},{"9","Этти"},{"10","Фэнтези"},{"11","Игры"},{"12","Хентай"},{"13","Историческое"},{"14","Ужасы"},{"15","Детское"},{"16","Магия"},{"17","Боевые искусства"},{"18","Меха"},{"19","Музыка"},{"20","Пародия"},{"21","Самураи"},{"22","Романтика"},{"23","Школа"},{"24","Фантастика"},{"25","Сёдзё"},{"26","Сёдзё-ай"},{"27","Сёнен"},{"28","Сёнен-ай"},{"29","Космос"},{"30","Спорт"},{"31","Супер сила"},{"32","Вампиры"},{"33","Яой"},{"34","Юри"},{"35","Гарем"},{"36","Повседневность"},{"37","Сверхъестественное"},{"38","Военное"},{"39","Полиция"},{"40","Психологическое"},{"41","Триллер"},{"42","Сэйнэн"},{"43","Дзёсей"},{"539","Эротика"},{"541","Работа"},{"543","Гурман"}};
    public static String shikiGenreId(String name){String n=name==null?"":name.trim().toLowerCase(Locale.ROOT);if(n.isEmpty())return "";for(String[] row:SHIKI_GENRE_ROWS)if(!row[0].isEmpty()&&row[1].toLowerCase(Locale.ROOT).equals(n))return row[0];for(String[] row:SHIKI_GENRE_ROWS)if(!row[0].isEmpty()&&(row[1].toLowerCase(Locale.ROOT).contains(n)||n.contains(row[1].toLowerCase(Locale.ROOT))))return row[0];return "";}
    private static final long DAY_MS=24L*60*60*1000;
    private final Context context;
    private final ConcurrentHashMap<String,Anime> known=new ConcurrentHashMap<>();
    private final YoruShield shield;
    private final ArrayList<Anime> seed=new ArrayList<>();
    private final java.util.concurrent.ConcurrentHashMap<String,Long> counts=new java.util.concurrent.ConcurrentHashMap<>();
    private volatile boolean bootLoaded;
    private static final class YoruChoice {Anime.Variant variant;int quality;TreeMap<Integer,String> streams;YoruChoice(Anime.Variant v,int q,TreeMap<Integer,String> s){variant=v;quality=q;streams=new TreeMap<>(s);}}
    public static final class Filter {public String year="",genre="",type="",status="",sort="RATING_DESC",season="";}
    public static final class AiringItem {public Anime anime;public long time;public int episode;public String kind="",precision="",source="";}
    public static JSONArray airingJson(List<AiringItem> rows){JSONArray arr=new JSONArray();try{if(rows!=null)for(AiringItem item:rows){if(item==null||item.anime==null)continue;arr.put(new JSONObject().put("anime",item.anime.json()).put("time",item.time).put("episode",item.episode).put("kind",item.kind).put("precision",item.precision).put("source",item.source));}}catch(Exception ignored){}return arr;}
    public static ArrayList<AiringItem> airingFromJson(JSONArray arr){ArrayList<AiringItem> out=new ArrayList<>();try{for(int i=0;arr!=null&&i<arr.length()&&i<800;i++){JSONObject j=arr.optJSONObject(i);if(j==null)continue;AiringItem item=new AiringItem();item.anime=Anime.from(j.optJSONObject("anime"));item.time=j.optLong("time");item.episode=j.optInt("episode");item.kind=j.optString("kind");item.precision=j.optString("precision");item.source=j.optString("source");if(Anime.valid(item.anime)&&item.time>0)out.add(item);}}catch(Exception ignored){}return out;}
    public static int todayCount(List<AiringItem> rows){Calendar c=Calendar.getInstance(TimeZone.getTimeZone(MSK_ZONE.getId()));c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);long start=c.getTimeInMillis(),end=start+DAY_MS;int n=0;if(rows!=null)for(AiringItem item:rows)if(item!=null&&item.time>=start&&item.time<end)n++;return n;}
    public ApiRepository(Context c){context=c.getApplicationContext();shield=new YoruShield(context);}
    private synchronized void ensureBoot(){if(bootLoaded)return;bootLoaded=true;try{byte[] raw=readBytes(context.getAssets().open("data.bin"),500*1024);if(raw!=null&&raw.length>0){JSONObject boot=new JSONObject(new String(raw,StandardCharsets.UTF_8));JSONArray rows=boot.optJSONArray("releases");for(int i=0;rows!=null&&i<rows.length();i++){Anime a=Anime.from(rows.getJSONObject(i));a.cached=true;if(a.id.equals("9542"))a.malId=52991;if(a.id.equals("9600"))a.malId=52299;if(a.id.equals("9555"))a.malId=54492;seed.add(a);known.put(a.key(),a);}}}catch(Exception ignored){}counts.put("shikimori",23896L);counts.put("animelib",23818L);counts.put("anilibria",1955L);counts.put("animevost",3566L);counts.put("yummy",10451L);}
    public long countOf(String source){ensureBoot();if("yoru".equals(source))return countOf("all");if("all".equals(source)){long sum=0;for(String s:REAL_SOURCES){Long n=counts.get(s);if(n!=null&&n>0)sum+=n;}return sum>0?sum:-1;}Long n=counts.get(source);return n==null?-1:n;}
    public void clearMemory(){}
    public JSONObject sourceDiagnostics(){JSONObject out=new JSONObject();try{out.put("routes",YoruApp.app().store.sourceSnapshot());out.put("memoryCache",0);out.put("streamCache",0);out.put("known",known.size());out.put("calendarToday",YoruApp.app().calendarTodayCount);}catch(Exception ignored){}return out;}
    public List<Anime> seed(){ensureBoot();return new ArrayList<>(seed);}
    public Anime remember(Anime a){normalize(a);if(Anime.valid(a)){known.put(a.key(),a);if(known.size()>1800){Iterator<String> it=known.keySet().iterator();if(it.hasNext())known.remove(it.next());}}return a;}
    public Anime known(String key){ensureBoot();return known.get(key);}
    public TreeMap<Integer,String> resolveStreams(String input)throws Exception{TaskQueue.check();String key=embed(input);if(key.isEmpty())key=safeUrl(input);if(key.isEmpty())throw new IOException("Просмотр не передал данные");TreeMap<Integer,String> streams=VideoResolver.resolve(this,key);return new TreeMap<>(streams);}
    static byte[] readBytes(InputStream in,int max)throws IOException{try(InputStream input=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=input.read(b))!=-1){TaskQueue.check();if(out.size()+n>max)throw new IOException("Слишком большой ответ");out.write(b,0,n);}return out.toByteArray();}}
    static String readStream(InputStream in,int max)throws IOException{return new String(readBytes(in,max),StandardCharsets.UTF_8);}
    public static String safeUrl(String value){if(value==null||value.trim().isEmpty())return "";value=value.trim().replace(" ","%20").replace("\\/","/").replace("&amp;","&");if(value.startsWith("//"))value="https:"+value;try{Uri u=Uri.parse(value);String h=u.getHost();if(h==null)return "";h=h.toLowerCase(Locale.ROOT);if("http".equals(u.getScheme())&&(h.equals("video.animetop.info")||h.equals("media.animetop.info")||h.equals("static.openni.ru")))u=u.buildUpon().scheme("https").build();String scheme=u.getScheme();if(!("https".equals(scheme)||"http".equals(scheme))||u.getUserInfo()!=null||(!h.contains("."))||h.equals("localhost")||h.endsWith(".local")||h.matches("^(127|10|0|192\\.168|169\\.254)\\..*")||h.matches("^172\\.(1[6-9]|2[0-9]|3[01])\\..*"))return "";return u.toString();}catch(Exception e){return "";}}
    String request(String url,String method,String body,boolean form)throws Exception{return request(url,method,body,form,null);}
    String request(String url,String method,String body,boolean form,Map<String,String> headers)throws Exception{TaskQueue.check();
        Exception last=null;ArrayList<String> attempts=shield.routes(url);for(String start:attempts){TaskQueue.check();try{String text=requestNetwork(start,method,body,form,headers);shield.ok(start);return text;}catch(Exception e){TaskQueue.check();last=e;shield.fail(start);}}
        if(last!=null)throw last;throw new IOException("Каталог не ответил");
    }
    private String requestNetwork(String url,String method,String body,boolean form,Map<String,String> headers)throws Exception{
        if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();if(safeUrl(url).isEmpty())throw new IOException("Недопустимый адрес");
        TaskQueue.check();
        try{return Net.text(url,method,body,form,headers,"application/json,text/html;q=0.9,*/*;q=0.6",CHROME,5000,9000,12*1024*1024);}
        catch(Net.HttpCode e){if(e.code==429)throw new IOException("Каталог временно занят Попробуйте позже");throw new IOException("Каталог сейчас недоступен Попробуйте другой вариант");}
    }
    public void refreshProtection(boolean force){shield.refresh(force);prewarmDns();}
    public void prewarmDns(){
        try{
            ArrayList<String> hosts=new ArrayList<>();
            for(String u:SHIKI_GRAPH){String h=Uri.parse(u).getHost();if(h!=null&&!h.isEmpty()&&!hosts.contains(h))hosts.add(h);}
            for(String u:SHIKI_REST){String h=Uri.parse(u).getHost();if(h!=null&&!h.isEmpty()&&!hosts.contains(h))hosts.add(h);}
            for(String u:ANIX_BASES){String h=Uri.parse(u).getHost();if(h!=null&&!h.isEmpty()&&!hosts.contains(h))hosts.add(h);}
            String anilistHost=Uri.parse(ANILIST_GRAPH).getHost();
            if(anilistHost!=null&&!anilistHost.isEmpty()&&!hosts.contains(anilistHost))hosts.add(anilistHost);
            String[] moreUrls={
                "https://kodik-api.com/get-player",
                "https://anilibria.top/api/v1/anime/catalog/releases",
                "https://api.yani.tv/anime",
                "https://api.cdnlibs.org/api/anime",
                "https://api.animevost.org/v1/search",
                "https://animetka.com/api/anime/top",
                "https://online.anidub.com/"
            };
            for(String u:moreUrls){String h=Uri.parse(u).getHost();if(h!=null&&!h.isEmpty()&&!hosts.contains(h))hosts.add(h);}
            Net.FastDns.prewarm(hosts.toArray(new String[0]));
            Net.prewarmConnections(
                SHIKI_GRAPH[0],
                moreUrls[0],
                moreUrls[1],
                ANIX_BASES[0]
            );
            SourceResolver.prewarm(this);
        }catch(Exception ignored){}
    }
    String document(String u)throws Exception{return request(u,"GET",null,false);}
    String formPage(String u,String body)throws Exception{return request(u,"POST",body,true);}
    JSONObject get(String u)throws Exception{return new JSONObject(request(u,"GET",null,false));}
    private JSONObject postJson(String u,JSONObject j)throws Exception{return new JSONObject(request(u,"POST",j.toString(),false));}
    private JSONObject postForm(String u,String key,String value)throws Exception{return new JSONObject(request(u,"POST",enc(key)+"="+enc(value),true));}
    private static String enc(String s){try{return URLEncoder.encode(s,"UTF-8");}catch(Exception e){return "";}}
    public static String query(String base,Map<String,String> params){StringBuilder s=new StringBuilder(base);for(Map.Entry<String,String> e:params.entrySet()){if(e.getValue()==null||e.getValue().isEmpty())continue;s.append(s.indexOf("?")>=0?'&':'?').append(enc(e.getKey())).append('=').append(enc(e.getValue()));}return s.toString();}
    static LinkedHashMap<String,String> params(String...kv){LinkedHashMap<String,String> p=new LinkedHashMap<>();for(int i=0;i+1<kv.length;i+=2)p.put(kv[i],kv[i+1]);return p;}
    JSONObject shiki(String q)throws Exception{JSONObject body=new JSONObject().put("query",q);Exception last=null;for(String url:SHIKI_GRAPH){try{JSONObject j=new JSONObject(request(url,"POST",body.toString(),false));if(j.has("errors"))throw new IOException("Каталог не ответил на запрос");return j.getJSONObject("data");}catch(Exception e){last=e;}}if(last!=null)throw last;throw new IOException("Каталог не ответил на запрос");}
    String shikiRest(String path)throws Exception{Exception last=null;for(String base:SHIKI_REST){try{return request(base+path,"GET",null,false);}catch(Exception e){last=e;}}if(last!=null)throw last;throw new IOException("Shikimori не ответил");}
    private JSONObject anilist(String q)throws Exception{JSONObject body=new JSONObject().put("query",q);Exception last=null;try{JSONObject j=new JSONObject(request(ANILIST_GRAPH,"POST",body.toString(),false));if(j.has("errors"))throw new IOException("AniList не ответил");return j.getJSONObject("data");}catch(Exception e){last=e;}if(last!=null)throw last;throw new IOException("AniList не ответил");}
    private Anime.Page anilistCatalog(String q,int page)throws Exception{Anime.Page out=new Anime.Page();out.page=page;out.note="AniList";String query="{Page(page:"+Math.max(1,page)+",perPage:12){media(search:"+JSONObject.quote(q==null?"":q)+",type:ANIME,sort:SEARCH){"+ANI_FIELDS+"}}}";JSONObject data=anilist(query);JSONObject pg=data==null?null:data.optJSONObject("Page");if(pg==null)return out;JSONArray list=pg.optJSONArray("media");for(int i=0;list!=null&&i<list.length();i++){JSONObject m=list.optJSONObject(i);if(m==null)continue;Anime item=anilistAnime(m);if(item!=null){item=remember(item);if(Anime.valid(item))out.items.add(item);}}JSONObject pi=pg.optJSONObject("pageInfo");out.total=pi==null?out.items.size():pi.optInt("total",out.items.size());out.more=pg.optBoolean("hasNextPage",false);return out;}
    private static boolean nativeFilters(String source){return source.equals("yoru")||source.equals("shikimori")||source.equals("yummy")||source.equals("anilibria");}
    private static boolean filterActive(Filter f){return f!=null&&(!f.year.isEmpty()||!f.genre.isEmpty()||!f.type.isEmpty()||!f.status.isEmpty()||!f.season.isEmpty()||!"RATING_DESC".equals(f.sort));}
    private static String shikiStatus(Filter f){String v=f==null?"":f.status;return v.equals("ongoing")?"ongoing":v.equals("released")?"released":v.equals("anons")?"anons":"";}
    private static String yummyStatus(Filter f){String v=f==null?"":f.status;return v.equals("ongoing")?"ongoing":v.equals("released")?"released":v.equals("anons")?"anons":"";}
    private static String libriaStatus(Filter f){String v=f==null?"":f.status;return v.equals("ongoing")?"IS_ONGOING":v.equals("released")?"IS_NOT_ONGOING":"";}
    private static String shikiSort(Filter f){String v=f==null?"":f.sort;return v.equals("YEAR_DESC")?"aired_on":v.equals("NAME")?"name":v.equals("POPULARITY")?"popularity":"ranked";}
    private static String shikiSort(Filter f,String q){return q!=null&&!q.trim().isEmpty()&&"RATING_DESC".equals(f.sort)?"aired_on":shikiSort(f);}
    private static String libriaSort(Filter f){String v=f==null?"":f.sort;return v.equals("YEAR_DESC")?"YEAR_DESC":v.equals("NAME")?"NAME_ASC":v.equals("POPULARITY")?"RATING_DESC":"RATING_DESC";}

    public Anime.Page catalog(String source,String search,int page,Filter f)throws Exception{
        if(f==null)f=new Filter();if(source==null||source.isEmpty())source="all";if(HentaiEngine.isHenta())source="henta";if(!HentaiEngine.isHenta()&&!source.equals("all")&&!nativeFilters(source)&&filterActive(f)){Anime.Page smart=catalog("shikimori",search,page,f);smart.note="Умная подборка";return smart;}if(source.equals("all"))return allCatalog(search,page,f);if(source.equals("yoru"))return yoruCatalog(search,page,f);if(source.equals("anixsekai"))return anixCatalog(search,page,f);if(source.equals("animedia"))return new NativeSources(this).catalog(source,search,page);if(source.equals("kodik"))return kodikCatalog(search,page,f);if(source.equals("animelib4k"))return animelib4kCatalog(search,page,f);if(source.equals("animetka"))return animetkaCatalog(search,page,f);if(source.equals("anidub"))return anidubCatalog(search,page);if(source.equals("henta"))return new HentaiEngine(this).catalog(search,page,f);
        Anime.Page out=new Anime.Page();out.page=page;JSONArray rows;String q=search==null?"":search.trim();int limit=24;
        if(source.equals("shikimori")){
            String args="limit:24,page:"+page+",order:"+shikiSort(f,q)+",censored:false";
            if(!q.isEmpty())args+=",search:"+JSONObject.quote(q);if(!f.year.isEmpty())args+=",season:"+JSONObject.quote((f.season.isEmpty()?"":f.season+"_")+f.year);if(!f.genre.isEmpty())args+=",genre:"+JSONObject.quote(f.genre);if(!f.type.isEmpty())args+=",kind:"+JSONObject.quote(f.type.toLowerCase(Locale.ROOT));String st=shikiStatus(f);if(!st.isEmpty())args+=",status:"+JSONObject.quote(st);
            rows=shiki("{animes("+args+"){"+SH_FIELDS+"}}").optJSONArray("animes");for(int i=0;rows!=null&&i<rows.length();i++)out.items.add(remember(shikiAnime(rows.getJSONObject(i))));out.more=rows!=null&&rows.length()==limit;
        }else if(source.equals("animevost")){
            JSONObject data=q.isEmpty()?get("https://api.animevost.org/v1/last?quantity=24&page="+page):postForm("https://api.animevost.org/v1/search","name",q);rows=data.optJSONArray("data");if(rows==null)rows=new JSONArray();if(q.isEmpty()){JSONObject st=data.optJSONObject("state");out.total=st==null?-1:st.optLong("count",-1);for(int i=0;i<rows.length();i++)out.items.add(remember(vostAnime(rows.getJSONObject(i))));out.more=out.total>page*24;}else{out.total=rows.length();for(int i=(page-1)*24;i<Math.min(rows.length(),page*24);i++)out.items.add(remember(vostAnime(rows.getJSONObject(i))));out.more=rows.length()>page*24;}
        }else if(source.equals("yummy")){
            Map<String,String> p=params("limit","24","offset",String.valueOf((page-1)*24),"q",q,"sort",f.sort.equals("YEAR_DESC")?"year":f.sort.equals("NAME")?"name":"rating","sort_forward",f.sort.equals("NAME")?"true":"false","genres",f.genre,"from_year",f.year,"to_year",f.year,"types",f.type.toLowerCase(Locale.ROOT),"status",yummyStatus(f));JSONObject data=get(query("https://api.yani.tv/anime",p));if(data.has("error"))throw new IOException("Каталог сейчас недоступен");rows=data.optJSONArray("response");for(int i=0;rows!=null&&i<rows.length();i++)out.items.add(remember(yummyAnime(rows.getJSONObject(i))));out.more=rows!=null&&rows.length()==24;
        }else if(source.equals("animelib")){
            Map<String,String> p=params("page",String.valueOf(page),"q",q,"sort_by",f.sort.equals("FRESH_AT_DESC")?"last_episode_at":"rate_avg");String u=query("https://api.cdnlibs.org/api/anime",p)+"&fields%5B%5D=rate&fields%5B%5D=rate_avg&fields%5B%5D=releaseDate";if(f.status.equals("ongoing"))u+="&status%5B%5D=1";else if(f.status.equals("released"))u+="&status%5B%5D=2";JSONObject data=get(u);rows=data.optJSONArray("data");for(int i=0;rows!=null&&i<rows.length();i++)out.items.add(remember(amAnime(rows.getJSONObject(i))));JSONObject links=data.optJSONObject("links");out.more=links!=null&&!links.isNull("next")&&!links.optString("next","").isEmpty();
        }else if(source.equals("anilibria")){
            Map<String,String> p=params("limit","24","page",String.valueOf(page),"f[search]",q,"f[sorting]",libriaSort(f),"f[genres]",f.genre,"f[types]",f.type,"f[years][from_year]",f.year,"f[years][to_year]",f.year,"f[publish_statuses]",libriaStatus(f));JSONObject data=get(query("https://anilibria.top/api/v1/anime/catalog/releases",p));rows=data.optJSONArray("data");for(int i=0;rows!=null&&i<rows.length();i++)out.items.add(remember(libriaAnime(rows.getJSONObject(i))));JSONObject meta=data.optJSONObject("meta"),pg=meta==null?null:meta.optJSONObject("pagination");if(pg!=null){out.total=pg.optLong("total",-1);out.more=page<pg.optInt("total_pages");}
        }else throw new IOException("Неизвестный каталог");
        if(out.total>=0&&q.isEmpty()&&f.genre.isEmpty()&&f.year.isEmpty()&&f.type.isEmpty()&&f.status.isEmpty())counts.put(source,out.total);return out;
    }


    private Anime.Page allCatalog(String search,int page,Filter f)throws Exception{if(HentaiEngine.isHenta())return new HentaiEngine(this).catalog(search,page,f);if(filterActive(f)){Anime.Page smart=catalog("shikimori",search,page,f);smart.note="Умная подборка";return smart;}Anime.Page out=new Anime.Page();out.page=page;LinkedHashMap<String,Anime> items=new LinkedHashMap<>();boolean more=false;int ok=0;boolean withAni=search!=null&&!search.trim().isEmpty();boolean isMobile=false;try{YoruApp app=YoruApp.app();if(app!=null&&app.traffic!=null)isMobile=app.traffic.mobile()||app.traffic.metered();}catch(Exception ignored){}ExecutorService pool=Executors.newFixedThreadPool(Math.max(2,Math.min(isMobile?3:5,REAL_SOURCES.length+1)));CompletionService<Anime.Page> done=new ExecutorCompletionService<>(pool);for(String source:REAL_SOURCES){final String src=source;done.submit(()->catalog(src,search,page,f));}if(withAni)done.submit(()->anilistCatalog(search.trim(),page));int tasks=REAL_SOURCES.length+(withAni?1:0);long deadline=System.currentTimeMillis()+((search==null||search.trim().isEmpty())?3600:5200);try{for(int i=0;i<tasks;i++){long left=deadline-System.currentTimeMillis();if(left<=0)break;Future<Anime.Page> future=done.poll(left,TimeUnit.MILLISECONDS);if(future==null)break;try{Anime.Page p=future.get();ok++;more|=p.more;for(Anime a:p.items)items.put(a.key(),a);if(items.size()>=24&&(isMobile?ok>=1:ok>=2))break;}catch(Exception ignored){}}}finally{pool.shutdownNow();}out.items.addAll(SourceEngine.mergeCatalog(items.values(),24));out.more=more;if((search==null||search.trim().isEmpty())&&countOf("all")>0)out.total=countOf("all");if(out.items.isEmpty()&&ok==0)throw new IOException("Tsuyu сейчас не получил подборку");return out;}
    public Anime quickDetails(Anime base)throws Exception{if(!Anime.valid(base))return base;YoruCache db=YoruApp.app()==null?null:YoruApp.app().cache;Anime cached=db==null?null:db.detail(base,18*60*60*1000L);if(Anime.valid(cached)&&!cached.description.isEmpty()){SourceEngine.absorb(base,cached);return remember(cached);}if(base.source.equals("henta")){try{return remember(new HentaiEngine(this).quickDetails(base));}catch(Exception e){return remember(base);}}Anime result=null;if(base.source.equals("shikimori")){int id=base.malId>0?base.malId:parseInt(base.id);if(id>0)result=shikiQuick(id,base.source);}else if(base.source.equals("yoru")){int id=base.malId>0?base.malId:0;if(id>0){Anime meta=shikiQuick(id,"yoru");Anime a=yoruShell(meta);fillYoruMeta(a,meta);result=a;}else try{Anime y=findYummy(base);if(Anime.valid(y)){Anime a=yoruShell(y);fillYoruMeta(a,y);result=a;}}catch(Exception ignored){}}else if(base.source.equals("yummy")){JSONObject d=get("https://api.yani.tv/anime/"+enc(base.id)).optJSONObject("response");result=d==null?base:yummyAnime(d);}else if(base.source.equals("animelib")){String slug=base.alias.isEmpty()?base.id:base.alias;result=amAnime(animelibDetail(slug,base).getJSONObject("data"));}else if(base.source.equals("anilibria"))result=libriaAnime(get("https://anilibria.top/api/v1/anime/releases/"+enc(base.id)));else if(base.source.equals("henta"))result=new HentaiEngine(this).quickDetails(base);else result=details(base,false);if(!Anime.valid(result))result=base;if(result.year==0)result.year=base.year;if(result.description.isEmpty())result.description=base.description;if(result.poster.isEmpty())result.poster=base.poster;if(db!=null)db.detail(result);return remember(result);}
    public void prefetchQuickDetails(Collection<Anime> rows,int max){if(rows==null)return;YoruApp app=YoruApp.app();if(app!=null&&app.traffic!=null&&(app.traffic.mobile()||app.traffic.metered()))return;Net.bg(true);try{int n=0;for(Anime a:rows){if(!Anime.valid(a))continue;if(++n>max)break;try{quickDetails(a);}catch(Exception ignored){}}}finally{Net.bg(false);}}
    public void prefetchEpisodeList(Anime a){if(!Anime.valid(a))return;YoruApp app=YoruApp.app();if(app==null||app.cache==null||app.discovery==null||app.savingMobile())return;if(app.traffic!=null&&(app.traffic.mobile()||app.traffic.metered()))return;app.discovery.execute(()->Net.runBg(()->{try{Anime cached=app.cache.detail(a,14*24*60*60*1000L);if(cached!=null&&!cached.episodeList.isEmpty()&&playableEpisodes(cached)>0)return;Anime target=a;if("shikimori".equals(a.source))target=yoruShell(a);playback(target,"yoru");}catch(Exception ignored){}}));}
    public void prefetchEpisodes(Collection<Anime> rows,int max){if(rows==null)return;YoruApp app=YoruApp.app();if(app!=null&&app.traffic!=null&&(app.traffic.mobile()||app.traffic.metered()))return;int n=0;for(Anime a:rows){if(!Anime.valid(a))continue;if(++n>max)break;prefetchEpisodeList(a);}}
    public int airedEpisodes(Anime a)throws Exception{int mal=malIdOf(a);if(mal<=0)throw new IOException("Нет id");JSONArray rows=shiki("{animes(ids:\""+mal+"\",limit:1){id episodes episodesAired status}}").optJSONArray("animes");if(rows==null||rows.length()==0)throw new IOException("Аниме не найдено");JSONObject j=rows.getJSONObject(0);int episodes=j.optInt("episodes"),aired=j.optInt("episodesAired",0);String status=j.optString("status","");if(aired<=0&&episodes>0&&(status.equals("released")||status.equals("finished")||status.equals("complete")))aired=episodes;return aired;}
    private static int malIdOf(Anime a){if(a==null)return 0;return a.malId>0?a.malId:("shikimori".equals(a.source)?parseInt(a.id):0);}
    public HashMap<Long,String> episodeShots(Anime a){
        HashMap<Long,String> out=new HashMap<>();
        int mal=malIdOf(a);
        YoruCache db=YoruApp.app()==null?null:YoruApp.app().cache;
        int epCount=a!=null?Math.max(a.episodes,a.episodeList.size()):0;
        if(mal>0&&db!=null)try{
            JSONArray cached=db.shots(mal,21*DAY_MS);
            for(int i=0;i<cached.length();i++){
                JSONObject row=cached.optJSONObject(i);
                if(row==null)continue;
                double n=row.optDouble("n",-1);
                String u=safeUrl(row.optString("u",""));
                if(n>0&&!u.isEmpty()){Long key=Math.round(n);if(!out.containsKey(key))out.put(key,u);}
            }
            if(!out.isEmpty()&&(epCount<=0||out.size()>=epCount))return out;
        }catch(Exception ignored){}
        if(a!=null&&!a.episodeList.isEmpty()){
            for(Anime.Episode ep:a.episodeList){
                if(ep!=null&&!ep.future&&ep.poster!=null&&!ep.poster.isEmpty()&&!ep.poster.equals(a.poster)){
                    Long key=Math.round(ep.number);
                    if(key>0&&!out.containsKey(key))out.put(key,safeUrl(ep.poster));
                }
            }
            if(!out.isEmpty()&&(epCount<=0||out.size()>=epCount)){
                if(mal>0&&db!=null){
                    JSONArray store=new JSONArray();
                    for(Map.Entry<Long,String> en:out.entrySet()){
                        try{store.put(new JSONObject().put("n",en.getKey()).put("u",en.getValue()));}catch(Exception ignored){}
                    }
                    if(store.length()>0)db.shots(mal,store);
                }
                return out;
            }
        }
        if(mal>0||(a!=null&&a.anilistId>0)){
            try{
                HashMap<Long,String> ani=AniListApi.episodeThumbnails(mal,a!=null?a.anilistId:0,this);
                if(ani!=null&&!ani.isEmpty()){
                    for(Map.Entry<Long,String> en:ani.entrySet()){
                        if(!out.containsKey(en.getKey()))out.put(en.getKey(),en.getValue());
                    }
                }
            }catch(Exception ignored){}
        }
        if(a!=null&&mal>0){
            try{
                ArrayList<String> shots=screenshotsOf(a);
                if(shots!=null&&!shots.isEmpty()){
                    int count=epCount>0?epCount:shots.size();
                    for(int i=0;i<count;i++){
                        Long key=(long)(i+1);
                        if(!out.containsKey(key)){
                            String u=safeUrl(shots.get(i%shots.size()));
                            if(!u.isEmpty())out.put(key,u);
                        }
                    }
                }
            }catch(Exception ignored){}
        }
        if(mal>0&&db!=null&&!out.isEmpty()){
            JSONArray store=new JSONArray();
            for(Map.Entry<Long,String> en:out.entrySet()){
                try{store.put(new JSONObject().put("n",en.getKey()).put("u",en.getValue()));}catch(Exception ignored){}
            }
            if(store.length()>0)db.shots(mal,store);
        }
        return out;
    }
    public void fillEpisodePosters(Anime anime,Runnable done){if(anime==null)return;YoruApp app=YoruApp.app();app.discovery.execute(()->{try{HashMap<Long,String> shots=episodeShots(anime);if(!shots.isEmpty())for(Anime.Episode e:anime.episodeList){if(e==null||e.future)continue;if(!e.poster.isEmpty()&&!e.poster.equals(anime.poster))continue;String url=shots.get(Math.round(e.number));if(url!=null&&!url.isEmpty())e.poster=url;}}catch(Exception ignored){}finally{if(done!=null)app.main.post(done);}});}
    public void refreshFranchise(Anime base,Runnable done){if(base==null)return;YoruApp app=YoruApp.app();app.discovery.execute(()->{try{enrichRelated(base);}catch(Exception ignored){}finally{if(done!=null)app.main.post(done);}});}
    private Anime shikiQuick(int id,String source)throws Exception{return ShikimoriApi.shikiQuick(id,source,this);}
    public Anime details(Anime base,boolean episodes)throws Exception{
        if(base.source.equals("henta"))return new HentaiEngine(this).details(base,episodes);
        if(base.source.equals("animedia"))return new NativeSources(this).details(base,episodes);
        Anime a;String id=base.id;
        if("yoru".equals(base.source)){a=yoruDetails(base,episodes);}
        else if("anixsekai".equals(base.source)){a=anixDetails(base,episodes);}
        else if("shikimori".equals(base.source)){JSONArray rows=shiki("{animes(ids:"+JSONObject.quote(id)+",limit:1){"+SH_FIELDS+" descriptionHtml related{relationKind anime{"+SH_FIELDS+"}}}P{").optJSONArray("animes");if(rows==null||rows.length()==0)throw new IOException("Аниме не найдено");JSONObject j=rows.getJSONObject(0);a=shikiAnime(j);a.description=plain(j.optString("descriptionHtml"));JSONArray rel=j.optJSONArray("related");for(int i=0;rel!=null&&i<rel.length();i++){JSONObject r=rel.getJSONObject(i).optJSONObject("anime");if(r!=null)a.related.add(remember(shikiAnime(r)));}if(episodes){try{Anime y=yoruShell(a);Anime full=details(y,true);if(full!=null&&!full.episodeList.isEmpty()){a.episodeList.addAll(full.episodeList);a.episodes=Math.max(a.episodes,full.episodes);a.episodesAired=Math.max(a.episodesAired,full.episodesAired);}}catch(Exception ignored){}}}
        else if("animevost".equals(base.source)){JSONArray rows=postForm("https://api.animevost.org/v1/info","id",id).optJSONArray("data");if(rows==null||rows.length()==0)throw new IOException("Аниме не найдено");a=vostAnime(rows.getJSONObject(0));if(episodes){JSONArray list=new JSONArray(request("https://api.animevost.org/v1/playlist","POST","id="+enc(id),true));for(int i=0;i<list.length();i++){JSONObject e=list.getJSONObject(i);Anime.Episode ep=new Anime.Episode();ep.id=id+"-"+i;ep.name=e.optString("name","");ep.number=numberIn(ep.name,i+1);putStream(ep,480,e.optString("std"));putStream(ep,720,e.optString("hd"));a.episodeList.add(ep);}a.episodesAired=Math.max(a.episodesAired,a.episodeList.size());a.episodes=Math.max(a.episodes,a.episodeList.size());}}
        else if("yummy".equals(base.source)){JSONObject d=get("https://api.yani.tv/anime/"+enc(id)).optJSONObject("response");if(d==null)throw new IOException("Tsuyu не открыл карточку");a=yummyAnime(d);if(episodes){a.episodeList.addAll(YummyParser.episodes(id));a.episodesAired=Math.max(a.episodesAired,playableEpisodes(a));a.episodes=Math.max(a.episodes,a.episodeList.size());}}
        else if("anidub".equals(base.source)){a=anidubDetails(base,episodes);}
        else if("animelib".equals(base.source)){String slug=base.alias.isEmpty()?id:base.alias;JSONObject d=animelibDetail(slug,base).getJSONObject("data");a=amAnime(d);if(episodes){JSONArray rows=get("https://api.cdnlibs.org/api/episodes?anime_id="+enc(a.alias)).optJSONArray("data");for(int i=0;rows!=null&&i<rows.length();i++){JSONObject e=rows.getJSONObject(i);double n=e.optDouble("number",-1);if(n<0||!Double.isFinite(n))continue;Anime.Episode ep=new Anime.Episode();ep.id=e.optString("id");ep.number=n;ep.name=e.optString("name","");ep.poster=bestImage(e);ep.lazy="animelib";a.episodeList.add(ep);}a.episodeList.sort(Comparator.comparingDouble(e->e.number));a.episodesAired=Math.max(a.episodesAired,a.episodeList.size());a.episodes=Math.max(a.episodes,a.episodeList.size());}}
        else if("animelib4k".equals(base.source)){Anime copy=Anime.from(base.json());copy.source="animelib";a=details(copy,episodes);a.source="animelib4k";}
        else if("anilibria".equals(base.source)){a=libriaAnime(get("https://anilibria.top/api/v1/anime/releases/"+enc(id)));}
        else if("animetka".equals(base.source)){a=animetkaDetails(base,episodes);}
        else if("hanime".equals(base.source)){a=hanimeDetails(base,episodes);}
        else if("kodik".equals(base.source)){a=kodikDetails(base,episodes);}
        else throw new IOException("Неизвестный каталог");
        if(a.year==0)a.year=base.year;if(a.malId==0)a.malId=base.malId;if(a.anilistId==0)a.anilistId=base.anilistId;if(a.kpId==0)a.kpId=base.kpId;if(a.description.isEmpty())a.description=base.description;if(a.poster.isEmpty())a.poster=base.poster;if(a.trailerUrl.isEmpty())a.trailerUrl=base.trailerUrl;for(String shot:base.screenshots)if(!shot.isEmpty()&&!a.screenshots.contains(shot)&&a.screenshots.size()<12)a.screenshots.add(shot);
        YoruCache db=YoruApp.app()==null?null:YoruApp.app().cache;
        boolean fullMeta=base.source.equals("yoru")||!episodes;
        if(fullMeta){
            if(episodes){
                final Anime snap=a;
                ENRICH.execute(()->{try{runEnrich(snap);}catch(Exception ignored){}});
            }else{
                runEnrich(a);
            }
        }
        if(episodes)appendFutureEpisodes(a);applyEpisodeVisuals(a);if(db!=null&&episodes)db.detail(a);return remember(a);
    }
    private static final ExecutorService ENRICH=new ThreadPoolExecutor(
            4, 16, 30L, TimeUnit.SECONDS,
            new SynchronousQueue<>(),
            r -> {
                Thread t = new Thread(r, "yoru-enrich");
                t.setPriority(Thread.NORM_PRIORITY - 1);
                return t;
            },
            new ThreadPoolExecutor.CallerRunsPolicy()
    );
    private void runEnrich(Anime a){ArrayList<Future<?>> jobs=new ArrayList<>();try{jobs.add(ENRICH.submit((Runnable)()->enrichSchedule(a)));jobs.add(ENRICH.submit((Runnable)()->enrichVisuals(a)));jobs.add(ENRICH.submit((Runnable)()->enrichRelated(a)));for(Future<?> j:jobs){try{j.get(800,TimeUnit.MILLISECONDS);}catch(InterruptedException ie){Thread.currentThread().interrupt();break;}catch(Exception ignored){}}}catch(Exception ignored){}finally{for(Future<?> j:jobs)j.cancel(true);}}
    public Anime.Playback playback(Anime input,String selectedMode)throws Exception{
        normalizeIds(input);
        String selected=selectedMode==null||selectedMode.trim().isEmpty()?"auto":selectedMode.trim();
        if(selected.equals("all"))selected="auto";
        if(input!=null&&"henta".equals(input.source)&&!selected.equals("henta"))selected="henta";
        if(!selected.equals("auto")){
            Anime video=findPlayableSource(input,selected);
            if(video!=null)return playbackResult(input,video,selected);
            if("henta".equals(selected)||"henta".equals(input.source))throw new IOException("Просмотр сейчас не вернул серии");
        }
        ArrayList<String> order=SourceEngine.playbackOrder(input);
        ExecutorService pool=Executors.newFixedThreadPool(Math.max(1,Math.min(6,order.size())));
        CompletionService<Anime.Playback> done=new ExecutorCompletionService<>(pool);
        for(String source:order){final String src=source;done.submit(()->{Anime video=findPlayableSource(input,src);return video==null?null:playbackResult(input,video,src);});}
        long deadline=System.currentTimeMillis()+30000;
        try{for(int i=0;i<order.size();i++){long left=deadline-System.currentTimeMillis();if(left<=0)break;Future<Anime.Playback> f=done.poll(left,TimeUnit.MILLISECONDS);if(f==null)break;try{Anime.Playback r=f.get();if(r!=null)return r;}catch(Exception ignored){}}}finally{pool.shutdownNow();}
        throw new IOException("Tsuyu сейчас не нашёл серии");
    }
    private Anime.Playback playbackResult(Anime catalog,Anime video,String provider){Anime.Playback r=new Anime.Playback();r.catalog=catalog;r.video=video;r.provider=provider==null||provider.isEmpty()?video.source:provider;return r;}
    private Anime findPlayableSource(Anime input,String source){long started=System.currentTimeMillis();try{Anime candidate=findSourceCandidate(input,source);if(candidate==null){SourceEngine.record(source,false,System.currentTimeMillis()-started,0,0,0);return null;}Anime full=candidate.episodeList.isEmpty()||playableEpisodes(candidate)<=0?details(candidate,true):candidate;if(!full.blocked&&playableEpisodes(full)>0){SourceEngine.record(source,true,System.currentTimeMillis()-started,full.episodeList.size(),SourceEngine.optionCount(full),SourceEngine.maxQuality(full));return full;}SourceEngine.record(source,false,System.currentTimeMillis()-started,0,0,0);}catch(Exception ignored){SourceEngine.record(source,false,System.currentTimeMillis()-started,0,0,0);}return null;}
    private Anime findSourceCandidate(Anime input,String source)throws Exception{
        if(source.equals(input.source)&&Arrays.asList("yoru","animevost","anilibria","animedia","animelib","animelib4k","yummy","animetka","anidub","kodik","anixsekai","hanime","henta").contains(source))return input;
        if(source.equals("yoru"))return yoruShell(input);
        if(source.equals("yummy"))return findYummy(input);
        if(source.equals("anilibria")){Anime v=findAniLiberty(input);if(v!=null)return v;}
        if(source.equals("animelib")){Anime v=findAniLib(input);if(v!=null)return v;}
        if(source.equals("kodik"))return kodikShell(input);
        if(source.equals("anixsekai"))return findAnix(input);
        if(source.equals("hanime"))return findHanime(input);
        if(source.equals("animetka")||source.equals("anidub"))return searchSource(input,source);
        if(source.equals("animelib4k")){Anime v=findAniLib(input);if(v!=null){v.source="animelib4k";return v;}}
        if(Arrays.asList("animevost","animedia").contains(source))return searchSource(input,source);
        return null;
    }
    public synchronized void loadEpisode(Anime.Episode ep)throws Exception{TaskQueue.check();normalizeEpisode(ep);if(ep.lazy.equals("yoru")){loadYoruEpisode(ep);return;}if(ep.lazy.equals("animedia")){new NativeSources(this).loadEpisode(ep);return;}if(ep.lazy.equals("anidub")){if(ep.variants.isEmpty()&&!ep.resolverUrl.isEmpty())ep.variants.add(new Anime.Variant("AniDUB",hostName(ep.resolverUrl),ep.resolverUrl));return;}if(ep.lazy.equals("kodik")){if(ep.variants.isEmpty())ep.variants.add(new Anime.Variant("",cleanLabel(hostName(ep.resolverUrl)),ep.resolverUrl));return;}if(ep.lazy.equals("anixsekai")){return;}if(ep.lazy.equals("hanime")){return;}if(!"animelib".equals(ep.lazy)||!ep.variants.isEmpty())return;JSONObject d=get("https://api.cdnlibs.org/api/episodes/"+enc(ep.id)).getJSONObject("data");JSONArray rows=d.optJSONArray("players");for(int i=0;rows!=null&&i<rows.length();i++){JSONObject v=rows.getJSONObject(i);String u=embed(v.optString("src"));if(u.isEmpty())continue;JSONObject team=v.optJSONObject("team"),t=v.optJSONObject("translation_type");String teamName=team==null?"":team.optString("name",team.optString("title",""));String type=t==null?"":t.optString("label",t.optString("title",""));String name=(type+" "+teamName).trim();String voice=voiceLabel(name);if(voice.isEmpty())voice=voiceLabel(teamName);String player=cleanLabel(v.optString("player",""));Anime.Variant row=new Anime.Variant(voice,player,u);row.displayName=voice;addVariant(ep,row);}if(ep.variants.isEmpty())throw new IOException("У серии пока нет доступного просмотра");ep.variants.sort(Comparator.comparingInt(v->SourceEngine.variantRank(v)));}
    public static final class DownloadOption {public Anime source;public Anime.Episode episode;public int quality;public String voice,player;DownloadOption(Anime s,Anime.Episode e,int q,String v,String p){source=s;episode=e;quality=q;voice=v;player=p;}public String label(){String q=QualityPlus.streamLabel(quality);String v=voiceLabel(voice);return v.isEmpty()?q:q+" · "+v;}}
    private List<DownloadOption> options(Anime source,double number)throws Exception{SecureStore store=YoruApp.app().store;return options(source,number,store.voicePreference(),store.downloadResolution(),store.onlyPreferredVoice());}
    private List<DownloadOption> options(Anime source,double number,String voice,int maxQuality,boolean strictVoice)throws Exception{ArrayList<DownloadOption> out=new ArrayList<>();if(!Anime.valid(source))return out;Anime a=source.episodeList.isEmpty()?details(source,true):source;Anime.Episode e=findEpisode(a,number);if(e==null)return out;if(!"yoru".equals(e.lazy))loadEpisode(e);for(Map.Entry<Integer,String> stream:e.streams.entrySet()){String u=safeUrl(stream.getValue());if(u.isEmpty())continue;String streamVoice=sourceVoice(a.source);if(streamVoice.isEmpty())continue;DownloadOption option=new DownloadOption(a,e,stream.getKey(),streamVoice,downloadSourceName(a.source));if(optionAllowed(option,voice,maxQuality,strictVoice))out.add(option);}if(!e.variants.isEmpty())out.addAll(variantOptions(a,e,voice,maxQuality,strictVoice));return uniqueOptions(out);}
    private List<DownloadOption> variantOptions(Anime source,Anime.Episode episode,String voice,int maxQuality,boolean strictVoice){ArrayList<DownloadOption> out=new ArrayList<>();ArrayList<Anime.Variant> variants=SourceEngine.sortVariants(episode.variants);ArrayList<Anime.Variant> chosen=new ArrayList<>();for(Anime.Variant v:variants){if(v==null||variantVoiceLabel(v).isEmpty())continue;String label=v.name+" "+v.displayName+" "+v.player;if(strictVoice&&!voiceMatches(voice,label))continue;chosen.add(v);}if(chosen.isEmpty())return out;ExecutorService pool=Executors.newFixedThreadPool(strictVoice?3:Math.max(2,Math.min(6,chosen.size())));CompletionService<List<DownloadOption>> done=new ExecutorCompletionService<>(pool);for(Anime.Variant variant:chosen)done.submit(()->{ArrayList<DownloadOption> rows=new ArrayList<>();try{TreeMap<Integer,String> streams=resolveStreams(variant.url);String vName=variantVoiceLabel(variant);if(vName.isEmpty())return rows;for(Map.Entry<Integer,String> stream:streams.entrySet()){if(safeUrl(stream.getValue()).isEmpty())continue;Anime.Episode ep=new Anime.Episode();ep.id=episode.id+"-"+Integer.toHexString((variant.url+"|"+stream.getKey()).hashCode());ep.number=episode.number;ep.name=vName;ep.duration=episode.duration;ep.openingStart=episode.openingStart;ep.openingEnd=episode.openingEnd;ep.streams.put(stream.getKey(),stream.getValue());DownloadOption option=new DownloadOption(source,ep,stream.getKey(),vName,variant.player);if(optionAllowed(option,voice,maxQuality,strictVoice))rows.add(option);}SourceEngine.recordVariant(variant,!rows.isEmpty(),0,streams.isEmpty()?0:streams.lastKey());}catch(Exception ignored){SourceEngine.recordVariant(variant,false,0,0);}return rows;});long deadline=System.currentTimeMillis()+(strictVoice?16000:9500);try{for(int i=0;i<chosen.size();i++){long left=deadline-System.currentTimeMillis();if(left<=0)break;Future<List<DownloadOption>> future;try{future=done.poll(left,TimeUnit.MILLISECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}if(future==null)break;try{out.addAll(future.get());out=uniqueOptions(out);}catch(Exception ignored){}}}finally{pool.shutdownNow();}return uniqueOptions(out);}
    private boolean optionAllowed(DownloadOption option,String voice,int maxQuality,boolean strictVoice){if(option==null||option.episode==null)return false;if(strictVoice&&!voiceMatches(voice,option.voice+" "+option.episode.name))return false;if(maxQuality>0&&maxQuality<9999&&option.quality>0&&option.quality>maxQuality)return false;return option.quality>=0;}
    private static ArrayList<DownloadOption> uniqueOptions(Collection<DownloadOption> rows){LinkedHashMap<String,DownloadOption> map=new LinkedHashMap<>();if(rows!=null)for(DownloadOption option:rows){if(option==null||option.episode==null)continue;String url=safeUrl(option.episode.streams.get(option.quality));if(url.isEmpty())continue;String key=episodeParam(option.episode.number)+"|"+option.quality+"|"+url;if(!map.containsKey(key))map.put(key,option);}ArrayList<DownloadOption> out=new ArrayList<>(map.values());out.sort((a,b)->{int va=YoruApp.app().store.voicePriority(a.voice+" "+(a.episode==null?"":a.episode.name)),vb=YoruApp.app().store.voicePriority(b.voice+" "+(b.episode==null?"":b.episode.name));if(va!=vb)return Integer.compare(va<0?999:va,vb<0?999:vb);int sa=SourceEngine.score(a.source==null?"":a.source.source,a.source),sb=SourceEngine.score(b.source==null?"":b.source.source,b.source);int p=sb-sa;if(p!=0)return p;return Integer.compare(b.quality,a.quality);});return out;}
    private boolean enoughDownloadOptions(ArrayList<DownloadOption> rows,String voice,int maxQuality,boolean strictVoice){ArrayList<DownloadOption> unique=uniqueOptions(rows);if(unique.size()>=6)return true;HashSet<Integer> q=new HashSet<>();for(DownloadOption option:unique)if(optionAllowed(option,voice,maxQuality,strictVoice))q.add(option.quality);return q.size()>=3&&unique.size()>=3;}
    private void collectOptions(ArrayList<DownloadOption> out,Anime source,double number,String voice,int maxQuality,boolean strictVoice){if(!Anime.valid(source))return;try{out.addAll(options(source,number,voice,maxQuality,strictVoice));}catch(Exception ignored){}}
    private void collectDetailsOptions(ArrayList<DownloadOption> out,Anime base,double number,String voice,int maxQuality,boolean strictVoice){if(!Anime.valid(base))return;try{collectOptions(out,details(base,true),number,voice,maxQuality,strictVoice);}catch(Exception ignored){}}
    private void collectCatalogOptions(ArrayList<DownloadOption> out,Anime base,double number,String voice,int maxQuality,boolean strictVoice){if(!Anime.valid(base))return;ArrayList<Anime> matches=new ArrayList<>();for(String s:SourceEngine.discoveryOrder(base,null)){try{for(Anime candidate:catalog(s,base.original.isEmpty()?base.title:base.original,1,new Filter()).items)if(candidate!=null&&SourceEngine.identity(candidate).equals(SourceEngine.identity(base)))matches.add(candidate);}catch(Exception ignored){}if(matches.size()>=4)break;}matches.sort((a,b)->SourceEngine.score(b.source,b)-SourceEngine.score(a.source,a));for(Anime candidate:matches){collectOptions(out,candidate,number,voice,maxQuality,strictVoice);if(enoughDownloadOptions(out,voice,maxQuality,strictVoice))break;}}
    private void collectIframeOptions(ArrayList<DownloadOption> out,Anime base,double number){try{Anime.Playback ready=playback(base,"kodik");String url=ready==null?"":embed(ready.directUrl);if(url.isEmpty()&&ready!=null&&ready.video!=null){Anime.Episode ep=findEpisode(ready.video,number);if(ep!=null){loadEpisode(ep);if(!ep.variants.isEmpty())url=embed(ep.variants.get(0).url);}}if(url.isEmpty())return;TreeMap<Integer,String> streams=resolveStreams(url);for(Map.Entry<Integer,String> stream:streams.entrySet()){String safe=safeUrl(stream.getValue());if(safe.isEmpty())continue;Anime source=Anime.from(base.json());source.source="kodik";source.id=base.id.isEmpty()?String.valueOf(Math.abs(base.key().hashCode())):base.id;Anime.Episode ep=new Anime.Episode();ep.id=source.id+"-"+episodeParam(number)+"-"+stream.getKey();ep.number=number;ep.name="";ep.streams.put(stream.getKey(),safe);}}catch(Exception ignored){}}
    private static Anime.Episode findEpisode(Anime anime,double number){if(anime==null)return null;Anime.Episode fallback=null;double best=Double.MAX_VALUE;for(Anime.Episode ep:anime.episodeList){if(ep==null||ep.future)continue;if(sameEpisode(ep.number,number))return ep;double diff=Math.abs(ep.number-number);if(diff<best){best=diff;fallback=ep;}}return fallback;}
    public List<DownloadOption> downloadOptions(Anime a,Anime.Playback current,double number)throws Exception{SecureStore store=YoruApp.app().store;return downloadOptions(a,current,number,store.voicePreference(),store.downloadResolution(),store.onlyPreferredVoice());}
    public List<DownloadOption> downloadOptions(Anime a,Anime.Playback current,double number,String voice,int maxQuality,boolean strictVoice)throws Exception{voice=voiceLabel(voice);if(voice.isEmpty())strictVoice=false;ArrayList<DownloadOption> out=new ArrayList<>();if(current!=null&&current.video!=null)collectOptions(out,current.video,number,voice,maxQuality,strictVoice);if(enoughDownloadOptions(out,voice,maxQuality,strictVoice))return uniqueOptions(out);collectDetailsOptions(out,a,number,voice,maxQuality,strictVoice);if(enoughDownloadOptions(out,voice,maxQuality,strictVoice))return uniqueOptions(out);Anime yoru=yoruShell(a);if(Anime.valid(yoru))collectOptions(out,yoru,number,voice,maxQuality,strictVoice);if(enoughDownloadOptions(out,voice,maxQuality,strictVoice))return uniqueOptions(out);Anime max=null;try{max=findYummy(a);}catch(Exception ignored){}if(Anime.valid(max))collectOptions(out,max,number,voice,maxQuality,strictVoice);if(enoughDownloadOptions(out,voice,maxQuality,strictVoice))return uniqueOptions(out);if(!strictVoice)collectIframeOptions(out,a,number);if(!out.isEmpty())return uniqueOptions(out);collectCatalogOptions(out,a,number,voice,maxQuality,strictVoice);return uniqueOptions(out);}

    private Anime.Page yoruCatalog(String search,int page,Filter f)throws Exception{String q=search==null?"":search.trim();Anime.Page base;try{base=catalog("shikimori",q,page,f);}catch(Exception first){base=catalog("yummy",q,page,f);}Anime.Page out=new Anime.Page();out.page=base.page;out.total=base.total;out.more=base.more;out.note="Tsuyu";for(Anime item:base.items)out.items.add(remember(yoruShell(item)));ArrayList<Integer> anilistAt=new ArrayList<>();if(!q.isEmpty()){try{Anime.Page extra=anilistCatalog(q,1);for(Anime item:extra.items){if(out.items.size()>=24)break;boolean dup=false;for(Anime h:out.items){if(item.malId>0&&h.malId==item.malId){dup=true;break;}String hi=SourceEngine.identity(h);if(!hi.isEmpty()&&hi.equals(SourceEngine.identity(item))){dup=true;break;}if(!h.title.isEmpty()&&(h.title.equalsIgnoreCase(item.title)||h.original.equalsIgnoreCase(item.original))){dup=true;break;}}if(!dup){out.items.add(remember(yoruShell(item)));anilistAt.add(out.items.size()-1);}}}catch(Exception ignored){}}if(!anilistAt.isEmpty()&&page==1)canonicalize(out,anilistAt);return out;}
    private void canonicalize(Anime.Page out,ArrayList<Integer> at){ArrayList<Integer> need=new ArrayList<>();for(int idx:at){if(idx<0||idx>=out.items.size())continue;int id=out.items.get(idx).malId;if(id>0&&!need.contains(id))need.add(id);if(need.size()>=12)break;}if(need.isEmpty())return;StringBuilder ids=new StringBuilder();for(int id:need){if(ids.length()>0)ids.append(',');ids.append(id);}JSONArray rows;try{StringBuilder qs=new StringBuilder();qs.append("{animes(ids:\"").append(ids).append("\",limit:").append(need.size()).append("){").append(SH_FIELDS).append("}}");rows=shiki(qs.toString()).optJSONArray("animes");}catch(Exception ignored){return;}if(rows==null||rows.length()==0)return;Map<Integer,Anime> canon=new HashMap<>();for(int i=0;i<rows.length();i++){JSONObject raw=rows.optJSONObject(i);if(raw==null)continue;Anime e=shikiAnime(raw);if(e!=null&&e.malId>0&&Anime.valid(e))canon.put(e.malId,remember(e));}for(int idx:at){if(idx<0||idx>=out.items.size())continue;Anime e=canon.get(out.items.get(idx).malId);if(e!=null)out.items.set(idx,e);}}
    public Anime yoruShell(Anime base){Anime a=Anime.from(base==null?new JSONObject():base.json());String originalSource=base==null?"":base.source;a.source="yoru";int id=a.malId>0?a.malId:("shikimori".equals(originalSource)?parseInt(base.id):0);if(id>0&&a.malId==0)a.malId=id;if(id<=0)id=(int)(1L+Integer.toUnsignedLong((base==null?"yoru":base.key()).hashCode())%999999999L);a.id=String.valueOf(id);a.blocked=false;return a;}
    private Anime yoruDetails(Anime base,boolean episodes)throws Exception{
        Anime a=yoruShell(base);
        Future<Anime> yummyJob=ENRICH.submit(()->{try{return findYummy(base);}catch(Exception e){return null;}});
        Future<Anime> metaJob=null;
        int baseMal=a.malId;
        if(baseMal>0){
            final int mm=baseMal;
            metaJob=ENRICH.submit(()->{try{Anime sh=new Anime();sh.source="shikimori";sh.id=String.valueOf(mm);return details(sh,false);}catch(Exception e){return null;}});
        }
        Anime y=null;
        if(!episodes){
            try{y=yummyJob.get(50,TimeUnit.MILLISECONDS);if(y!=null)fillYoruMeta(a,y);}catch(Exception ignored){}
        }else if(yummyJob!=null&&yummyJob.isDone()){
            try{y=yummyJob.get();if(y!=null)fillYoruMeta(a,y);}catch(Exception ignored){}
        }
        if(episodes){
            YoruCache db=YoruApp.app()==null?null:YoruApp.app().cache;
            if(db!=null){
                try{
                    Anime cached=db.detail(a,24*60*60*1000L);
                    if(cached!=null&&!cached.episodeList.isEmpty()&&playableEpisodes(cached)>0){
                        a.episodeList.clear();
                        a.episodeList.addAll(cached.episodeList);
                        a.episodes=Math.max(a.episodes,a.episodeList.size());
                        fillYoruMeta(a,cached);
                        return remember(a);
                    }
                }catch(Exception ignored){}
            }
            if(a.episodeList.isEmpty()){
                ArrayList<Anime> found=yoruFoundSources(base,a,yummyJob);
                LinkedHashMap<String,Anime.Episode> map=new LinkedHashMap<>();
                for(Anime source:found)mergeYoruEpisodes(map,source);
                a.episodeList.clear();
                a.episodeList.addAll(map.values());
                a.episodeList.sort(Comparator.comparingDouble(e->e.number));
                a.episodes=Math.max(a.episodes,a.episodeList.size());
                appendFutureEpisodes(a);
                applyEpisodeVisuals(a);
                if(db!=null&&!a.episodeList.isEmpty())db.detail(a);
                if(a.episodeList.isEmpty()||playableEpisodes(a)<=0){
                    silentSweep(a,base);
                    if(db!=null&&!a.episodeList.isEmpty())db.detail(a);
                }
            }
        }
        Anime meta=null;
        if(metaJob!=null&&metaJob.isDone()){
            try{meta=metaJob.get();}catch(Exception ignored){}
        }else if(metaJob!=null&&!episodes){
            try{meta=metaJob.get(2000,TimeUnit.MILLISECONDS);}catch(Exception ignored){}
        }else if(!episodes){
            try{int mal=y==null?0:y.malId;if(mal>0){Anime sh=new Anime();sh.source="shikimori";sh.id=String.valueOf(mal);meta=details(sh,false);}}catch(Exception ignored){}
        }
        try{if(meta!=null){fillYoruMeta(a,meta);for(Anime r:meta.related)a.related.add(r);}}catch(Exception ignored){}
        return remember(a);
    }

    private void fillYoruMeta(Anime target,Anime source){if(target==null||source==null)return;if(target.title.isEmpty())target.title=source.title;if(target.original.isEmpty())target.original=source.original;if(target.alias.isEmpty())target.alias=source.alias;if(target.poster.isEmpty())target.poster=source.poster;if(target.description.isEmpty())target.description=source.description;if(target.year==0)target.year=source.year;if(target.type.isEmpty()||target.type.equals("Аниме"))target.type=source.type;if(target.status.isEmpty())target.status=source.status;if(target.age.isEmpty())target.age=source.age;if(target.studio.isEmpty())target.studio=source.studio;if(target.episodes==0)target.episodes=source.episodes;if(target.episodesAired==0)target.episodesAired=source.episodesAired;if(target.nextEpisodeAt.isEmpty())target.nextEpisodeAt=source.nextEpisodeAt;if(target.malId==0)target.malId=source.malId;if(target.anilistId==0)target.anilistId=source.anilistId;if(target.kpId==0)target.kpId=source.kpId;if(target.libriaAlias.isEmpty())target.libriaAlias=source.libriaAlias;if(target.score==0)target.score=source.score;if(target.trailerUrl.isEmpty())target.trailerUrl=source.trailerUrl;if(target.airedDate.isEmpty())target.airedDate=source.airedDate;for(String shot:source.screenshots)if(!shot.isEmpty()&&!target.screenshots.contains(shot)&&target.screenshots.size()<12)target.screenshots.add(shot);for(String g:source.genres)if(!target.genres.contains(g))target.genres.add(g);}
    private ArrayList<Anime> yoruFoundSources(Anime original,Anime shell,Future<Anime> yummyJob){
        ArrayList<Anime> out=new ArrayList<>();LinkedHashSet<String> seen=new LinkedHashSet<>();
        ArrayList<String> sources=SourceEngine.discoveryOrder(original,shell);String pref="";boolean concrete=false;
        try{pref=YoruApp.app().store.voicePreference();concrete=!voiceKey(pref).isEmpty();}catch(Exception ignored){}
        if(concrete){ArrayList<String> focused=new ArrayList<>();for(String s:sources)if(sourceLikelyHasVoice(s,pref))focused.add(s);for(String s:sources)if(!focused.contains(s))focused.add(s);sources=focused;}
        boolean isMobile=false;
        try{YoruApp app=YoruApp.app();if(app!=null&&app.traffic!=null)isMobile=app.traffic.mobile()||app.traffic.metered();}catch(Exception ignored){}
        ExecutorService pool=Executors.newFixedThreadPool(Math.max(2,Math.min(sources.size()+2,12)));
        CompletionService<Anime> done=new ExecutorCompletionService<>(pool);int jobs=0;
        if(!concrete||sourceLikelyHasVoice("yummy",pref)){done.submit(()->{try{Anime yy=yummyJob==null?null:yummyJob.get(20,TimeUnit.SECONDS);if(yy==null)return null;Anime full=details(yy,true);if(full==null||full.blocked||full.episodeList.isEmpty())return null;return full;}catch(Exception e){return null;}});jobs++;}
        for(String source:sources){done.submit(()->yoruFindSource(original,shell,source));jobs++;}
        long deadline=System.currentTimeMillis()+30000;
        try{for(int i=0;i<jobs;i++){long left=deadline-System.currentTimeMillis();if(left<=0)break;Future<Anime> f;try{f=done.poll(left,TimeUnit.MILLISECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}if(f==null)break;try{Anime a=f.get();if(a!=null&&!a.episodeList.isEmpty()&&seen.add(a.source+":"+a.id))out.add(a);}catch(Exception ignored){}}}finally{pool.shutdownNow();}
        out.sort(Comparator.comparingInt(a->1000-SourceEngine.score(a.source,a)));return out;
    }
    private boolean enoughYoruSources(ArrayList<Anime> rows,String pref,boolean concrete,Anime shell,boolean isMobile){if(rows==null||rows.isEmpty())return false;int episodes=0;for(Anime a:rows){episodes=Math.max(episodes,a==null?0:a.episodeList.size());}int target=shell==null?0:Math.max(shell.episodes,shell.episodesAired);int needEpisodes=target<=0?1:Math.min(target,6);return episodes>=needEpisodes;}
    private boolean hasPreferredVoice(Anime a,String pref){if(a==null||voiceKey(pref).isEmpty())return false;if(voiceMatches(pref,sourceVoice(a.source)))return true;for(Anime.Episode e:a.episodeList)for(Anime.Variant v:e.variants){String label=(v==null?"":v.name+" "+v.displayName+" "+v.player);if(voiceMatches(pref,label))return true;}return false;}
    private boolean sourceLikelyHasVoice(String source,String voice){String key=voiceKey(voice),s=SourceEngine.sourceId(source);if(key.isEmpty())return true;if(key.equals("anidub"))return s.equals("anidub")||s.equals("yummy")||s.equals("anixsekai")||s.equals("kodik");if(key.equals("animevost"))return s.equals("animevost")||s.equals("yummy")||s.equals("kodik");if(key.equals("animedia"))return s.equals("animedia")||s.equals("yummy")||s.equals("kodik");if(key.equals("anilibria"))return s.equals("anilibria")||s.equals("animelib")||s.equals("animelib4k")||s.equals("yummy");return s.equals("yummy")||s.equals("anixsekai")||s.equals("kodik")||s.equals("animetka");}
    private void silentSweep(Anime a,Anime base){if(a==null||playableEpisodes(a)>0)return;long deadline=System.currentTimeMillis()+30000;ArrayList<String> order=null;try{order=SourceEngine.playbackOrder(base==null?a:base);}catch(Exception e){return;}if(order==null)return;for(String source:order){if(source==null||source.equals("yoru")||System.currentTimeMillis()>=deadline)continue;Anime got=null;try{got=findPlayableSource(a,source);}catch(Exception ignored){}if(got==null||got.episodeList.isEmpty()||playableEpisodes(got)<=0)continue;LinkedHashMap<String,Anime.Episode> map=new LinkedHashMap<>();try{mergeYoruEpisodes(map,got);}catch(Exception ignored){}if(map.isEmpty())continue;a.episodeList.clear();a.episodeList.addAll(map.values());a.episodeList.sort(Comparator.comparingDouble(e->e.number));a.episodes=Math.max(a.episodes,a.episodeList.size());try{a.episodesAired=Math.max(a.episodesAired,playableEpisodes(a));}catch(Exception ignored){}try{appendFutureEpisodes(a);}catch(Exception ignored){}try{applyEpisodeVisuals(a);}catch(Exception ignored){}try{remember(a);}catch(Exception ignored){}YoruCache db=YoruApp.app()==null?null:YoruApp.app().cache;if(db!=null)try{db.detail(a);}catch(Exception ignored){}break;}}
    private Anime yoruFindSource(Anime original,Anime shell,String source){long started=System.currentTimeMillis();try{Anime candidate;if(source.equals("kodik"))candidate=kodikShell(shell);else if(source.equals("anixsekai"))candidate=findAnix(shell);else if(source.equals("anilibria"))candidate=findAniLiberty(shell);else if(source.equals("hanime"))candidate=findHanime(shell);else if(source.equals("animetka")||source.equals("anidub")||source.equals("animevost")||source.equals("animedia"))candidate=searchSource(shell,source);else candidate=searchSource(shell,source);if(candidate==null&&original!=null&&!original.source.equals("yoru")&&original.source.equals(source))candidate=original;if(candidate==null){SourceEngine.record(source,false,System.currentTimeMillis()-started,0,0,0);return null;}Anime full=(!candidate.episodeList.isEmpty()&&playableEpisodes(candidate)>0)?candidate:details(candidate,true);if(full.blocked||playableEpisodes(full)<=0){SourceEngine.record(source,false,System.currentTimeMillis()-started,0,0,0);return null;}SourceEngine.record(source,true,System.currentTimeMillis()-started,full.episodeList.size(),SourceEngine.optionCount(full),SourceEngine.maxQuality(full));return full;}catch(Exception e){SourceEngine.record(source,false,System.currentTimeMillis()-started,0,0,0);return null;}}
    private void mergeYoruEpisodes(LinkedHashMap<String,Anime.Episode> map,Anime source){
        String route=downloadSourceName(source.source);
        String fallbackVoice=sourceVoice(source.source);
        for(Anime.Episode e:source.episodeList){
            if(e==null||e.number<0||!Double.isFinite(e.number))continue;
            ArrayList<Anime.Variant> variants=new ArrayList<>();
            for(Map.Entry<Integer,String> stream:e.streams.entrySet()){
                String url=safeUrl(stream.getValue());
                if(url.isEmpty())continue;
                Anime.Variant v=new Anime.Variant(fallbackVoice,route,url);
                v.duration=e.duration;v.openingStart=e.openingStart;v.openingEnd=e.openingEnd;v.displayName=fallbackVoice;
                variants.add(v);
            }
            for(Anime.Variant row:e.variants){
                String url=embed(row.url);
                if(url.isEmpty())continue;
                String voice=variantVoiceLabel(row);
                String rowPlayer=cleanLabel(row.player);
                Anime.Variant v=new Anime.Variant(voice,rowPlayer.isEmpty()?route:route+" · "+rowPlayer,url);
                v.duration=row.duration;v.openingStart=row.openingStart;v.openingEnd=row.openingEnd;v.displayName=voice;
                variants.add(v);
            }
            if(variants.isEmpty())continue;
            String key=episodeParam(e.number);Anime.Episode ep=map.get(key);
            if(ep==null){ep=new Anime.Episode();ep.id="yoru-"+key;ep.number=e.number;ep.name="";ep.lazy="yoru";map.put(key,ep);}
            if(ep.poster.isEmpty()&&e.poster!=null&&!e.poster.isEmpty())ep.poster=e.poster;
            ep.duration=Math.max(ep.duration,e.duration);
            if(ep.openingEnd<=0&&e.openingEnd>0){ep.openingStart=e.openingStart;ep.openingEnd=e.openingEnd;}
            for(Anime.Variant v:variants)addVariant(ep,v);
            ep.variants.sort(Comparator.comparingInt(v->SourceEngine.variantRank(v)));
        }
    }
    private void loadYoruEpisode(Anime.Episode ep)throws Exception{if("yoru-ready".equals(ep.resolverUrl))return;if(ep.variants.isEmpty()&&!ep.streams.isEmpty()){ep.resolverUrl="yoru-ready";return;}ArrayList<Anime.Variant> sorted=SourceEngine.sortVariants(ep.variants);ArrayList<Anime.Variant> keep=new ArrayList<>();
        // Keep every valid variant belonging to this episode. The saved voice preference
        // only controls which one opens first; it must never hide the other real dubs from
        // the in-player voice menu.
        collectYoruVariants(sorted,keep,"",false);
        if(keep.isEmpty())throw new IOException("Tsuyu пока не нашёл доступные озвучки для этой серии");
        ep.variants.clear();for(Anime.Variant v:keep)addVariant(ep,v);ep.variants.sort(Comparator.comparingInt(v->SourceEngine.variantRank(v)));ep.resolverUrl="yoru-ready";}
    private static void collectYoruVariants(ArrayList<Anime.Variant> sorted,ArrayList<Anime.Variant> keep,String preferred,boolean strict){
        LinkedHashMap<String,Anime.Variant> unique=new LinkedHashMap<>();
        for(Anime.Variant v:sorted){
            if(v==null||v.url==null||v.url.isEmpty())continue;
            String label=v.name+" "+v.displayName+" "+v.player;
            if(strict&&!voiceMatches(preferred,label))continue;
            Anime.Variant old=unique.get(v.url);
            if(old==null||variantVoiceLabel(old).isEmpty()&&!variantVoiceLabel(v).isEmpty())unique.put(v.url,v);
        }
        for(Anime.Variant v:unique.values())keep.add(copyVariant(v));
    }
    private static Anime.Variant copyVariant(Anime.Variant v){Anime.Variant copy=new Anime.Variant(cleanLabel(v.name),cleanLabel(v.player),v.url);copy.displayName=cleanLabel(v.displayName);copy.duration=v.duration;copy.openingStart=v.openingStart;copy.openingEnd=v.openingEnd;return copy;}
    private static int yoruSourceRank(String source){if("yummy".equals(source))return 0;if("anixsekai".equals(source))return 1;if("anilibria".equals(source))return 2;if("animevost".equals(source))return 3;if("animetka".equals(source))return 4;if("kodik".equals(source))return 5;if("anidub".equals(source))return 6;if("animedia".equals(source))return 7;return 20;}
    private static int yoruVariantRank(Anime.Variant v){String p=((v==null?"":v.player)+" "+(v==null?"":v.name)+" "+(v==null?"":v.displayName)).toLowerCase(Locale.ROOT);int source=p.contains("yummyanime")?0:p.contains("anix")?1:p.contains("anilibria")||p.contains("aniliberty")?2:p.contains("animevost")?3:p.contains("animetka")?4:p.contains("kodik")?5:p.contains("anidub")?6:10;int player=p.contains("cvh")||p.contains("cdnvideohub")?0:p.contains("aksor")?1:p.contains("vk")||p.contains("вконт")?2:p.contains("rutube")?3:p.contains("zedfilm")||p.contains("hlamer")?4:p.contains("alloha")?5:p.contains("sibnet")?6:10;return source*100+player;}
    public ArrayList<AiringItem> airingSchedule(int days)throws Exception{return CalendarApi.airingSchedule(days,null,this);}
    public ArrayList<AiringItem> airingSchedule(int days,List<Anime> focus)throws Exception {return CalendarApi.airingSchedule(days,focus,this);}

    private Anime.Page animetkaCatalog(String search,int page,Filter f)throws Exception{Anime.Page out=new Anime.Page();out.page=page;String q=search==null?"":search.trim();int limit=24,offset=Math.max(0,(page-1)*limit);String url=q.isEmpty()?query("https://animetka.com/api/anime/top",params("limit",String.valueOf(limit),"offset",String.valueOf(offset))):query("https://animetka.com/api/anime/search",params("name",q,"limit",String.valueOf(limit),"offset",String.valueOf(offset)));JSONArray rows=new JSONArray(request(url,"GET",null,false,animetkaHeaders()));if(rows.length()==0&&!q.isEmpty())rows=new JSONArray(request(query("https://animetka.com/api/anime/search",params("q",q,"limit",String.valueOf(limit),"offset",String.valueOf(offset))),"GET",null,false,animetkaHeaders()));int end=Math.min(rows.length(),limit);for(int i=0;i<end;i++){Anime a=animetkaAnime(rows.getJSONObject(i));if(Anime.valid(a))out.items.add(remember(a));}out.more=rows.length()==limit;return out;}
    private Anime animetkaDetails(Anime base,boolean episodes)throws Exception{JSONObject d=new JSONObject(request("https://animetka.com/api/anime/"+enc(base.id),"GET",null,false,animetkaHeaders()));Anime a=animetkaAnime(d);if(!Anime.valid(a)){a=Anime.from(base.json());a.source="animetka";}JSONArray rel=d.optJSONArray("franchise");for(int i=0;rel!=null&&i<rel.length();i++){JSONObject r=rel.optJSONObject(i);if(r!=null){Anime item=animetkaAnime(r);if(Anime.valid(item)&&!item.id.equals(a.id))a.related.add(remember(item));}}if(episodes){LinkedHashMap<String,Anime.Episode> map=new LinkedHashMap<>();JSONObject lm=d.optJSONObject("AnilibriaMapping");JSONArray le=lm==null?null:lm.optJSONArray("episodes");for(int i=0;le!=null&&i<le.length();i++){JSONObject e=le.optJSONObject(i);if(e==null)continue;double n=e.optDouble("ordinal",i+1);String key=episodeParam(n);Anime.Episode ep=map.get(key);if(ep==null){ep=new Anime.Episode();ep.id=a.id+"-"+key;ep.number=n;ep.name=e.optString("name","");map.put(key,ep);}ep.duration=e.optInt("duration",ep.duration);putStream(ep,480,e.optString("hls_480"));putStream(ep,720,e.optString("hls_720"));putStream(ep,1080,e.optString("hls_1080"));JSONObject op=e.optJSONObject("opening");if(op!=null){ep.openingStart=op.optInt("start",ep.openingStart);ep.openingEnd=op.optInt("stop",ep.openingEnd);}}JSONArray rows=d.optJSONArray("Animes");HashMap<Integer,String> names=animetkaTranslationNames(d,rows);for(int i=0;rows!=null&&i<rows.length();i++){JSONObject row=rows.optJSONObject(i);if(row==null)continue;String link=embed(row.optString("link"));if(link.isEmpty())continue;int material=parseInt(a.id);int tid=row.optInt("translation",0),count=Math.max(row.optInt("episodes_total",0),row.optInt("episodes_aired",0));if(count<=0)count=a.episodes>0?a.episodes:1;if(row.optString("kodik_id").startsWith("movie-")||Uri.parse(link).getPath()!=null&&Uri.parse(link).getPath().startsWith("/video/"))count=1;count=Math.max(1,Math.min(250,count));String voice=voiceLabel(names.get(tid));String q=row.optString("quality","").replace("WEB-DLRip ","").trim();for(int n=1;n<=count;n++){String key=episodeParam(n);Anime.Episode ep=map.get(key);if(ep==null){ep=new Anime.Episode();ep.id=a.id+"-"+key;ep.number=n;map.put(key,ep);}String url=tid>0?animetkaPlaylistUrl(material,tid,n):animetkaEpisodeUrl(link,n);Anime.Variant v=new Anime.Variant(voice,"Animetka",url);v.displayName=voice.isEmpty()?"":voice+(q.isEmpty()?"":" · "+q);addVariant(ep,v);if(!link.isEmpty()){String fallback=animetkaEpisodeUrl(link,n);if(!fallback.equals(url)){Anime.Variant back=new Anime.Variant(voice,"Animetka",fallback);back.displayName=v.displayName;addVariant(ep,back);}}}}a.episodeList.clear();a.episodeList.addAll(map.values());a.episodeList.sort(Comparator.comparingDouble(e->e.number));a.episodesAired=Math.max(a.episodesAired,playableEpisodes(a));a.episodes=Math.max(a.episodes,a.episodeList.size());}return remember(a);}
    private HashMap<Integer,String> animetkaTranslationNames(JSONObject detail,JSONArray rows){HashMap<Integer,String> out=new HashMap<>();int material=detail.optInt("id",detail.optInt("animetka_id",0)),tid=0;for(int i=0;rows!=null&&i<rows.length();i++){JSONObject row=rows.optJSONObject(i);if(row!=null&&row.optInt("translation",0)>0){tid=row.optInt("translation");break;}}if(material<=0||tid<=0)return out;try{JSONObject p=new JSONObject(request(query("https://animetka.com/api/anime/playlist",params("material",String.valueOf(material),"tid",String.valueOf(tid))),"GET",null,false,animetkaHeaders()));JSONArray list=p.optJSONArray("translations");for(int i=0;list!=null&&i<list.length();i++){JSONObject t=list.optJSONObject(i);if(t!=null)out.put(t.optInt("value",t.optInt("id",0)),t.optString("name",t.optString("title","")));}}catch(Exception ignored){}return out;}
    private static String animetkaEpisodeUrl(String link,int episode){try{Uri u=Uri.parse(link);String path=u.getPath();if(path!=null&&path.startsWith("/video/"))return link;return u.buildUpon().appendQueryParameter("episode",String.valueOf(episode)).build().toString();}catch(Exception e){return link;}}
    private static String animetkaPlaylistUrl(int material,int tid,int episode){return query("https://animetka.com/api/anime/playlist",params("material",String.valueOf(material),"tid",String.valueOf(tid),"episode",String.valueOf(episode)));}
    private static void addVariant(Anime.Episode ep,Anime.Variant v){
        if(ep==null||v==null||v.url==null||v.url.isEmpty())return;
        for(int i=0;i<ep.variants.size();i++){
            Anime.Variant old=ep.variants.get(i);
            if(old!=null&&old.url.equals(v.url)){
                if(variantVoiceLabel(old).isEmpty()&&!variantVoiceLabel(v).isEmpty())ep.variants.set(i,v);
                return;
            }
        }
        ep.variants.add(v);
    }
    private static HashMap<String,String> animetkaHeaders(){HashMap<String,String> h=new HashMap<>();h.put("Accept","application/json,text/plain,*/*");h.put("Accept-Language","ru-RU,ru;q=0.9,en;q=0.5");h.put("Origin","https://animetka.com");h.put("Referer","https://animetka.com/");h.put("User-Agent","Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36");return h;}

    private Anime.Page anidubCatalog(String search,int page)throws Exception{Anime.Page out=new Anime.Page();out.page=page;String q=search==null?"":search.trim();String url=q.isEmpty()?(page<=1?"https://online.anidub.com/":"https://online.anidub.com/page/"+page+"/"):query("https://online.anidub.com/index.php",params("do","search","subaction","search","story",q));Document doc=Jsoup.parse(document(url),url);LinkedHashMap<String,Anime> map=new LinkedHashMap<>();for(Element a:doc.select("a[href]")){String href=absolute(url,a.attr("href"));if(href.isEmpty()||href.contains("/user/")||href.contains("/anidub_news/")||!Pattern.compile("/(\\d+)-[^/]+\\.html(?:$|[?#])").matcher(href).find())continue;Element scope=cardScope(a);String title=anchorTitle(a);if(title.isEmpty()||title.length()<2||title.matches("[+\\-]?[0-9.]+"))continue;Anime item=anidubShell(href,title,posterFrom(url,scope),scope==null?title:scope.text());if(q.isEmpty()||matchesQuery(item,q))putBetter(map,item);if(map.size()>=24)break;}out.items.addAll(map.values());out.more=q.isEmpty()&&out.items.size()>=18;return out;}
    private Anime anidubDetails(Anime base,boolean episodes)throws Exception{String url=sourceUrl(base);String html=document(url);Document doc=Jsoup.parse(html,url);Anime a=anidubShell(url,heading(doc,base.title),posterFrom(url,doc),doc.text());String desc=descriptionFrom(doc);if(!desc.isEmpty())a.description=desc;for(Element g:doc.select("a[href*=/xfsearch/genre/],a[href*=/genre/]") ){String t=cleanText(g.text());if(!t.isEmpty()&&!a.genres.contains(t))a.genres.add(t);}if(episodes){LinkedHashMap<String,Anime.Episode> map=new LinkedHashMap<>();anidubOptions(doc,html,url,"sel","Sibnet",map,a.id);anidubOptions(doc,html,url,"sel2","AniDUB",map,a.id);anidubOptions(doc,html,url,"sel3","Stormo",map,a.id);if(map.isEmpty())anidubDirectFallback(a,html,url);else{a.episodeList.clear();a.episodeList.addAll(map.values());a.episodeList.sort(Comparator.comparingDouble(e->e.number));a.episodes=Math.max(a.episodes,a.episodeList.size());}}return remember(a);}



    private void anidubOptions(Document doc,String html,String page,String id,String player,LinkedHashMap<String,Anime.Episode> map,String baseId){for(Element o:doc.select("#"+id+" option"))anidubOption(page,player,o.attr("value"),o.text(),map,baseId);Matcher box=Pattern.compile("<select[^>]+id=[\\\"']"+Pattern.quote(id)+"[\\\"'][^>]*>(.*?)</select>",Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(html);while(box.find()){Matcher m=Pattern.compile("<option[^>]+value=[\\\"']([^\\\"']+)[\\\"'][^>]*>(.*?)</option>",Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(box.group(1));while(m.find())anidubOption(page,player,unescape(m.group(1)),plain(m.group(2)),map,baseId);}}
    private void anidubOption(String page,String suggested,String value,String label,LinkedHashMap<String,Anime.Episode> map,String baseId){String v=unescape(value);if(v.isEmpty())return;int cut=v.lastIndexOf('|');String raw=cut>0?v.substring(0,cut):v,num=cut>0?v.substring(cut+1):label;String provider=absolute(page,raw);if(provider.isEmpty())return;double n=numberIn(num+" "+label,map.size()+1);if(n<=0||!Double.isFinite(n))n=map.size()+1;String key=episodeParam(n);Anime.Episode ep=map.get(key);if(ep==null){ep=new Anime.Episode();ep.id=baseId+"-"+key;ep.number=n;ep.name="AniDUB";ep.lazy="anidub";map.put(key,ep);}String h=hostName(provider).toLowerCase(Locale.ROOT),p=suggested;if(h.contains("sibnet"))p="Sibnet";else if(h.contains("stormo"))p="Stormo";else if(h.contains("ladony")||provider.contains("vid.php"))p="AniDUB";Anime.Variant variant=new Anime.Variant("AniDUB",p,provider);variant.displayName="AniDUB · "+p;addVariant(ep,variant);}
    private void anidubDirectFallback(Anime a,String html,String page){Matcher m=Pattern.compile("https?:\\\\?/\\\\?/[^\\\"'<>\\s]+?(?:\\.m3u8|\\.mp4|\\.mpd)[^\\\"'<>\\s]*",Pattern.CASE_INSENSITIVE).matcher(html);Anime.Episode ep=null;while(m.find()){String safe=safeUrl(m.group().replace("\\/","/"));if(safe.isEmpty())continue;if(ep==null){ep=new Anime.Episode();ep.id=a.id+"-1";ep.number=1;ep.name="AniDUB";a.episodeList.add(ep);}putStream(ep,VideoResolver.qualityOf(safe),safe);}if(ep!=null){a.episodes=Math.max(a.episodes,1);return;}Matcher iframe=Pattern.compile("<(?:iframe|embed)[^>]+src=[\\\"']([^\\\"']+)[\\\"']",Pattern.CASE_INSENSITIVE).matcher(html);while(iframe.find()){String u=embed(absolute(page,iframe.group(1)));if(u.isEmpty())continue;if(ep==null){ep=new Anime.Episode();ep.id=a.id+"-1";ep.number=1;ep.name="AniDUB";ep.lazy="anidub";a.episodeList.add(ep);}Anime.Variant v=new Anime.Variant("AniDUB",hostName(u),u);v.displayName="AniDUB · "+hostName(u);addVariant(ep,v);}if(ep!=null)a.episodes=Math.max(a.episodes,1);}
    private static boolean badTitle(String title){String t=title==null?"":title.trim();if(t.length()<2||t.length()>120)return true;if(!Pattern.compile("[\\p{L}]").matcher(t).find())return true;String compact=t.replaceAll("[\\s_.-]","");boolean cyr=Pattern.compile("[А-Яа-яЁё]").matcher(t).find();boolean token=compact.length()>18&&compact.matches("[A-Za-z0-9+/=_]+")&&compact.matches(".*[0-9+/=_].*");return token&&!cyr;}
    private static Anime anidubShell(String url,String title,String poster,String meta){Anime a=new Anime();a.source="anidub";Matcher m=Pattern.compile("/(\\d+)-[^/]+\\.html").matcher(url);a.id=m.find()?m.group(1):stableId(url);a.alias=safeUrl(url);fillNames(a,title);a.poster=safeUrl(poster);a.year=yearIn(meta);a.episodes=episodesIn(meta+" "+title);a.status=meta!=null&&meta.toLowerCase(Locale.ROOT).contains("онгоинг")?"ongoing":"released";return a;}
    private static void fillNames(Anime a,String title){String t=cleanTitle(title);if(t.isEmpty())t="Аниме";String[] parts=t.split("\\s*/\\s*",2);a.title=parts[0].trim();if(parts.length>1)a.original=parts[1].replaceAll("\\s*\\[[^\\]]*\\]\\s*$","").trim();}
    private static String cleanTitle(String raw){String t=plain(raw).replace('\u00a0',' ').trim();if(t.contains("\n"))for(String row:t.split("\\r?\\n")){row=row.trim();if(row.length()>1){t=row;break;}}t=t.replaceAll("\\s+"," ").trim();t=t.replaceFirst("(?iu)^смотреть\\s+","").replaceFirst("(?iu)^постер\\s+аниме\\s+","");t=t.replaceAll("(?iu)\\s+все\\s+серии(?:\\s+и\\s+сезоны)?$","");t=t.replaceAll("\\s*\\[[^\\]]*\\]\\s*$","");return t.trim();}
    private static String cleanText(String raw){return plain(raw).replace('\u00a0',' ').replaceAll("\\s+"," ").trim();}
    private static String anchorTitle(Element a){String[] values={a.attr("title"),a.select("img[alt]").attr("alt"),a.ownText(),a.text()};for(String v:values){String t=cleanTitle(v);if(!t.isEmpty()&&!t.equalsIgnoreCase("смотреть")&&!t.matches("[+\\-]?[0-9.]+"))return t;}return "";}
    private static Element cardScope(Element a){Element s=a;for(int i=0;i<5&&s!=null;i++){String cls=s.className().toLowerCase(Locale.ROOT);if(cls.contains("short")||cls.contains("th-")||cls.contains("item")||cls.contains("movie")||cls.contains("anime")||cls.contains("story")||!s.select("img[src]").isEmpty())return s;s=s.parent();}return a.parent()==null?a:a.parent();}
    private static String posterFrom(String base,Element scope){if(scope==null)return "";String best="";for(Element img:scope.select("img[src],img[data-src],img[data-original]")){String src=first(first(img.attr("data-src"),img.attr("data-original")),img.attr("src"));String safe=absolute(base,src);String low=safe.toLowerCase(Locale.ROOT);if(safe.isEmpty()||low.contains("logo")||low.contains("banner")||low.contains("avatar")||low.contains("transparent"))continue;best=safe;if(low.contains("poster")||low.contains("uploads/posts")||low.contains("previews"))break;}if(!best.isEmpty())return best;Matcher bg=Pattern.compile("url\\(['\\\"]?([^)'\\\"]+)",Pattern.CASE_INSENSITIVE).matcher(scope.attr("style"));return bg.find()?absolute(base,bg.group(1)):"";}
    private static String heading(Document doc,String fallback){for(Element h:doc.select("h1,h2,h3")){String t=cleanTitle(h.text());String l=t.toLowerCase(Locale.ROOT);if(t.length()>2&&!l.startsWith("описание")&&!l.contains("комментар")&&!l.contains("смотреть онлайн"))return t;}String title=cleanTitle(doc.title());return title.isEmpty()?fallback:title.replaceAll("(?iu)\\s+смотреть.*$","").trim();}
    private static String descriptionFrom(Document doc){for(String sel:new String[]{"[itemprop=description]",".description",".full-text",".story",".quote",".entry","p"})for(Element e:doc.select(sel)){String t=cleanText(e.text());String l=t.toLowerCase(Locale.ROOT);if(t.length()>80&&!l.contains("зарегистриру")&&!l.contains("комментар")&&!l.contains("донат"))return t.length()>1200?t.substring(0,1200):t;}return "";}
    private void putBetter(LinkedHashMap<String,Anime> map,Anime a){if(!Anime.valid(a))return;Anime old=map.get(a.id);if(old==null||a.title.length()<old.title.length()||old.poster.isEmpty()&&!a.poster.isEmpty())map.put(a.id,remember(a));}
    private static boolean matchesQuery(Anime a,String q){String n=plainName(q);if(n.isEmpty())return true;String title=plainName(a.title+" "+a.original+" "+a.alias);return title.contains(n)||n.contains(plainName(a.title))||(!a.original.isEmpty()&&n.contains(plainName(a.original)));}
    private static String sourceUrl(Anime base)throws Exception{String u=safeUrl(base.alias);if(!u.isEmpty())return u;throw new IOException("У каталога нет адреса страницы");}
    private static String stableId(String value){long h=Integer.toUnsignedLong((value==null?"":value).hashCode());return String.valueOf(1000000000L+h%8999999999L);}
    private static int yearIn(String text){Matcher m=Pattern.compile("(?:^|[^0-9])((?:19|20)[0-9]{2})(?:[^0-9]|$)").matcher(text==null?"":text);try{return m.find()?Integer.parseInt(m.group(1)):0;}catch(Exception e){return 0;}}
    private static int episodesIn(String text){String s=text==null?"":text;String[] patterns={"из\\s*(\\d{1,4})","(\\d{1,4})\\s*сер(?:ия|ии|ий)","Серии?:\\s*[^0-9]*(\\d{1,4})"};for(String p:patterns){Matcher m=Pattern.compile(p,Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(s);if(m.find())try{return Integer.parseInt(m.group(1));}catch(Exception ignored){}}return 0;}
    private static String episodeTitle(String text,int fallback){String t=cleanText(text);if(t.isEmpty())return "Серия "+fallback;t=t.replaceFirst("(?iu)^смотреть\\s+","");return t.length()>120?t.substring(0,120):t;}
    private static String latinSlug(String text){String s=(text==null?"":text).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+","-").replaceAll("^-+|-+$","");return s.matches(".*[a-z].*")?s:"";}
    private static String findText(String input,String regex){Matcher m=Pattern.compile(regex,Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE|Pattern.DOTALL).matcher(input==null?"":input);return m.find()?cleanText(unescape(m.group(1))):"";}
    private static String unescape(String s){return s==null?"":s.replace("&quot;","\"").replace("&#34;","\"").replace("&#039;","'").replace("&amp;","&").replace("\\/","/");}


    private Anime.Page anixCatalog(String search,int page,Filter f)throws Exception{Anime.Page out=new Anime.Page();out.page=page;String q=search==null?"":search.trim();JSONObject body=new JSONObject();body.put("sort",f!=null&&"POPULARITY".equals(f.sort)?2:1);body.put("age_rating",new JSONArray());body.put("genres",new JSONArray());body.put("years",new JSONArray());body.put("seasons",new JSONArray());body.put("types",new JSONArray());body.put("statuses",new JSONArray());body.put("countries",new JSONArray());if(!q.isEmpty()){body.put("search",q);body.put("query",q);body.put("title",q);}if(f!=null&&!f.year.isEmpty())body.getJSONArray("years").put(parseInt(f.year));JSONObject root=anixPost("/filter/"+Math.max(0,page-1),body);JSONArray rows=firstArray(root,"releases","content","data","list","items");for(int i=0;rows!=null&&i<rows.length();i++){JSONObject row=rows.optJSONObject(i);if(row==null)continue;Anime a=anixAnime(row);if(Anime.valid(a)&&(q.isEmpty()||matchesQuery(a,q)))out.items.add(remember(a));if(out.items.size()>=24)break;}out.more=rows!=null&&rows.length()>=24;return out;}
    private Anime anixDetails(Anime base,boolean episodes)throws Exception{JSONObject root=anixGet("/release/"+enc(base.id));JSONObject row=firstObject(root,"release","data","item");Anime a=row==null?Anime.from(base.json()):anixAnime(row);if(!Anime.valid(a)){a=Anime.from(base.json());a.source="anixsekai";}if(episodes){LinkedHashMap<String,Anime.Episode> map=new LinkedHashMap<>();JSONArray types=firstArray(anixGet("/episode/"+enc(a.id)),"types","data","items");ArrayList<JSONObject> list=new ArrayList<>();for(int i=0;types!=null&&i<types.length();i++){JSONObject t=types.optJSONObject(i);if(t==null)continue;String voice=voiceLabel(t.optString("name",t.optString("title","")));if(voice.isEmpty())continue;list.add(t);}String pref="";boolean strict=false;try{pref=YoruApp.app().store.voicePreference();strict=false;}catch(Exception ignored){}final String wanted=pref;list.sort((x,y)->{String xv=voiceLabel(x.optString("name",x.optString("title",""))),yv=voiceLabel(y.optString("name",y.optString("title","")));int xs=!wanted.isEmpty()&&voiceMatches(wanted,xv)?0:1,ys=!wanted.isEmpty()&&voiceMatches(wanted,yv)?0:1;if(xs!=ys)return xs-ys;int xc=x.optInt("episodes_count",0),yc=y.optInt("episodes_count",0);return yc-xc;});for(JSONObject type:list){String voice=voiceLabel(type.optString("name",type.optString("title","")));if(strict&&!voiceMatches(pref,voice))continue;int typeId=type.optInt("id",0);if(typeId<=0)continue;JSONObject srcRoot;try{srcRoot=anixGet("/episode/"+enc(a.id)+"/"+typeId);}catch(Exception ignored){continue;}JSONArray sources=firstArray(srcRoot,"sources","data","items");JSONObject source=chooseAnixSource(sources);if(source==null)continue;int sourceId=source.optInt("id",0);if(sourceId<=0)continue;JSONObject epRoot;try{epRoot=anixGet("/episode/"+enc(a.id)+"/"+typeId+"/"+sourceId);}catch(Exception ignored){continue;}JSONArray eps=firstArray(epRoot,"episodes","data","items");for(int i=0;eps!=null&&i<eps.length();i++){JSONObject e=eps.optJSONObject(i);if(e==null)continue;String url=embed(e.optString("url",e.optString("link",e.optString("iframe_url",""))));if(url.isEmpty())continue;double n=e.optDouble("position",e.optDouble("episode",e.optDouble("number",i+1)));if(!Double.isFinite(n)||n<0)n=i+1;String key=episodeParam(n);Anime.Episode ep=map.get(key);if(ep==null){ep=new Anime.Episode();ep.id=a.id+"-"+key;ep.number=n;ep.name=e.optString("title",e.optString("name",""));map.put(key,ep);}ep.lazy="anixsekai";if(ep.poster.isEmpty())ep.poster=anixImage(bestImage(e));ep.duration=Math.max(ep.duration,e.optInt("duration",0));Anime.Variant v=new Anime.Variant(voice,"AnixSekai",url);v.displayName=voice;addVariant(ep,v);}}a.episodeList.clear();a.episodeList.addAll(map.values());a.episodeList.sort(Comparator.comparingDouble(e->e.number));a.episodesAired=Math.max(a.episodesAired,playableEpisodes(a));a.episodes=Math.max(a.episodes,a.episodeList.size());}return remember(a);}
    private JSONObject chooseAnixSource(JSONArray sources){JSONObject first=null,kodik=null;for(int i=0;sources!=null&&i<sources.length();i++){JSONObject s=sources.optJSONObject(i);if(s==null)continue;String name=s.optString("name",s.optString("title","")).toLowerCase(Locale.ROOT);if(first==null)first=s;if(s.optInt("id",0)==12||name.contains("kodik")){kodik=s;break;}}return kodik!=null?kodik:first;}
    private Anime findAnix(Anime a)throws Exception{normalizeIds(a);Anime best=null;for(String q:searchTerms(a)){Anime.Page page=anixCatalog(q,1,new Filter());for(Anime item:page.items){if(matchesAnime(item,a))return item;if(best==null&&matchesQuery(item,q))best=item;}}return best;}
    private JSONObject anixGet(String path)throws Exception{Exception last=null;for(String base:ANIX_BASES)try{return anixOk(request(base+path,"GET",null,false,anixHeaders(base)));}catch(Exception e){last=e;}if(last!=null)throw last;throw new IOException("Tsuyu не ответил");}
    private JSONObject anixPost(String path,JSONObject body)throws Exception{Exception last=null;for(String base:ANIX_BASES)try{return anixOk(request(base+path,"POST",body.toString(),false,anixHeaders(base)));}catch(Exception e){last=e;}if(last!=null)throw last;throw new IOException("Tsuyu не ответил");}
    private JSONObject anixOk(String text)throws Exception{JSONObject root=new JSONObject(text);if(root.has("code")&&root.optInt("code",0)!=0)throw new IOException("Tsuyu временно недоступен");return root;}
    private static HashMap<String,String> anixHeaders(String base){HashMap<String,String> h=new HashMap<>();h.put("Accept","application/json");h.put("User-Agent",ANIX_UA);h.put("Origin",base);h.put("Referer",base+"/");h.put("Accept-Language","ru-RU,ru;q=0.9,en;q=0.5");return h;}
    private static JSONArray firstArray(JSONObject root,String...keys){if(root==null)return null;for(String k:keys){JSONArray a=root.optJSONArray(k);if(a!=null)return a;JSONObject o=root.optJSONObject(k);if(o!=null){JSONArray nested=firstArray(o,"releases","content","data","list","items","types","sources","episodes");if(nested!=null)return nested;}}return null;}
    private static JSONObject firstObject(JSONObject root,String...keys){if(root==null)return null;for(String k:keys){JSONObject o=root.optJSONObject(k);if(o!=null)return o;}return null;}
    private static Anime anixAnime(JSONObject j){Anime a=new Anime();a.source="anixsekai";a.id=j.optString("id",j.optString("releaseId"));a.title=j.optString("title_ru",j.optString("title",j.optString("name","Аниме")));a.original=j.optString("title_original",j.optString("title_en",j.optString("title_alt","")));a.alias=j.optString("alias",j.optString("code",""));a.description=plain(j.optString("description",j.optString("annotation","")));String poster=j.optString("poster",j.optString("image",j.optString("image_url",j.optString("poster_url",j.optString("screenshot","")))));a.poster=anixImage(poster);a.trailerUrl=safeUrl(j.optString("trailer",j.optString("trailer_url",j.optString("youtube_url",""))));addScreenshot(a,anixImage(j.optString("screenshot",j.optString("frame",""))));JSONArray shots=j.optJSONArray("screenshots");for(int i=0;shots!=null&&i<shots.length();i++)addScreenshot(a,anixImage(imageFrom(shots.opt(i))));a.airedDate=j.optString("aired_on",j.optString("release_date",j.optString("date","")));a.year=j.optInt("year",yearIn(j.optString("aired_on",j.optString("season",""))));a.type=kind(j.optString("type",j.optString("category","")));a.status=j.optString("status",j.optString("publish_status",""));a.episodes=j.optInt("episodes_total",j.optInt("episodes_count",j.optInt("episodes",j.optInt("episode_count",0))));a.episodesAired=j.optInt("episodes_aired",j.optInt("episodesAired",0));a.score=j.optDouble("grade",j.optDouble("rating",j.optDouble("score",0)));a.age=j.optInt("age_rating",0)>0?j.optInt("age_rating")+"+":"";a.malId=j.optInt("myanimelist_id",j.optInt("mal_id",j.optInt("malId",0)));a.anilistId=j.optInt("anilist_id",j.optInt("anilistId",0));genres(a,j.optJSONArray("genres"),"name");genres(a,j.optJSONArray("categories"),"name");return a;}
    private static String anixImage(String raw){String s=raw==null?"":raw.trim().replace("\\/","/");if(s.isEmpty()||s.equals("null"))return "";if(s.startsWith("http"))return safeUrl(s);if(s.startsWith("//"))return safeUrl("https:"+s);if(s.startsWith("/"))return safeUrl("https://api-s.anixsekai.com"+s);return safeUrl(s);}


    private void enrichSchedule(Anime a){ShikimoriApi.enrichSchedule(a,this);}
    private static int playableEpisodes(Anime a){
        int n=0;
        if(a!=null)for(Anime.Episode e:a.episodeList){
            if(e==null||e.future)continue;
            boolean namedVariant=false;
            for(Anime.Variant v:e.variants)if(!variantVoiceLabel(v).isEmpty()){namedVariant=true;break;}
            boolean lazy=e.lazy!=null&&!e.lazy.isEmpty()&&!"future".equals(e.lazy);
            boolean content=!e.streams.isEmpty()||namedVariant
                    ||(lazy&&!"yoru".equals(e.lazy))
                    ||(e.resolverUrl!=null&&!e.resolverUrl.isEmpty());
            if(content)n++;
        }
        return n;
    }
    private static void appendFutureEpisodes(Anime a){if(a==null||a.episodes<=0||a.episodeList.isEmpty())return;if(a.finished()){int have=a.episodesAired;if(have>0&&a.episodeList.size()>=have&&a.episodes>have)a.episodes=have;return;}boolean incomplete=a.episodesAired>0&&a.episodesAired<a.episodes;boolean scheduled=!a.nextEpisodeAt.isEmpty()&&!"null".equalsIgnoreCase(a.nextEpisodeAt);if(!a.ongoing()&&!incomplete&&!scheduled)return;int playable=0;for(Anime.Episode e:a.episodeList){if(e==null)continue;if(!e.streams.isEmpty()||!e.variants.isEmpty()||(e.lazy!=null&&!e.lazy.isEmpty()&&!"future".equals(e.lazy))||(e.resolverUrl!=null&&!e.resolverUrl.isEmpty()))e.future=false;if(!e.future)playable++;}if(playable<=0)return;int aired=incomplete?a.episodesAired:Math.max(a.episodesAired,playable);if(aired<=0&&playable>0)aired=playable;if(aired>=a.episodes){a.episodesAired=Math.max(a.episodesAired,a.episodes);return;}a.episodesAired=aired;LinkedHashSet<String> have=new LinkedHashSet<>();for(Anime.Episode e:a.episodeList){if(e==null)continue;String key=episodeParam(e.number);have.add(key);if(e.number>aired+0.001&&e.streams.isEmpty()&&e.variants.isEmpty()&&(e.lazy==null||e.lazy.isEmpty()||"future".equals(e.lazy))&&(e.resolverUrl==null||e.resolverUrl.isEmpty()))markFuture(e,(int)Math.round(e.number)==aired+1?formatAirDate(a.nextEpisodeAt):"Дата уточняется");}int max=a.episodes-aired>24?Math.min(a.episodes,aired+24):a.episodes;for(int n=aired+1;n<=max;n++){String key=episodeParam(n);if(have.contains(key))continue;Anime.Episode ep=new Anime.Episode();ep.id=(a.id==null||a.id.isEmpty()?"future":a.id)+"-future-"+n;ep.number=n;markFuture(ep,n==aired+1?formatAirDate(a.nextEpisodeAt):"Дата уточняется");a.episodeList.add(ep);}}
    private static void markFuture(Anime.Episode ep,String date){if(ep==null)return;String label=date==null||date.trim().isEmpty()?"Дата уточняется":date.trim();ep.future=true;ep.airDate=label;ep.name=label;ep.poster="";ep.lazy="";ep.resolverUrl="";ep.duration=0;ep.openingStart=0;ep.openingEnd=0;ep.streams.clear();ep.variants.clear();}
    private static String formatAirDate(String raw){String v=raw==null?"":raw.trim();if(v.isEmpty()||v.equals("null"))return "Дата уточняется";try{return "Выйдет "+dateLabel(OffsetDateTime.parse(v).atZoneSameInstant(MSK_ZONE).toLocalDateTime());}catch(Exception ignored){}try{return "Выйдет "+dateLabel(Instant.parse(v).atZone(MSK_ZONE).toLocalDateTime());}catch(Exception ignored){}try{return "Выйдет "+dateLabel(LocalDateTime.parse(v));}catch(Exception ignored){}return "Выйдет "+v.replace('T',' ');}
    private static String dateLabel(LocalDateTime t){String[] m={"янв","фев","мар","апр","мая","июн","июл","авг","сен","окт","ноя","дек"};return String.format(Locale.ROOT,"%d %s, %02d:%02d",t.getDayOfMonth(),m[Math.max(0,Math.min(11,t.getMonthValue()-1))],t.getHour(),t.getMinute());}
    String shikiText(String path)throws Exception{return ShikimoriApi.shikiText(path,this);}
    JSONArray shikiArray(String path)throws Exception{return ShikimoriApi.shikiArray(path,this);}
    public ArrayList<String> screenshotsOf(Anime a)throws Exception{return ShikimoriApi.screenshotsOf(a,this);}
    private void enrichVisuals(Anime a){ShikimoriApi.enrichVisuals(a,this);}
    private void enrichRelated(Anime a){ShikimoriApi.enrichRelated(a,this);}
    static String shikiImage(String raw){return ShikimoriApi.shikiImage(raw);}
    private static void applyEpisodeVisuals(Anime a){
        if(a==null)return;
        int shots=a.screenshots.size();
        for(int i=0;i<a.episodeList.size();i++){
            Anime.Episode ep=a.episodeList.get(i);
            if(ep==null)continue;
            if(ep.future){ep.poster="";continue;}
            if(ep.poster.equals(a.poster))ep.poster="";
            if(ep.poster.isEmpty()&&shots>0)ep.poster=a.screenshots.get(i%shots);
            if(ep.duration<=0&&a.type.toLowerCase(Locale.ROOT).contains("фильм"))ep.duration=90*60;
        }
    }
    private static void addScreenshot(Anime a,String url){String safe=safeUrl(url);if(a!=null&&!safe.isEmpty()&&!a.screenshots.contains(safe)&&a.screenshots.size()<12)a.screenshots.add(safe);}
    private static String bestImage(JSONObject j){if(j==null)return "";String[] keys={"preview","preview_url","thumbnail","thumbnail_url","screenshot","screenshot_url","image","image_url","poster","poster_url","frame","frame_url","cover","cover_url"};for(String key:keys){String v=j.optString(key,"");String s=safeUrl(v);if(!s.isEmpty())return s;if(v.startsWith("/"))return v;JSONObject o=j.optJSONObject(key);if(o!=null){String x=bestImage(o);if(!x.isEmpty())return x;}}return "";}
    private static String imageFrom(Object value){if(value instanceof JSONObject)return bestImage((JSONObject)value);if(value instanceof String)return (String)value;return "";}

    private Anime.Page animelib4kCatalog(String search,int page,Filter f)throws Exception{Anime.Page base=catalog("animelib",search,page,f);Anime.Page out=new Anime.Page();out.page=base.page;out.total=base.total;out.more=base.more;for(Anime a:base.items){Anime copy=Anime.from(a.json());copy.source="animelib4k";out.items.add(remember(copy));}return out;}
    private Anime.Page kodikCatalog(String search,int page,Filter f)throws Exception{Anime.Page base=catalog("shikimori",search,page,f);Anime.Page out=new Anime.Page();out.page=base.page;out.total=base.total;out.more=base.more;for(Anime a:base.items)out.items.add(remember(kodikShell(a)));return out;}
    private Anime kodikShell(Anime base){return SourceResolver.kodikShell(base);}
    private Anime kodikDetails(Anime base,boolean episodes)throws Exception{return SourceResolver.kodikDetails(base,episodes,this);}
    static int parseInt(String s){try{return Integer.parseInt(s==null?"0":s.replaceAll("\\D+",""));}catch(Exception e){return 0;}}
    private Anime findAniLiberty(Anime a)throws Exception{
        normalizeIds(a);
        String alias=a.libriaAlias;
        if(alias.isEmpty()){
            try{Anime y=findYummy(a);if(y!=null&&!y.libriaAlias.isEmpty())alias=y.libriaAlias;}catch(Exception ignored){}
        }
        if(!alias.isEmpty())return libriaAnime(get("https://anilibria.top/api/v1/anime/releases/"+enc(alias)));
        return searchSource(a,"anilibria");
    }
    private Anime searchSource(Anime a,String source)throws Exception{for(String term:searchTerms(a)){Anime.Page page=catalog(source,term,1,new Filter());for(Anime item:page.items)if(matchesAnime(item,a))return item;}return null;}
    static boolean matchesAnime(Anime candidate,Anime base){if(candidate==null||base==null)return false;if(candidate.malId>0&&base.malId>0&&candidate.malId==base.malId)return true;if(candidate.anilistId>0&&base.anilistId>0&&candidate.anilistId==base.anilistId)return true;String bt=plainName(base.title),bo=plainName(base.original),ct=plainName(candidate.title),co=plainName(candidate.original);boolean title=(!bt.isEmpty()&&(bt.equals(ct)||bt.equals(co)))||(!bo.isEmpty()&&(bo.equals(ct)||bo.equals(co)));if(!title&&("anidub".equals(candidate.source)))title=(!bt.isEmpty()&&(ct.contains(bt)||bt.contains(ct)))||(!bo.isEmpty()&&(co.contains(bo)||bo.contains(co)||ct.contains(bo)));return title&&(base.year==0||candidate.year==0||Math.abs(base.year-candidate.year)<=1);}
    static LinkedHashSet<String> searchTerms(Anime a){LinkedHashSet<String> terms=new LinkedHashSet<>();ArrayList<String> raw=new ArrayList<>();if(a!=null){raw.add(a.title);raw.add(a.original);raw.add(a.alias);}for(String value:raw){if(value==null)continue;String v=value.trim();if(v.isEmpty()||v.length()>160||v.contains("/")&&v.startsWith("http"))continue;addSearchTerm(terms,v);addSearchTerm(terms,trimSearchNoise(v));int cut=v.indexOf('/');if(cut>1)addSearchTerm(terms,v.substring(0,cut));Matcher m=Pattern.compile("(.+?)(?:\\s+[-–—:]\\s+.+)$").matcher(v);if(m.find())addSearchTerm(terms,m.group(1));}if(terms.isEmpty()&&a!=null)addSearchTerm(terms,YoruBrain.title(a));LinkedHashSet<String> limited=new LinkedHashSet<>();for(String t:terms){limited.add(t);if(limited.size()>=3)break;}return limited;}
    private static void addSearchTerm(LinkedHashSet<String> terms,String value){String v=cleanTitle(value);v=v.replaceAll("(?iu)\\b(смотреть|онлайн|аниме|все серии|озвучка|субтитры)\\b","").replaceAll("\\s+"," ").trim();if(v.length()>=2&&v.length()<=120&&Pattern.compile("[\\p{L}]").matcher(v).find())terms.add(v);}
    private static String trimSearchNoise(String value){String v=cleanTitle(value);v=v.replaceAll("\\s*\\([^)]*\\)\\s*"," ").replaceAll("\\s*\\[[^]]*]\\s*"," ");v=v.replaceAll("(?iu)\\b(tv|ova|ona|movie|special|season|фильм|спешл|сезон)\\b"," ");v=v.replaceAll("(?iu)\\b[0-9]+(?:st|nd|rd|th)?\\s*(season|сезон)\\b"," ").replaceAll("\\s+"," ").trim();return v;}
    private static boolean sameEpisode(double a,double b){return Math.abs(a-b)<0.001;}
    private static String episodeParam(double n){return sameEpisode(n,Math.floor(n))?String.valueOf((int)Math.floor(n)):String.valueOf(n);}
    public static String downloadSourceName(String id){String name=sourceNames.get(id);if(name!=null)return name;String value=cleanLabel(id);return value.isEmpty()?"Источник":value;}
    public static String cleanLabel(String value){String v=value==null?"":value.trim();if(v.isEmpty())return "";if(v.equalsIgnoreCase("player")||v.equalsIgnoreCase("плеер")||v.equalsIgnoreCase("вариант"))return "";return v;}
    private static int downloadSourceRank(String id){if("yoru".equals(id))return -1;if("yummy".equals(id))return 0;if("anixsekai".equals(id))return 1;if("animevost".equals(id))return 2;if("anidub".equals(id))return 3;if("animelib4k".equals(id))return 4;if("anilibria".equals(id))return 5;if("animelib".equals(id))return 6;if("animedia".equals(id))return 7;if("animetka".equals(id))return 8;if("kodik".equals(id))return 9;return 20;}
    private static void normalizeIds(Anime a){if(a!=null&&a.malId==0&&"shikimori".equals(a.source))try{a.malId=Integer.parseInt(a.id);}catch(Exception ignored){}}
    public String hentaText(String u)throws Exception{return request(u,"GET",null,false);}
    public JSONObject hentaShiki(String q)throws Exception{Exception last=null;for(String url:SHIKI_GRAPH){try{JSONObject j=new JSONObject(request(url,"POST",new JSONObject().put("query",q).toString(),false));if(j.has("errors"))throw new IOException("Shikimori не ответил");return j.getJSONObject("data");}catch(Exception e){last=e;}}if(last!=null)throw last;throw new IOException("Shikimori не ответил");}
    private JSONObject hanimeSearch(String q)throws Exception{JSONObject body=new JSONObject().put("search_text",q).put("tags",new JSONArray()).put("tags_mode","AND").put("brands",new JSONArray()).put("blacklist",new JSONArray()).put("order_by","likes").put("ordering","desc").put("page",0);return postJson("https://search.htv-services.com/",body);}
    private JSONObject hanimeVideo(String slug)throws Exception{try{return get("https://members.hanime.tv/rapi/v7/video?id="+enc(slug));}catch(Exception first){return get("https://hanime.tv/api/v8/video?id="+enc(slug));}}
    private static int hanimeYear(long rel){if(rel>100000000000L)rel/=1000;if(rel<946684800L||rel>4102444800L)return 0;try{java.util.Calendar c=java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));c.setTimeInMillis(rel*1000);int y=c.get(java.util.Calendar.YEAR);return y>=1985&&y<=2100?y:0;}catch(Exception e){return 0;}}
    private static long hanimeMoment(JSONObject v){long r=v==null?0:v.optLong("released_at_unix",v.optLong("released_at",0));if(r>100000000000L)r/=1000;return r<0?0:r;}
    private Anime hanimeShell(JSONObject v){Anime a=new Anime();a.source="hanime";a.id=v.optString("slug","");if(a.id.isEmpty())a.id="h"+v.optInt("id",0);a.title=v.optString("name","Hentai");JSONArray titles=v.optJSONArray("titles");if(titles!=null&&titles.length()>0)a.original=titles.optString(0,"");if(a.original.isEmpty())a.original=a.title;a.poster=safeUrl(v.optString("poster_url",v.optString("cover_url","")));a.description=plain(v.optString("description",""));a.year=hanimeYear(v.optLong("released_at",0));a.score=v.optDouble("rating",0);return a;}
    private static boolean hanimeMatches(JSONObject v,Anime a){if(v==null||a==null)return false;String bt=plainName(a.title),bo=plainName(a.original);ArrayList<String> names=new ArrayList<>();names.add(v.optString("name",""));JSONArray titles=v.optJSONArray("titles");for(int i=0;titles!=null&&i<titles.length();i++)names.add(titles.optString(i,""));boolean hit=false;for(String n:names){String t=plainName(n);if(t.isEmpty())continue;if(!bt.isEmpty()&&(t.equals(bt)||t.startsWith(bt+" ")||t.startsWith(bt+":"))){hit=true;break;}if(!bo.isEmpty()&&(t.equals(bo)||t.startsWith(bo+" ")||t.startsWith(bo+":"))){hit=true;break;}}if(!hit)return false;int y=hanimeYear(v.optLong("released_at",0));return a.year==0||y==0||Math.abs(a.year-y)<=1;}
    private Anime findHanime(Anime a)throws Exception{Anime best=null;int terms=0;for(String q:searchTerms(a)){if(terms++>=3)break;JSONArray rows=null;try{rows=firstArray(hanimeSearch(q),"videos","data","items","results");}catch(Exception ignored){continue;}if(rows==null)continue;for(int i=0;i<rows.length();i++){JSONObject v=rows.optJSONObject(i);if(v==null)continue;Anime item=hanimeShell(v);if(hanimeMatches(v,a))return remember(item);if(best==null&&i<5&&matchesQuery(item,q))best=item;}}return best==null?null:remember(best);}
    private static int hanimeHeight(JSONObject st){int h=st==null?0:st.optInt("height",st.optInt("resolution",0));if(h<=0&&st!=null){String str=st.optString("height","");StringBuilder d=new StringBuilder();for(int i=0;i<str.length();i++){char c=str.charAt(i);if(c>='0'&&c<='9')d.append(c);}if(d.length()>0&&d.length()<5)try{h=Integer.parseInt(d.toString());}catch(Exception e){h=0;}}return h<0?0:h;}
    private Anime.Episode hanimeEpisode(Anime shell,JSONObject v,JSONObject detail,int number){if(shell==null||v==null||detail==null||number<=0)return null;JSONObject root=firstObject(detail,"videos_manifest","manifest");if(root==null)root=detail;JSONArray servers=root.optJSONArray("servers");if(servers==null)servers=firstArray(detail,"servers");String best="";int bestH=-1;for(int x=0;servers!=null&&x<servers.length();x++){JSONObject srv=servers.optJSONObject(x);if(srv==null)continue;JSONArray streams=srv.optJSONArray("streams");if(streams==null)streams=firstArray(srv,"streams","urls","files");for(int k=0;streams!=null&&k<streams.length();k++){JSONObject st=streams.optJSONObject(k);if(st==null)continue;String u=embed(st.optString("url",st.optString("src",st.optString("link",""))));int h=hanimeHeight(st);if(u.isEmpty()||h>720||h<=bestH)continue;bestH=h;best=u;}}if(best.isEmpty())return null;Anime.Episode ep=new Anime.Episode();ep.id="hanime-"+v.optString("slug","x");ep.number=number;ep.name=v.optString("name","");ep.poster=safeUrl(v.optString("poster_url",v.optString("cover_url",shell.poster)));long dur=v.optLong("duration_in_ms",0);if(dur>0)ep.duration=(int)Math.min(86400L,dur/1000);ep.lazy="hanime";addVariant(ep,new Anime.Variant("","",best));return ep;}
    private Anime hanimeDetails(Anime base,boolean episodes)throws Exception{Anime a=Anime.from(base.json());a.source="hanime";if(a.id.isEmpty()||!episodes)return remember(a);JSONObject info;try{info=hanimeVideo(a.id);}catch(Exception e){return remember(a);}JSONObject hv=firstObject(info,"hentai_video","video","data");JSONArray franchise=firstArray(info,"hentai_franchise_hentai_videos","franchise_videos","videos","episodes");ArrayList<JSONObject> vids=new ArrayList<>();for(int i=0;franchise!=null&&i<franchise.length();i++){JSONObject v=franchise.optJSONObject(i);if(v!=null&&!v.optString("slug","").isEmpty())vids.add(v);}if(vids.isEmpty()&&hv!=null&&!hv.optString("slug","").isEmpty())vids.add(hv);if(hv!=null&&a.poster.isEmpty())a.poster=safeUrl(hv.optString("poster_url",hv.optString("cover_url","")));vids.sort(Comparator.comparingLong((JSONObject v)->hanimeMoment(v)).thenComparing(v->v.optString("slug","")));ArrayList<JSONObject> targets=new ArrayList<>();for(JSONObject v:vids){if(targets.size()>=24)break;targets.add(v);}long deadline=System.currentTimeMillis()+9000;ExecutorService pool=Executors.newFixedThreadPool(Math.min(4,Math.max(1,targets.size())));ArrayList<Future<JSONObject>> futures=new ArrayList<>();try{for(JSONObject v:targets){final String slug=v.optString("slug","");futures.add(pool.submit(()->{try{return hanimeVideo(slug);}catch(Exception e){return null;}}));}int n=0;for(int i=0;i<targets.size();i++){long left=deadline-System.currentTimeMillis();if(left<=0)break;JSONObject detail=null;try{detail=futures.get(i).get(left,TimeUnit.MILLISECONDS);}catch(InterruptedException ie){Thread.currentThread().interrupt();break;}catch(Exception e){break;}if(detail==null)continue;Anime.Episode ep=null;try{ep=hanimeEpisode(a,targets.get(i),detail,n+1);}catch(Exception ignored){}if(ep==null)continue;n++;a.episodeList.add(ep);}}finally{pool.shutdownNow();}a.episodeList.sort(Comparator.comparingDouble(e->e.number));a.episodes=Math.max(a.episodes,a.episodeList.size());a.episodesAired=Math.max(a.episodesAired,a.episodeList.size());return remember(a);}
    public static void posterFix(Anime a,Runnable done){AniListApi.posterFix(a,done);}
    public static void posterFixReplace(Anime a,Runnable done){AniListApi.posterFixReplace(a,done);}
    private Anime findYummy(Anime a)throws Exception{normalizeIds(a);String url="https://api.yani.tv/anime"+(a.malId>0?"?shikimori_ids="+a.malId+"&limit=20":"?q="+enc(a.title)+"&limit=20");JSONArray rows=get(url).optJSONArray("response");Anime found=null;for(int i=0;rows!=null&&i<rows.length();i++){Anime y=yummyAnime(rows.getJSONObject(i));if(a.malId>0){JSONObject remote=rows.getJSONObject(i).optJSONObject("remote_ids");if(remote!=null&&(remote.optInt("myanimelist_id")==a.malId||remote.optInt("shikimori_id")==a.malId))return remember(y);}if(a.malId==0&&plainName(y.title).equals(plainName(a.title))&&(a.year==0||a.year==y.year)){if(found!=null&&found.malId!=y.malId)return null;found=y;}}return found==null?null:remember(found);}
    private Anime findAniLib(Anime a)throws Exception{normalizeIds(a);Anime best=null;for(String q:searchTerms(a)){Anime.Page page=catalog("animelib",q,1,new Filter());for(Anime item:page.items){if(!matchesAnime(item,a))continue;return item;}}return best;}
    private JSONObject animelibDetail(String slug,Anime base)throws Exception{String fields="?fields[]=genres&fields[]=releaseDate&fields[]=shiki_id&fields[]=anilist_id&fields[]=rate&fields[]=rate_avg";String resolved=slug;if(parseInt(slug)>0&&!slug.contains("--")){String found=animelibSlug(base);if(!found.isEmpty())resolved=found;}try{return get("https://api.cdnlibs.org/api/anime/"+enc(resolved)+fields);}catch(Exception first){String found=animelibSlug(base);if(!found.isEmpty()&&!found.equals(resolved))return get("https://api.cdnlibs.org/api/anime/"+enc(found)+fields);throw first;}}
    private String animelibSlug(Anime base){try{if(base==null)return "";if(base.alias!=null&&!base.alias.isEmpty()&&base.alias.contains("--"))return base.alias;for(String q:searchTerms(base)){Anime.Page page=catalog("animelib",q,1,new Filter());for(Anime item:page.items){if(item.id.equals(base.id)||matchesAnime(item,base))return item.alias;}}}catch(Exception ignored){}return "";}
    private int resolveMal(Anime a)throws Exception{if(a.malId>0)return a.malId;Anime y=findYummy(a);if(y!=null&&y.malId>0){a.malId=y.malId;a.kpId=y.kpId;return y.malId;}throw new IOException("Не удалось найти просмотр Попробуйте открыть карточку позже");}
    private int resolveKp(Anime a)throws Exception{if(a.kpId>0)return a.kpId;Anime y=findYummy(a);if(y!=null&&y.kpId>0){a.kpId=y.kpId;return y.kpId;}throw new IOException("У этого просмотра пока нет подходящего варианта");}
    public String directKodik(int mal)throws Exception{return SourceResolver.directKodik(mal,this);}
    private String regional(String source,int kp)throws Exception{if(source.equals("flixcdn"))return "https://tarantino.factorios.live/show/kinopoisk/"+kp;if(source.equals("gendit"))return "https://horsez.org/lat/"+kp;JSONObject root=get("https://fbphdplay.top/api/players?kinopoisk="+kp);JSONArray list=root.optJSONArray("data");for(int i=0;list!=null&&i<list.length();i++){JSONObject j=list.getJSONObject(i);if(j.optString("type").equalsIgnoreCase(source)){String url=safeUrl(j.optString("iframeUrl"));if(!url.isEmpty())return url;}}throw new IOException("Просмотр пока недоступен для этого аниме");}
    public static String embed(String input){return SourceResolver.embed(input);}
    private static String absolute(String base,String value){try{if(value==null||value.trim().isEmpty())return "";value=value.trim().replace(" ","%20").replace("&amp;","&");if(value.startsWith("//"))value="https:"+value;return safeUrl(new URL(new URL(base),value).toString());}catch(Exception e){return "";}}
    private static String hostName(String link){try{String h=Uri.parse(link.startsWith("//")?"https:"+link:link).getHost();return h==null?"Вариант":h.replace("www.","");}catch(Exception e){return "Вариант";}}
    static String plain(String text){return Html.fromHtml(text==null?"":text,Html.FROM_HTML_MODE_LEGACY).toString().replaceAll("\\[/?[^\\]]+\\]","").trim();}
    static String plainName(String text){return (text==null?"":text).toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+"," ").trim();}
    private static double numberIn(String text,double fallback){Matcher m=Pattern.compile("[0-9]+(?:\\.[0-9]+)?").matcher(text);try{return m.find()?Double.parseDouble(m.group()):fallback;}catch(Exception e){return fallback;}}
    private static void putStream(Anime.Episode ep,int q,String url){String s=safeUrl(url);if(!s.isEmpty())ep.streams.put(q,s);}
    private static void genres(Anime a,JSONArray rows,String name){for(int i=0;rows!=null&&i<rows.length();i++){Object g=rows.opt(i);if(g instanceof JSONObject){String value=((JSONObject)g).optString(name,((JSONObject)g).optString("name",""));if(!value.isEmpty()&&!a.genres.contains(value))a.genres.add(value);}else if(g instanceof String&&!a.genres.contains((String)g))a.genres.add((String)g);}}






    private static String screenshotUrl(Object raw){if(raw instanceof JSONObject){JSONObject o=(JSONObject)raw;return safeUrl(first(o.optString("original",""),first(o.optString("preview",""),first(o.optString("url",""),o.optString("src","")))));}return safeUrl(String.valueOf(raw==null?"":raw));}
    private static String joinJson(JSONObject j,String key,int limit){JSONArray arr=j.optJSONArray(key);StringBuilder b=new StringBuilder();for(int i=0;arr!=null&&i<arr.length()&&i<limit;i++){String v=arr.optString(i,"").trim();if(v.isEmpty())continue;if(b.length()>0)b.append(", ");b.append(v);}return b.toString();}
    private static String firstArray(JSONArray arr){for(int i=0;arr!=null&&i<arr.length();i++){String v=arr.optString(i,"").trim();if(!v.isEmpty())return v;}return "";}
    private static String crewJson(JSONObject j){StringBuilder b=new StringBuilder();String d=joinJson(j,"directors",4),w=joinJson(j,"writers",4),c=joinJson(j,"composers",3);if(!d.isEmpty())b.append("Режиссёр: ").append(d);if(!w.isEmpty()){if(b.length()>0)b.append(" · ");b.append("Сценарий: ").append(w);}if(!c.isEmpty()){if(b.length()>0)b.append(" · ");b.append("Музыка: ").append(c);}return b.toString();}
    private static String ratingsJson(JSONObject j){StringBuilder b=new StringBuilder();double sh=j.optDouble("shikimori_rating",0),kp=j.optDouble("kinopoisk_rating",0),im=j.optDouble("imdb_rating",0);if(sh>0)b.append(String.format(Locale.US,"Shikimori %.2f",sh));if(kp>0){if(b.length()>0)b.append(" · ");b.append(String.format(Locale.US,"КП %.1f",kp));}if(im>0){if(b.length()>0)b.append(" · ");b.append(String.format(Locale.US,"IMDb %.1f",im));}return b.toString();}

    private static Anime animetkaAnime(JSONObject j){Anime a=new Anime();a.source="animetka";a.id=j.optString("animetka_id",j.optString("id"));a.title=j.optString("anime_title",j.optString("title","Аниме"));if(a.title.isEmpty())a.title=j.optString("title","Аниме");a.original=j.optString("title_orig",j.optString("title_en",""));a.alias=j.optString("title_en","");a.description=plain(j.optString("anime_description",j.optString("description","")));String poster=j.optString("anime_poster_url",j.optString("poster_url",""));a.poster=safeUrl(poster);a.year=j.optInt("year");a.type=kind(j.optString("anime_kind",j.optString("kind","")));a.status=j.optString("all_status",j.optString("anime_status",""));int age=j.optInt("minimal_age",0);a.age=age>0?age+"+":j.optString("rating_mpaa","");a.episodes=j.optInt("episodes_total",j.optInt("episodes",0));a.episodesAired=j.optInt("episodes_aired",0);a.score=j.optDouble("shikimori_rating",j.optDouble("rating",0));if(!Double.isFinite(a.score))a.score=0;a.malId=j.optInt("shikimori_id",j.optInt("malId",0));a.kpId=j.optInt("kinopoisk_id",j.optInt("kp_id",0));JSONArray studios=j.optJSONArray("anime_studios");a.studio=firstArray(studios);a.countries=joinJson(j,"countries",5);a.durationMinutes=j.optInt("duration",0);a.translationsCount=j.optInt("translation_count",0);a.franchise=j.optString("shikimori_franchise","");a.shikimoriOrder=j.optInt("shikimori_order",0);a.ratings=ratingsJson(j);a.cast=joinJson(j,"actors",10);a.crew=crewJson(j);a.airedDate=first(j.optString("aired_at",""),first(j.optString("premiere_world",""),j.optString("released_at","")));JSONArray ss=j.optJSONArray("screenshots");for(int i=0;ss!=null&&i<ss.length()&&a.screenshots.size()<12;i++){String u=screenshotUrl(ss.opt(i));if(!u.isEmpty()&&!a.screenshots.contains(u))a.screenshots.add(u);}for(String key:new String[]{"trailer","trailer_url","trailerUrl"}){String u=safeUrl(j.optString(key,""));if(!u.isEmpty()){a.trailerUrl=u;break;}}genres(a,j.optJSONArray("anime_genres"),"name");genres(a,j.optJSONArray("all_genres"),"name");genres(a,j.optJSONArray("Genres"),"name");return a;}

    static Anime shikiAnime(JSONObject j){Anime a=new Anime();a.source="shikimori";a.id=j.optString("id");a.malId=j.optInt("malId",0);if(a.malId==0)try{a.malId=Integer.parseInt(a.id);}catch(Exception ignored){}a.title=j.optString("russian","");if(a.title.isEmpty())a.title=j.optString("name","Аниме");a.original=j.optString("name","");a.type=kind(j.optString("kind"));a.status=j.optString("status");a.episodes=j.optInt("episodes");a.episodesAired=j.optInt("episodesAired",0);a.nextEpisodeAt=j.optString("nextEpisodeAt","");a.score=j.optDouble("score",0);JSONObject date=j.optJSONObject("airedOn"),poster=j.optJSONObject("poster");a.year=date==null?0:date.optInt("year");a.airedDate=date==null?"":date.optString("date","");a.poster=poster==null?"":safeUrl(poster.optString("mainUrl",poster.optString("originalUrl")));a.age=j.optString("rating").equals("pg_13")?"13+":j.optString("rating").startsWith("r")?"18+":"";JSONArray studios=j.optJSONArray("studios");if(studios!=null&&studios.length()>0)a.studio=studios.optJSONObject(0)==null?"":studios.optJSONObject(0).optString("name","");genres(a,j.optJSONArray("genres"),"russian");return a;}
    private static Anime anilistAnime(JSONObject j){Anime a=new Anime();a.source="anilist";a.anilistId=j.optInt("id",0);a.malId=j.optInt("malId",0);int use=a.malId>0?a.malId:a.anilistId;if(use<=0)return null;a.id=String.valueOf(use);JSONObject t=j.optJSONObject("title");String ru=t==null?"":t.optString("russian",""),en=t==null?"":t.optString("english",""),romaji=t==null?"":t.optString("romaji","");a.title=ru;if(a.title.isEmpty())a.title=en;if(a.title.isEmpty())a.title=romaji;if(a.title.isEmpty())a.title="Аниме";a.original=romaji;if(a.original.isEmpty())a.original=en;a.alias=en;a.type=kind(j.optString("format",""));String st=j.optString("status","");a.status="FINISHED".equals(st)||"CANCELLED".equals(st)||"HIATUS".equals(st)?"finished":"NOT_YET_RELEASED".equals(st)?"anons":"ongoing";a.episodes=j.optInt("episodes",0);a.episodesAired=0;JSONObject d=j.optJSONObject("startDate");if(d!=null&&d.optInt("year",0)>0){a.year=d.optInt("year");a.airedDate=String.format(Locale.ROOT,"%04d-%02d-%02d",a.year,d.optInt("month",1),d.optInt("day",1));}JSONObject c=j.optJSONObject("coverImage");a.poster=c==null?"":safeUrl(c.optString("large",c.optString("medium","")));a.score=j.optDouble("averageScore",0)/10.0;a.description=plain(j.optString("description",""));genres(a,j.optJSONArray("genres"),"name");return a;}
    private static Anime vostAnime(JSONObject j){Anime a=new Anime();a.source="animevost";a.id=j.optString("id");String raw=j.optString("title","Аниме"),clean=raw.replaceAll("\\s*\\[[^\\]]*\\]\\s*$","");String[] names=clean.split(" / ",2);a.title=names[0];a.original=names.length>1?names[1]:"";a.description=plain(j.optString("description"));a.poster=safeUrl(j.optString("urlImagePreview"));a.year=j.optInt("year");a.type=j.optString("type","Аниме");Matcher m=Pattern.compile("из\\s*(\\d+)").matcher(raw);if(m.find())a.episodes=Integer.parseInt(m.group(1));a.status="published";for(String g:j.optString("genre","").split(","))if(!g.trim().isEmpty()&&!a.genres.contains(g.trim()))a.genres.add(g.trim());return a;}
    private static Anime yummyAnime(JSONObject j){Anime a=new Anime();a.source="yummy";a.id=j.optString("anime_id");a.title=j.optString("title","Аниме");a.alias=j.optString("anime_url");a.year=j.optInt("year");a.description=plain(j.optString("description"));JSONObject p=j.optJSONObject("poster"),type=j.optJSONObject("type"),age=j.optJSONObject("min_age"),rat=j.optJSONObject("rating"),ids=j.optJSONObject("remote_ids"),eps=j.optJSONObject("episodes"),status=j.optJSONObject("anime_status");a.poster=p==null?"":safeUrl(p.optString("medium",p.optString("fullsize")));a.type=type==null?"Аниме":type.optString("shortname","Аниме");a.age=age==null?"":age.optString("title");a.score=rat==null?0:rat.optDouble("average",0);a.status=status==null?"":status.optString("alias");a.episodes=eps==null?j.optInt("ep_count"):eps.optInt("count");a.episodesAired=a.episodes;a.malId=ids==null?0:ids.optInt("myanimelist_id");if(a.malId<=0&&ids!=null)a.malId=ids.optInt("shikimori_id");a.kpId=ids==null?0:ids.optInt("kp_id");a.libriaAlias=ids==null?"":ids.optString("anilibria_alias","");a.blocked=j.optBoolean("blocked",false);genres(a,j.optJSONArray("genres"),"title");return a;}
    private static String animelibCover(JSONObject cover,String id){if(cover==null)return "";String[] keys={"default","md","thumbnail","filename","url","src"};for(String key:keys){String u=animelibCoverUrl(cover.optString(key,""));if(!u.isEmpty())return u;}JSONObject optimized=cover.optJSONObject("optimized");if(optimized!=null)for(String key:keys){String u=animelibCoverUrl(optimized.optString(key,""));if(!u.isEmpty())return u;}JSONObject images=cover.optJSONObject("images");if(images!=null)for(String key:keys){String u=animelibCoverUrl(images.optString(key,""));if(!u.isEmpty())return u;}return animelibCoverUrl(id==null?"":cover.optString("path",id));}
    private static String animelibCoverUrl(String raw){String s=raw==null?"":raw.trim().replace("\\/","/").replace(" ","%20");if(s.isEmpty()||s.equalsIgnoreCase("null"))return "";if(s.startsWith("http://")||s.startsWith("https://"))return safeUrl(s);if(s.startsWith("//"))return safeUrl("https:"+s);if(s.startsWith("/"))return safeUrl("https://cover.cdnlibs.org"+s);return safeUrl("https://cover.cdnlibs.org/"+s.replaceAll("^/+",""));}
    private static Anime amAnime(JSONObject j){Anime a=new Anime();a.source="animelib";a.id=j.optString("id");a.title=j.optString("rus_name",j.optString("name","Аниме"));a.original=j.optString("name",j.optString("eng_name",""));a.alias=j.optString("slug_url",a.id);JSONObject p=j.optJSONObject("cover"),type=j.optJSONObject("type"),age=j.optJSONObject("ageRestriction"),rating=j.optJSONObject("rating"),status=j.optJSONObject("status"),episodes=j.optJSONObject("episodes");a.poster=animelibCover(p,j.optString("id"));a.airedDate=j.optString("releaseDate","");try{a.year=Integer.parseInt(j.optString("releaseDate","").substring(0,4));}catch(Exception ignored){}a.type=type==null?"Аниме":type.optString("label");a.age=age==null?"":age.optString("label");a.score=rating==null?j.optDouble("shiki_rate",0):rating.optDouble("average",0);JSONObject studio=j.optJSONObject("studio");if(studio!=null)a.studio=studio.optString("name",studio.optString("title",""));a.status=status!=null&&status.optInt("id")==1?"ongoing":"released";a.malId=j.optInt("shiki_id",parseTrailingId(j.optString("shikimori_href",j.optString("shiki_href",""))));a.anilistId=j.optInt("anilist_id",parseTrailingId(j.optString("anilist_href","")));a.blocked=j.optBoolean("is_licensed",false);a.description=plain(first(j.optString("description",""),prose(j.opt("summary"),0)));a.episodes=episodes==null?j.optInt("episodes_total",j.optInt("episodes_count",0)):episodes.optInt("total",episodes.optInt("count",0));a.episodesAired=episodes==null?j.optInt("episodes_count",0):episodes.optInt("count",0);genres(a,j.optJSONArray("genres"),"name");return a;}
    private static String first(String a,String b){return a!=null&&!a.isEmpty()?a:b==null?"":b;}
    private static String prose(Object value,int depth){if(value==null||depth>12)return "";if(value instanceof String)return plain((String)value);if(!(value instanceof JSONObject))return "";JSONObject j=(JSONObject)value;if(j.has("text"))return j.optString("text");StringBuilder s=new StringBuilder();JSONArray a=j.optJSONArray("content");for(int i=0;a!=null&&i<a.length();i++){s.append(prose(a.opt(i),depth+1));if(j.optString("type").equals("doc"))s.append("\n\n");}return s.toString().trim();}
    private static int parseTrailingId(String value){try{Matcher m=Pattern.compile("(\\d+)(?:/)?$").matcher(value==null?"":value);return m.find()?Integer.parseInt(m.group(1)):0;}catch(Exception e){return 0;}}
    private static Anime libriaAnime(JSONObject j){Anime a=new Anime();a.source="anilibria";a.id=j.optString("id");JSONObject name=j.optJSONObject("name"),poster=j.optJSONObject("poster"),type=j.optJSONObject("type"),age=j.optJSONObject("age_rating");a.title=name==null?"Аниме":name.optString("main","Аниме");a.original=name==null?"":name.optString("english");a.alias=j.optString("alias");a.year=j.optInt("year");a.type=type==null?"Аниме":type.optString("description","Аниме");JSONObject opt=poster==null?null:poster.optJSONObject("optimized");String path=opt==null?(poster==null?"":poster.optString("preview")):opt.optString("preview");a.poster=path.startsWith("/")?"https://anilibria.top"+path:safeUrl(path);a.age=age==null?"":age.optString("label");a.description=plain(j.optString("description"));a.episodes=j.optInt("episodes_total");a.episodesAired=j.optJSONArray("episodes")==null?j.optInt("episodes_count",0):j.optJSONArray("episodes").length();a.status=j.optBoolean("is_ongoing")?"ongoing":"released";a.blocked=j.optBoolean("is_blocked_by_geo")||j.optBoolean("is_blocked_by_copyrights");genres(a,j.optJSONArray("genres"),"name");JSONArray eps=j.optJSONArray("episodes");for(int i=0;eps!=null&&i<eps.length();i++){JSONObject e=eps.optJSONObject(i);if(e==null)continue;Anime.Episode ep=new Anime.Episode();ep.id=e.optString("id");ep.number=e.optDouble("ordinal");ep.name=e.optString("name");ep.poster=absolute("https://anilibria.top/",bestImage(e));ep.duration=e.optInt("duration");putStream(ep,480,e.optString("hls_480"));putStream(ep,720,e.optString("hls_720"));putStream(ep,1080,e.optString("hls_1080"));JSONObject op=e.optJSONObject("opening");if(op!=null){ep.openingStart=op.optInt("start");ep.openingEnd=op.optInt("stop");}a.episodeList.add(ep);}a.episodeList.sort(Comparator.comparingDouble(e->e.number));return a;}
    static String kind(String value){switch(value.toLowerCase(Locale.ROOT)){case "tv":case "tv_short":return "ТВ";case "movie":return "Фильм";case "ona":return "ONA";case "ova":return "OVA";case "special":case "tv_special":return "Спешл";case "music":return "Музыка";default:return "Аниме";}}
}
