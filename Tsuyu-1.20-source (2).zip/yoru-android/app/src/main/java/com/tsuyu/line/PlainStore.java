package com.tsuyu.line;

import android.content.SharedPreferences;
import org.json.JSONObject;

/** Plain JSON preferences store. Application data is not encrypted. */
public final class PlainStore {
    public PlainStore() {}

    public JSONObject read(SharedPreferences prefs, String name) {
        if (prefs == null) return new JSONObject();
        String value = prefs.getString(name, "");
        if (value == null || value.trim().isEmpty()) return new JSONObject();
        try {
            return new JSONObject(value);
        } catch (Exception ignored) {
            return new JSONObject();
        }
    }

    public void write(SharedPreferences prefs, String name, JSONObject json) {
        if (prefs == null || json == null) return;
        prefs.edit().putString(name, json.toString()).apply();
    }
}
