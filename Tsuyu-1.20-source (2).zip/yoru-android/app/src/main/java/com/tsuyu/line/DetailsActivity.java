package com.tsuyu.line;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.*;

public final class DetailsActivity extends Activity {
    private RecyclerView episodeRecycler;private EpisodeAdapter episodeAdapter;private volatile Future<Anime.Playback> earlyPlayback;
    private Anime anime;private LinearLayout root,body;private TextView state;private int generation,downloadsGeneration;private boolean loaded,episodesLoaded,favoriteCached;private String bucketCached="",relatedFilter="";private JSONObject progressCached=new JSONObject();private HashMap<String,androidx.media3.exoplayer.offline.Download> completed=new HashMap<>();private Future<?> detailFuture,downloadFuture;
    public static boolean hasPlayable(Collection<Anime.Episode> list){if(list==null||list.isEmpty())return false;for(Anime.Episode e:list){if(e==null)continue;if(!e.streams.isEmpty()||!e.variants.isEmpty()||(e.lazy!=null&&!e.lazy.isEmpty()&&!"future".equals(e.lazy))||(e.resolverUrl!=null&&!e.resolverUrl.isEmpty()))return true;}return false;}
    @Override public void onCreate(Bundle b){super.onCreate(b);if(!Ui.allow(this))return;try{YoruApp.app().focusNow("details");}catch(Exception ignored){}anime=Ui.intentAnime(this);if(!Anime.valid(anime)){finish();return;}YoruApp.app().api.remember(anime);YoruCache cache=YoruApp.app().cache;if(cache!=null){try{Anime cached=cache.detail(anime,14*24*60*60*1000L);if(Anime.valid(cached)){SourceEngine.absorb(anime,cached);anime=cached;if(!anime.episodeList.isEmpty()&&hasPlayable(anime.episodeList))episodesLoaded=true;}}catch(Exception ignored){}}root=Ui.base(this);LinearLayout bar=Ui.row(this);bar.setPadding(Ui.dp(this,16),Ui.dp(this,9),Ui.dp(this,16),Ui.dp(this,9));bar.addView(Ui.iconButton(this,"back","Назад",this::finish),Ui.lp(this,44,44));TextView label=Ui.text(this,"Tsuyu",13,Ui.MUTED,true);Ui.gap(bar,label,-2,-2,13);root.addView(bar,Ui.lp(this,-1,-2));ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);body=Ui.column(this);body.setPadding(Ui.dp(this,20),Ui.dp(this,12),Ui.dp(this,20),Ui.dp(this,30));scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));render();loadDownloads();loadFull();}
    @Override protected void onResume(){super.onResume();if(body!=null){render();loadDownloads();ensureScreenshots(generation);if(anime!=null&&!hasPlayable(anime.episodeList))loadFull();}}
    private void loadFull(){int gen=++generation;if(detailFuture!=null)detailFuture.cancel(true);if(earlyPlayback!=null)earlyPlayback.cancel(true);boolean hasEps=episodesLoaded&&hasPlayable(anime.episodeList)&&anime.episodeList.size()>=Math.max(1,anime.episodesAired>0?anime.episodesAired:anime.episodes);if(hasEps&&!anime.description.isEmpty()&&!anime.related.isEmpty())return;detailFuture=YoruApp.app().io.submit(()->{Anime seed=Anime.from(anime.json());final Future<Anime.Playback> early=hasEps?null:YoruApp.app().io.submit(()->{try{Anime target=seed;if("shikimori".equals(seed.source))target=YoruApp.app().api.yoruShell(seed);Anime.Playback p=YoruApp.app().api.playback(target,"henta".equals(seed.source)?"henta":"yoru");if(p!=null&&p.video!=null&&!p.video.episodeList.isEmpty()&&hasPlayable(p.video.episodeList)){YoruApp.app().main.post(()->{if(gen==generation&&!isFinishing()&&anime!=null){if(!hasPlayable(anime.episodeList)||anime.episodeList.size()<p.video.episodeList.size()){anime.episodeList.clear();anime.episodeList.addAll(p.video.episodeList);anime.episodes=Math.max(anime.episodes,p.video.episodeList.size());anime.episodesAired=p.video.episodesAired>0?p.video.episodesAired:Math.max(anime.episodesAired,playableCount(anime.episodeList));episodesLoaded=true;completed.clear();if(episodeAdapter!=null)episodeAdapter.updateRows();render();loadDownloads();}}});}return p;}catch(Exception e){return null;}});earlyPlayback=early;Anime meta=seed;try{meta=YoruApp.app().api.quickDetails(seed);final Anime fast=meta;YoruApp.app().main.post(()->{if(gen==generation&&!isFinishing()){if(fast!=null){if(fast.episodeList.isEmpty()&&anime!=null&&!anime.episodeList.isEmpty()){fast.episodeList.addAll(anime.episodeList);fast.episodes=Math.max(fast.episodes,anime.episodes);fast.episodesAired=Math.max(fast.episodesAired,anime.episodesAired);}anime=fast;loaded=true;if(!anime.episodeList.isEmpty()&&hasPlayable(anime.episodeList)){episodesLoaded=true;completed.clear();}}render();loadDownloads();prefetchRelated();ensureScreenshots(gen);}});}catch(Exception ignored){}if(episodesLoaded&&hasPlayable(anime.episodeList)&&anime.episodeList.size()>=Math.max(1,anime.episodesAired>0?anime.episodesAired:anime.episodes))return;if(early==null)return;Anime.Playback p=null;long wait0=System.currentTimeMillis();try{p=early.get(episodesLoaded&&hasPlayable(anime.episodeList)?1500:8000,TimeUnit.MILLISECONDS);}catch(InterruptedException ie){early.cancel(true);Thread.currentThread().interrupt();return;}catch(Exception ignored){}if(Thread.currentThread().isInterrupted()){early.cancel(true);return;}if(p!=null&&p.video!=null&&!p.video.episodeList.isEmpty()&&hasPlayable(p.video.episodeList)){final Anime metaSnapshot=Anime.from(meta.json());metaSnapshot.episodeList.clear();metaSnapshot.episodeList.addAll(p.video.episodeList);metaSnapshot.episodes=Math.max(Math.max(metaSnapshot.episodes,p.video.episodes),metaSnapshot.episodeList.size());metaSnapshot.episodesAired=p.video.episodesAired>0?p.video.episodesAired:Math.max(metaSnapshot.episodesAired,playableCount(metaSnapshot.episodeList));for(Anime r:meta.related){if(r==null)continue;boolean hasM=false;for(Anime x:metaSnapshot.related)if(x!=null&&x.key().equals(r.key())){hasM=true;break;}if(!hasM)metaSnapshot.related.add(r);}for(Anime r:p.video.related){if(r==null)continue;boolean has=false;for(Anime x:metaSnapshot.related)if(x!=null&&x.key().equals(r.key())){has=true;break;}if(!has)metaSnapshot.related.add(r);}for(String u:p.video.screenshots)if(!u.isEmpty()&&!metaSnapshot.screenshots.contains(u)&&metaSnapshot.screenshots.size()<12)metaSnapshot.screenshots.add(u);Anime ready=metaSnapshot;YoruCache db=YoruApp.app()==null?null:YoruApp.app().cache;if(db!=null)try{db.detail(ready);}catch(Exception ignored){}YoruApp.app().main.post(()->{if(gen==generation&&!isFinishing()){anime=ready;loaded=true;episodesLoaded=true;completed.clear();postersFilled=false;render();loadDownloads();prefetchRelated();ensureScreenshots(gen);}});early.cancel(true);return;}try{Anime target=meta;if("shikimori".equals(meta.source))target=YoruApp.app().api.yoruShell(meta);Anime full=YoruApp.app().api.details(target,true);if(full!=null&&!full.episodeList.isEmpty()&&hasPlayable(full.episodeList)){final Anime ready=Anime.from(meta.json());ready.episodeList.clear();ready.episodeList.addAll(full.episodeList);ready.episodes=Math.max(Math.max(ready.episodes,full.episodes),ready.episodeList.size());ready.episodesAired=full.episodesAired>0?full.episodesAired:Math.max(ready.episodesAired,playableCount(ready.episodeList));for(Anime r:meta.related){if(r==null)continue;boolean hasM=false;for(Anime x:ready.related)if(x!=null&&x.key().equals(r.key())){hasM=true;break;}if(!hasM)ready.related.add(r);}for(Anime r:full.related){if(r==null)continue;boolean has=false;for(Anime x:ready.related)if(x!=null&&x.key().equals(r.key())){has=true;break;}if(!has)ready.related.add(r);}for(String u:full.screenshots)if(!u.isEmpty()&&!ready.screenshots.contains(u)&&ready.screenshots.size()<12)ready.screenshots.add(u);YoruCache db=YoruApp.app()==null?null:YoruApp.app().cache;if(db!=null)try{db.detail(ready);}catch(Exception ignored){}YoruApp.app().main.post(()->{if(gen==generation&&!isFinishing()){anime=ready;loaded=true;episodesLoaded=true;completed.clear();postersFilled=false;render();loadDownloads();prefetchRelated();ensureScreenshots(gen);}});early.cancel(true);return;}}catch(Exception ignored){}early.cancel(true);YoruApp.app().main.post(()->{if(!isFinishing()&&gen==generation){loaded=true;episodesLoaded=true;if(state!=null&&anime.episodeList.isEmpty())state.setText("Серии временно недоступны");ensureScreenshots(gen);}});});}
    private void ensureScreenshots(int gen){if(anime==null||!anime.screenshots.isEmpty())return;final Anime seed=Anime.from(anime.json());YoruApp.app().io.execute(()->{try{ArrayList<String> shots=YoruApp.app().api.screenshotsOf(seed);if(shots.isEmpty())return;YoruApp.app().main.post(()->{if(gen!=generation||isFinishing()||anime==null)return;boolean added=false;for(String u:shots)if(!u.isEmpty()&&!anime.screenshots.contains(u)&&anime.screenshots.size()<12){anime.screenshots.add(u);added=true;}if(added)render();});}catch(Exception ignored){}});}
    private void loadDownloads(){final int gen=++downloadsGeneration;if(downloadFuture!=null)downloadFuture.cancel(true);final Anime snapshot=Anime.from(anime.json());downloadFuture=YoruApp.app().ui.submit(()->{HashMap<String,androidx.media3.exoplayer.offline.Download> rows=YoruApp.app().downloads().completedEpisodes(snapshot);YoruApp.app().main.post(()->{if(gen==downloadsGeneration&&!isFinishing()){if(!completed.keySet().equals(rows.keySet())){completed=rows;if(episodeAdapter!=null)episodeAdapter.updateRows();}else completed=rows;}});});}
    private void render(){progressCached=YoruApp.app().store.progress(anime);bucketCached=YoruApp.app().store.bucket(anime);favoriteCached=YoruApp.app().store.favorite(anime);prepareEpisodeDisplay();body.removeAllViews();LinearLayout hero=Ui.row(this);hero.setGravity(Gravity.TOP);ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackground(Ui.stroke(0xff17171a,14,this));image.setClipToOutline(true);hero.addView(image,Ui.lp(this,126,184));YoruApp.app().images.load(image,anime);LinearLayout info=Ui.column(this);info.setPadding(Ui.dp(this,17),Ui.dp(this,3),0,0);TextView title=Ui.text(this,YoruBrain.title(anime),23,Ui.TEXT,true);title.setMaxLines(6);info.addView(title);Ui.space(info,12);info.addView(Ui.text(this,anime.cardMeta()+(anime.studio.isEmpty()?"":" · "+anime.studio),11,Ui.MUTED,false));if(anime.score>0){Ui.space(info,9);info.addView(Ui.text(this,String.format(Locale.US,"★ %.2f",anime.score),15,Ui.AMBER,true));}hero.addView(info,new LinearLayout.LayoutParams(0,-2,1));body.addView(hero);Ui.space(body,18);chips();about();screenshots();trailerBlock();actions();progress();episodes();related();similar();fillMissingPosters();ensureRelated();ensureAiredCount();}
    private void openGenreSearch(String g){String id=ApiRepository.shikiGenreId(g);if(id.isEmpty())return;Intent i=new Intent(this,MainActivity.class);i.putExtra("genre",g);startActivity(i);}
    private void chips(){if(!anime.original.isEmpty()&&!anime.original.equals(anime.title)){body.addView(Ui.text(this,anime.original,12,Ui.MUTED,false));Ui.space(body,13);}if(!anime.genres.isEmpty()){HorizontalScrollView h=new HorizontalScrollView(this);h.setHorizontalScrollBarEnabled(false);LinearLayout row=Ui.row(this);for(String g:anime.genres.subList(0,Math.min(10,anime.genres.size()))){TextView chip=Ui.chip(this,g,false,()->openGenreSearch(g));LinearLayout.LayoutParams p=Ui.lp(this,-2,-2);p.rightMargin=Ui.dp(this,7);row.addView(chip,p);}h.addView(row);body.addView(h,Ui.lp(this,-1,-2));Ui.space(body,14);}String status=anime.statusLabel();String eps=anime.episodesLine();String next=anime.ongoing()&&!anime.nextEpisodeAt.isEmpty()?" · следующая: "+airText(anime.nextEpisodeAt):"";body.addView(Ui.text(this,status+(eps.isEmpty()?"":" · "+eps)+next+(anime.age.isEmpty()?"":" · "+anime.age),11,Ui.MUTED,false));Ui.space(body,18);}
    private void actions(){JSONObject history=progressCached;String play=history.length()>0?"Продолжить":"Смотреть";String storedMode=history.optString("playerMode","");if(storedMode.trim().isEmpty()||storedMode.equals("auto"))storedMode="yoru";final String playMode=storedMode;double startEpisode=history.optDouble("episode",1);androidx.media3.exoplayer.offline.Download offline=completed.get(DownloadHub.episodeKey(startEpisode));TextView start=Ui.button(this,anime.blocked?"Просмотр ограничен":(offline!=null?"Смотреть скачанное":""+play+" · "+defaultVoiceName()+" · "+qualityName(YoruApp.app().store.quality())),true,()->{if(offline!=null)Ui.openOffline(this,offline.request.id,anime,startEpisode);else openWatch(startEpisode,playMode);});start.setEnabled(!anime.blocked);if(anime.blocked)start.setAlpha(.45f);body.addView(start,Ui.lp(this,-1,-2));Ui.space(body,10);voiceInfoCard();Ui.space(body,10);LinearLayout main=Ui.row(this);main.addView(Ui.button(this,favoriteCached?"В коллекции":"В коллекцию",false,()->Ui.bucketDialog(this,anime,this::render)),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(0,-2,1);dp.leftMargin=Ui.dp(this,9);main.addView(Ui.button(this,"Скачать",false,()->DownloadActions.chooseEpisodeFast(this,anime,null,history.optDouble("episode",1),anime.episodeList)),dp);body.addView(main);}

    private void progress(){JSONObject history=progressCached;if(history.length()>0){Ui.space(body,10);body.addView(Ui.text(this,"Вы смотрели серию "+Ui.number(history.optDouble("episode",1))+" · "+Ui.time(history.optInt("time")),11,Ui.MUTED,false));}String bucket=bucketCached;if(!bucket.isEmpty()){int i=Arrays.asList(SecureStore.BUCKETS).indexOf(bucket);Ui.space(body,7);body.addView(Ui.text(this,"Ваш список: "+(i>=0?SecureStore.BUCKET_LABELS[i]:"В планах")+(YoruApp.app().store.folderSummary(anime).isEmpty()?"":" · папки: "+YoruApp.app().store.folderSummary(anime)),11,Ui.PURPLE,false));}String hint=anime.episodeList.isEmpty()?(episodesLoaded?"Список серий пока недоступен Попробуйте открыть просмотр":"Загружаем серии…"):"Просмотр: "+defaultVoiceName()+" · "+qualityName(YoruApp.app().store.quality())+".";state=Ui.text(this,hint,11,Ui.MUTED,false);if(!state.getText().toString().isEmpty()){Ui.space(body,12);body.addView(state);}}
    private void episodes(){Ui.space(body,24);LinearLayout row=Ui.row(this);row.addView(Ui.text(this,"Серии",21,Ui.TEXT,true),new LinearLayout.LayoutParams(0,-2,1));if(!anime.episodeList.isEmpty()){TextView pack=Ui.text(this,"Скачать дальше",10,Ui.PURPLE,true);pack.setPadding(Ui.dp(this,9),Ui.dp(this,7),Ui.dp(this,9),Ui.dp(this,7));pack.setBackground(Ui.stroke(Ui.SURFACE,10,this));Ui.press(pack);pack.setOnClickListener(v->DownloadActions.chooseBatchFast(this,anime,null,progressCached.optDouble("episode",1),anime.episodeList));row.addView(pack);}else if(anime.episodes>0)row.addView(Ui.text(this,String.valueOf(anime.episodes),13,Ui.PURPLE,true));body.addView(row);Ui.space(body,12);if(anime.episodeList.isEmpty()){LinearLayout card=card();card.addView(Ui.text(this,episodesLoaded?"Серии временно недоступны Попробуйте открыть просмотр":"Загружаем серии…",12,Ui.MUTED,false));body.addView(card);return;}if(episodeRecycler==null){episodeRecycler=new RecyclerView(this);episodeRecycler.setLayoutManager(new LinearLayoutManager(this));episodeRecycler.setHasFixedSize(false);episodeRecycler.setItemViewCacheSize(10);episodeRecycler.setNestedScrollingEnabled(true);episodeRecycler.setClipToPadding(false);episodeRecycler.setPadding(0,0,0,Ui.dp(this,6));episodeAdapter=new EpisodeAdapter();episodeRecycler.setAdapter(episodeAdapter);}RecyclerView rv=episodeRecycler;ViewParent oldParent=rv.getParent();if(oldParent instanceof ViewGroup)((ViewGroup)oldParent).removeView(rv);episodeAdapter.updateRows();int visible=Math.max(3,Math.min(8,anime.episodeList.size()));body.addView(rv,Ui.lp(this,-1,visible*78));if(anime.episodeList.size()>visible){Ui.space(body,7);body.addView(Ui.text(this,"Прокрутите список серий внутри блока",10,Ui.MUTED,false));}}
    private boolean futureEpisode(Anime.Episode ep) {
        if(ep==null)return false;
        if(!ep.streams.isEmpty()||!ep.variants.isEmpty()||(ep.lazy!=null&&!ep.lazy.isEmpty()&&!"future".equals(ep.lazy))||(ep.resolverUrl!=null&&!ep.resolverUrl.isEmpty())){
            ep.future=false;
            return false;
        }
        return ep.future;
    }

    private String episodeDate(Anime.Episode ep) {
        if (!ep.airDate.isEmpty()) return ep.airDate;
        return Math.round(ep.number) == anime.episodesAired + 1 && !anime.nextEpisodeAt.isEmpty()
                ? "Выйдет " + airText(anime.nextEpisodeAt) : "Дата уточняется";
    }

    private void planEpisode(Anime.Episode ep) {
        long due=0;
        if(Math.abs(ep.number-anime.episodesAired-1)<0.001) {
            try { due=java.time.OffsetDateTime.parse(anime.nextEpisodeAt).toInstant().toEpochMilli(); }
            catch(Exception ignored) {}
        }
        ScheduledDownloads.choose(this,anime,ep.number,due,episodeDate(ep));
    }

    private final class EpisodeAdapter extends RecyclerView.Adapter<EpisodeHolder> {
        private ArrayList<Anime.Episode> rows=new ArrayList<>();
        private ArrayList<String> signatures=new ArrayList<>();
        void updateRows() {
            ArrayList<Anime.Episode> next=new ArrayList<>();
            ArrayList<String> sig=new ArrayList<>();
            for(Anime.Episode ep:anime.episodeList) {
                if(ep==null)continue;
                next.add(ep);
                androidx.media3.exoplayer.offline.Download done=completed.get(DownloadHub.episodeKey(ep.number));
                boolean watch=futureEpisode(ep)&&SeriesWatcher.has(anime,ep.number);
                sig.add(ep.number+"|"+ep.name+"|"+futureEpisode(ep)+"|"+episodeDate(ep)+"|"+episodePoster(ep)+"|"+ep.duration+"|"+progressCached.optDouble("episode",-1)+"|"+(done==null?"":done.request.id)+"|"+watch+"|"+YoruApp.app().store.spoilerSafe());
            }
            ArrayList<Anime.Episode> old=rows;
            ArrayList<String> oldSig=signatures;
            DiffUtil.DiffResult diff=DiffUtil.calculateDiff(new DiffUtil.Callback() {
                public int getOldListSize(){return old.size();}
                public int getNewListSize(){return next.size();}
                public boolean areItemsTheSame(int a,int b){return Double.compare(old.get(a).number,next.get(b).number)==0;}
                public boolean areContentsTheSame(int a,int b){return oldSig.get(a).equals(sig.get(b));}
                public Object getChangePayload(int a,int b){return Boolean.TRUE;}
            });
            rows=next;signatures=sig;try{diff.dispatchUpdatesTo(this);}catch(Exception e){notifyDataSetChanged();}
        }
        public int getItemCount(){return rows.size();}
        public EpisodeHolder onCreateViewHolder(ViewGroup parent,int type){return new EpisodeHolder();}
        public void onBindViewHolder(EpisodeHolder holder,int position){holder.bind(rows.get(position));}
        public void onBindViewHolder(EpisodeHolder holder,int position,List<Object> payloads){holder.bind(rows.get(position));}
        public void onViewRecycled(EpisodeHolder holder){holder.episode=null;holder.imageKey="";holder.shot.setTag(null);holder.shot.setImageDrawable(null);}
    }

    private final class EpisodeHolder extends RecyclerView.ViewHolder {
        final LinearLayout outer,card;
        final ImageView shot;
        final TextView placeholder,play,title,subtitle,download;
        final Ui.Icon bell;
        Anime.Episode episode;
        String imageKey="";
        EpisodeHolder() {
            super(Ui.column(DetailsActivity.this));
            outer=(LinearLayout)itemView;
            outer.setLayoutParams(new RecyclerView.LayoutParams(-1,-2));
            outer.setPadding(0,0,0,Ui.dp(DetailsActivity.this,8));
            card=Ui.row(DetailsActivity.this);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(Ui.dp(DetailsActivity.this,10),Ui.dp(DetailsActivity.this,9),Ui.dp(DetailsActivity.this,10),Ui.dp(DetailsActivity.this,9));
            card.setBackground(Ui.stroke(Ui.CARD,14,DetailsActivity.this));
            FrameLayout preview=new FrameLayout(DetailsActivity.this);
            preview.setBackground(Ui.shape(Ui.SURFACE,12,DetailsActivity.this));preview.setClipToOutline(true);
            shot=new ImageView(DetailsActivity.this);shot.setScaleType(ImageView.ScaleType.CENTER_CROP);
            preview.addView(shot,new FrameLayout.LayoutParams(-1,-1));
            placeholder=Ui.text(DetailsActivity.this,"",11,Ui.PURPLE,true);placeholder.setGravity(Gravity.CENTER);placeholder.setMaxLines(3);
            preview.addView(placeholder,new FrameLayout.LayoutParams(-1,-1));
            play=Ui.text(DetailsActivity.this,"▶",15,0xff09090b,true);play.setGravity(Gravity.CENTER);play.setBackground(Ui.shape(0xffffffff,24,DetailsActivity.this));
            preview.addView(play,new FrameLayout.LayoutParams(Ui.dp(DetailsActivity.this,34),Ui.dp(DetailsActivity.this,34),Gravity.CENTER));
            LinearLayout.LayoutParams pp=Ui.lp(DetailsActivity.this,94,56);pp.rightMargin=Ui.dp(DetailsActivity.this,11);card.addView(preview,pp);
            LinearLayout text=Ui.column(DetailsActivity.this);
            title=Ui.text(DetailsActivity.this,"",12,Ui.TEXT,true);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);text.addView(title);
            Ui.space(text,4);subtitle=Ui.text(DetailsActivity.this,"",10,Ui.MUTED,false);text.addView(subtitle);
            card.addView(text,new LinearLayout.LayoutParams(0,-2,1));
            bell=new Ui.Icon(DetailsActivity.this,"bell");
            bell.setPadding(Ui.dp(DetailsActivity.this,8),Ui.dp(DetailsActivity.this,8),Ui.dp(DetailsActivity.this,8),Ui.dp(DetailsActivity.this,8));
            bell.setBackground(Ui.stroke(Ui.SURFACE,12,DetailsActivity.this));
            bell.setVisibility(View.GONE);
            bell.setOnClickListener(v->toggleWatch());
            Ui.press(bell);
            card.addView(bell,Ui.lp(DetailsActivity.this,40,40));
            download=Ui.text(DetailsActivity.this,"",10,Ui.PURPLE,true);download.setGravity(Gravity.CENTER);download.setMaxLines(3);
            download.setPadding(Ui.dp(DetailsActivity.this,8),Ui.dp(DetailsActivity.this,7),Ui.dp(DetailsActivity.this,8),Ui.dp(DetailsActivity.this,7));
            download.setBackground(Ui.stroke(Ui.SURFACE,10,DetailsActivity.this));card.addView(download);outer.addView(card);
            Ui.press(card);Ui.press(download);
            download.setOnClickListener(v->open(true));card.setOnClickListener(v->open(false));
            card.setOnLongClickListener(v->{
                Anime.Episode ep=episode;if(ep==null||futureEpisode(ep))return true;
                YoruApp.app().store.progress(anime,ep.number,0,0,"yoru","",true);YoruWidgetProvider.refresh(DetailsActivity.this);
                progressCached=YoruApp.app().store.progress(anime);episodeAdapter.updateRows();
                Ui.toast(DetailsActivity.this,"Отмечено: серия "+Ui.number(ep.number));return true;
            });
        }
        void open(boolean downloadAction) {
            Anime.Episode ep=episode;if(ep==null)return;
            boolean hasContent=!ep.streams.isEmpty()||!ep.variants.isEmpty()||(ep.lazy!=null&&!ep.lazy.isEmpty()&&!"future".equals(ep.lazy))||(ep.resolverUrl!=null&&!ep.resolverUrl.isEmpty());
            if(hasContent)ep.future=false;
            if(futureEpisode(ep)){if(downloadAction)planEpisode(ep);else Ui.toast(DetailsActivity.this,episodeDate(ep));return;}
            androidx.media3.exoplayer.offline.Download done=completed.get(DownloadHub.episodeKey(ep.number));
            if(done!=null)Ui.openOffline(DetailsActivity.this,done.request.id,anime,ep.number);
            else if(downloadAction)DownloadActions.prepare(DetailsActivity.this,anime,null,ep.number);
            else openWatch(ep.number,"yoru");
        }
        void bind(Anime.Episode ep) {
            episode=ep;boolean future=futureEpisode(ep);
            boolean current=Math.abs(progressCached.optDouble("episode",-9999)-ep.number)<0.001;
            String name=YoruApp.app().store.spoilerSafe()?"":ep.name;
            title.setText((current?"▶ ":"")+"Серия "+Ui.number(ep.number)+(name.isEmpty()?"":" · "+name));title.setTextColor(current?Ui.PURPLE:Ui.TEXT);
            subtitle.setText(future?episodeDate(ep):(ep.duration>0?Ui.time(ep.duration):""));
            String poster=future?"":episodePoster(ep);
            shot.setVisibility(poster.isEmpty()?View.GONE:View.VISIBLE);
            placeholder.setVisibility(poster.isEmpty()?View.VISIBLE:View.GONE);
            placeholder.setText(future?episodeDate(ep):"Серия\n"+Ui.number(ep.number));play.setVisibility(future?View.GONE:View.VISIBLE);
            String key=anime.key()+":"+ep.number+":"+poster;
            if(!key.equals(imageKey)) {
                imageKey=key;
                if(!poster.isEmpty()) {
                    YoruApp.app().images.load(shot,poster,key);
                } else {
                    shot.setImageDrawable(null);
                }
            }
            boolean done=completed.containsKey(DownloadHub.episodeKey(ep.number));
            download.setText(future?"Скачать\nпосле выхода":done?"Скачана":"Скачать");
            download.setEnabled(true);download.setAlpha(1f);
            download.setContentDescription((future?"Скачать после выхода, серия ":"Скачать серию ")+Ui.number(ep.number));
            boolean watched=false;
            if(future)watched=SeriesWatcher.has(anime,ep.number);
            bell.setVisibility(future?View.VISIBLE:View.GONE);
            bell.filled=watched;
            bell.color=watched?Ui.PURPLE:Ui.MUTED;
            bell.invalidate();
            bell.setContentDescription(watched?"Уведомление о выходе серии включено":"Включить уведомление о выходе серии");
        }
        void toggleWatch() {
            Anime.Episode ep=episode;
            if(ep==null)return;
            long due=0;
            if(Math.abs(ep.number-anime.episodesAired-1)<0.001) {
                try { due=java.time.OffsetDateTime.parse(anime.nextEpisodeAt).toInstant().toEpochMilli(); }
                catch(Exception ignored) {}
            }
            SeriesWatcher.toggle(DetailsActivity.this,anime,ep.number,due,episodeAdapter::updateRows);
        }
    }
    private LinearLayout card(){LinearLayout c=Ui.column(this);c.setPadding(Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,14));c.setBackground(Ui.stroke(Ui.CARD,14,this));return c;}


    private void about(){Ui.space(body,24);body.addView(Ui.text(this,"Об истории",21,Ui.TEXT,true));Ui.space(body,13);if(YoruApp.app().store.spoilerSafe()&&!anime.description.isEmpty()){LinearLayout c=card();c.addView(Ui.text(this,"Описание скрыто режимом без спойлеров",12,Ui.MUTED,false));Ui.space(c,9);c.addView(Ui.button(this,"Показать описание",false,()->{YoruApp.app().store.smartSetting("spoilerSafe",false);render();}));body.addView(c);return;}TextView description=Ui.text(this,anime.description.isEmpty()?"Описание пока недоступно":anime.description,14,Ui.ZINC,false);description.setLineSpacing(Ui.dp(this,5),1);body.addView(description);}
    private void trailer(){try{String url=ApiRepository.safeUrl(anime.trailerUrl);if(url.isEmpty())url="https://www.youtube.com/results?search_query="+Uri.encode(YoruBrain.title(anime)+" trailer");startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){Ui.toast(this,"Не удалось открыть трейлер");}}
    private void similar(){ArrayList<Anime> rows=YoruBrain.similar(anime,8);if(rows.isEmpty())return;Ui.space(body,26);body.addView(Ui.text(this,"Похожее",21,Ui.TEXT,true));Ui.space(body,12);HorizontalScrollView row=new HorizontalScrollView(this);row.setHorizontalScrollBarEnabled(false);LinearLayout list=Ui.row(this);for(Anime a:rows){LinearLayout item=Ui.column(this);item.setPadding(0,0,Ui.dp(this,10),0);Ui.Card card=new Ui.Card(this,160);card.bind(a);item.addView(card,Ui.lp(this,132,-2));list.addView(item);}row.addView(list);body.addView(row,Ui.lp(this,-1,-2));}
    private void related(){if(anime.related.isEmpty())return;ArrayList<Anime> rows=filteredRelated();Ui.space(body,27);LinearLayout title=Ui.row(this);title.addView(Ui.text(this,"Связанные аниме и фильмы",21,Ui.TEXT,true),new LinearLayout.LayoutParams(0,-2,1));Anime next=nextFranchise();if(next!=null){TextView cont=Ui.text(this,franchiseEnded()?"Продолжить":"Дальше",10,Ui.PURPLE,true);cont.setPadding(Ui.dp(this,9),Ui.dp(this,7),Ui.dp(this,9),Ui.dp(this,7));cont.setBackground(Ui.stroke(Ui.SURFACE,10,this));Ui.press(cont);cont.setOnClickListener(v->Ui.openDetails(this,next));title.addView(cont);}body.addView(title);Ui.space(body,10);body.addView(Ui.button(this,"Смотреть по порядку франшизу",false,()->{ArrayList<Anime> seq=franchiseSequence();if(!seq.isEmpty())Ui.openDetails(this,seq.get(0));}),Ui.lp(this,-1,-2));Ui.space(body,10);HorizontalScrollView wrap=new HorizontalScrollView(this);wrap.setHorizontalScrollBarEnabled(false);LinearLayout chips=Ui.row(this);String[][] fs={{"","Все"},{"season","Сезоны"},{"film","Фильмы"},{"ova","OVA"},{"special","Спешлы"}};for(String[] f:fs){TextView chip=Ui.chip(this,f[1],f[0].equals(relatedFilter),()->{relatedFilter=f[0];render();});LinearLayout.LayoutParams lp=Ui.lp(this,-2,-2);lp.rightMargin=Ui.dp(this,7);chips.addView(chip,lp);}wrap.addView(chips);body.addView(wrap,Ui.lp(this,-1,-2));Ui.space(body,12);if(rows.isEmpty()){LinearLayout c=card();c.addView(Ui.text(this,"В этом фильтре пока пусто",12,Ui.MUTED,false));body.addView(c);return;}for(Anime a:rows){LinearLayout row=Ui.row(this);row.setPadding(Ui.dp(this,13),Ui.dp(this,11),Ui.dp(this,13),Ui.dp(this,11));row.setBackground(Ui.stroke(Ui.CARD,15,this));ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);poster.setClipToOutline(true);poster.setBackground(Ui.shape(Ui.SURFACE,12,this));row.addView(poster,Ui.lp(this,48,68));YoruApp.app().images.load(poster,a);String when=a.airedDate==null||a.airedDate.isEmpty()?a.meta():(a.airedDate+" · "+a.type);TextView text=Ui.text(this,a.title+"\n"+when,12,Ui.TEXT,false);text.setPadding(Ui.dp(this,12),0,0,0);row.addView(text,new LinearLayout.LayoutParams(0,-2,1));Ui.Icon icon=new Ui.Icon(this,"play");icon.color=Ui.PURPLE;row.addView(icon,Ui.lp(this,24,24));Ui.press(row);row.setOnClickListener(v->Ui.openDetails(this,a));body.addView(row);Ui.space(body,9);}}
    private ArrayList<Anime> filteredRelated(){ArrayList<Anime> out=new ArrayList<>();for(Anime a:anime.related){String t=(a.type==null?"":a.type).toLowerCase(Locale.ROOT);boolean film=t.contains("фильм")||t.contains("movie");boolean ova=t.contains("ova");boolean special=t.contains("спеш")||t.contains("special");boolean season=!film&&!ova&&!special;if(relatedFilter.isEmpty()||"film".equals(relatedFilter)&&film||"ova".equals(relatedFilter)&&ova||"special".equals(relatedFilter)&&special||"season".equals(relatedFilter)&&season)out.add(a);}out.sort(this::franchiseCompare);return out;}
    private ArrayList<Anime> franchiseSequence(){LinkedHashMap<String,Anime> map=new LinkedHashMap<>();if(Anime.valid(anime))map.put(SourceEngine.identity(anime),anime);for(Anime a:anime.related)if(Anime.valid(a))map.put(SourceEngine.identity(a),a);ArrayList<Anime> rows=new ArrayList<>(map.values());rows.sort(this::franchiseCompare);return rows;}
    private Anime nextFranchise(){ArrayList<Anime> rows=franchiseSequence();String own=SourceEngine.identity(anime);for(int i=0;i<rows.size();i++)if(SourceEngine.identity(rows.get(i)).equals(own)&&i+1<rows.size())return rows.get(i+1);return null;}
    private boolean franchiseEnded(){double ep=progressCached.optDouble("episode",0);int end=anime.episodesAired>0?anime.episodesAired:anime.episodes;return end>0&&ep>=end;}
    private int franchiseCompare(Anime a,Anime b){int p=releaseOrder(a)-releaseOrder(b);if(p!=0)return p;p=kindRank(a)-kindRank(b);if(p!=0)return p;p=seasonNo(a)-seasonNo(b);if(p!=0)return p;return YoruBrain.title(a).compareToIgnoreCase(YoruBrain.title(b));}
    private int releaseOrder(Anime a){if(a==null)return 99999999;if(a.airedDate!=null&&a.airedDate.length()>=4)try{return Integer.parseInt(a.airedDate.substring(0,4))*10000+monthDay(a.airedDate);}catch(Exception ignored){}return a.year>0?a.year*10000:99999999;}
    private int monthDay(String d){try{return Integer.parseInt(d.substring(5,7))*100+Integer.parseInt(d.substring(8,10));}catch(Exception e){return 0;}}
    private int kindRank(Anime a){String t=(a==null?"":a.type).toLowerCase(Locale.ROOT);if(t.contains("тв")||t.contains("tv"))return 10;if(t.contains("ona"))return 30;if(t.contains("фильм")||t.contains("movie"))return 50;if(t.contains("ova"))return 60;if(t.contains("спеш")||t.contains("special"))return 70;return 40;}
    private int seasonNo(Anime a){String t=((a==null?"":a.title)+" "+(a==null?"":a.original)).toLowerCase(Locale.ROOT);java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?:season|сезон)\\s*(\\d+)|(\\d+)\\s*(?:st|nd|rd|th|й|я)?\\s*сезон").matcher(t);if(m.find()){String n=m.group(1)!=null?m.group(1):m.group(2);try{return Integer.parseInt(n);}catch(Exception ignored){}}if(t.contains("iii"))return 3;if(t.contains("ii"))return 2;if(t.contains("iv"))return 4;return 1;}
    private void prefetchRelated(){if(anime==null||anime.related.isEmpty())return;ArrayList<Anime> rows=new ArrayList<>(anime.related.subList(0,Math.min(24,anime.related.size())));YoruApp.app().discovery.execute(()->{try{YoruApp.app().api.prefetchQuickDetails(rows,rows.size());}catch(Exception ignored){}});}
    private boolean postersFilled;
    private boolean airedQueued;
    private void ensureAiredCount(){if(anime==null||airedQueued)return;if(anime.episodesAired>0||anime.finished())return;airedQueued=true;final int gen=generation;YoruApp.app().discovery.execute(()->{int[] box=new int[1];try{box[0]=YoruApp.app().api.airedEpisodes(anime);}catch(Exception ignored){}final int aired=box[0];YoruApp.app().main.post(()->{airedQueued=false;if(gen!=generation||isFinishing())return;if(aired>0&&anime.episodesAired!=aired){anime.episodesAired=aired;render();}});});}
    private void fillMissingPosters(){if(anime==null||postersFilled)return;int count=0;for(Anime.Episode e:anime.episodeList){if(e!=null&&!e.future&&(e.poster.isEmpty()||e.poster.equals(anime.poster)))count++;}if(count==0)return;final int missing=count;postersFilled=true;final int gen=generation;YoruApp.app().api.fillEpisodePosters(anime,()->{if(gen!=generation||isFinishing())return;int after=0;for(Anime.Episode e:anime.episodeList){if(e!=null&&!e.future&&(e.poster.isEmpty()||e.poster.equals(anime.poster)))after++;}if(after<missing&&episodeAdapter!=null){episodeAdapter.updateRows();YoruWidgetProvider.refresh(DetailsActivity.this);}});}
    private boolean franchiseQueued;
    private void ensureRelated(){if(anime==null||franchiseQueued)return;if(anime.related.size()>=15)return;franchiseQueued=true;final int gen=generation;final Anime snapshot=Anime.from(anime.json());YoruApp.app().api.refreshFranchise(snapshot,()->{if(gen!=generation||isFinishing())return;boolean added=false;for(Anime r:snapshot.related){if(r==null||!Anime.valid(r))continue;boolean has=false;for(Anime x:anime.related)if(x!=null&&x.key().equals(r.key())){has=true;break;}if(!has){anime.related.add(r);added=true;}}if(added){franchiseQueued=false;render();}});}
    private String airText(String raw){String v=raw==null?"":raw.trim();if(v.isEmpty()||v.equals("null"))return "дата уточняется";try{java.time.LocalDateTime t=java.time.OffsetDateTime.parse(v).atZoneSameInstant(java.time.ZoneId.of("Europe/Moscow")).toLocalDateTime();String[] m={"янв","фев","мар","апр","мая","июн","июл","авг","сен","окт","ноя","дек"};return String.format(java.util.Locale.ROOT,"%d %s, %02d:%02d МСК",t.getDayOfMonth(),m[Math.max(0,Math.min(11,t.getMonthValue()-1))],t.getHour(),t.getMinute());}catch(Exception ignored){}return v.replace('T',' ');}
    private int playableCount(Collection<Anime.Episode> rows){int n=0;if(rows!=null)for(Anime.Episode e:rows)if(e!=null&&!e.future)n++;return n;}
    private String episodeKey(double n){return n==Math.floor(n)?String.valueOf((int)Math.floor(n)):String.valueOf(n);}
    private void prepareEpisodeDisplay(){if(anime==null||anime.episodeList.isEmpty())return;int playable=0;LinkedHashSet<String> have=new LinkedHashSet<>();for(Anime.Episode e:anime.episodeList){if(e==null)continue;boolean hasContent=!e.streams.isEmpty()||!e.variants.isEmpty()||(e.lazy!=null&&!e.lazy.isEmpty()&&!"future".equals(e.lazy))||(e.resolverUrl!=null&&!e.resolverUrl.isEmpty());if(hasContent)e.future=false;if(!e.future)playable++;have.add(episodeKey(e.number));}if(playable<=0)return;int total=anime.episodes;int aired=Math.max(anime.episodesAired,playable);if(total<playable)total=playable;if(anime.finished()&&aired>0)total=aired;if(total<=0)return;if(aired<=0&&playable>0)aired=playable;if(aired>total)aired=total;anime.episodes=total;anime.episodesAired=Math.max(anime.episodesAired,aired);if(!anime.finished()&&playable>0){for(Anime.Episode e:anime.episodeList)if(e!=null&&e.number>aired+0.001&&!e.future&&e.streams.isEmpty()&&e.variants.isEmpty()&&(e.lazy==null||e.lazy.isEmpty()||"future".equals(e.lazy))&&(e.resolverUrl==null||e.resolverUrl.isEmpty()))markFutureLocal(e,futureText((int)Math.round(e.number),aired));if(aired<total){int max=Math.min(total,aired+24);for(int n=aired+1;n<=max;n++){String key=episodeKey(n);if(have.contains(key))continue;Anime.Episode ep=new Anime.Episode();ep.id=anime.id+"-future-"+n;ep.number=n;markFutureLocal(ep,futureText(n,aired));anime.episodeList.add(ep);}}}for(Anime.Episode e:anime.episodeList){if(e==null||e.future)continue;if(e.poster.equals(anime.poster))e.poster="";int idx=(int)Math.floor(e.number)-1;if(e.poster.isEmpty()&&idx>=0&&!anime.screenshots.isEmpty())e.poster=anime.screenshots.get(idx%anime.screenshots.size());}anime.episodeList.sort(Comparator.comparingDouble(e->e.number));}
    private void markFutureLocal(Anime.Episode ep,String label){ep.future=true;ep.airDate=label;ep.name=label;ep.poster="";ep.lazy="";ep.resolverUrl="";ep.duration=0;ep.streams.clear();ep.variants.clear();}
    private String futureText(int number,int aired){return number==aired+1&&!anime.nextEpisodeAt.isEmpty()?airText(anime.nextEpisodeAt):"Не вышла";}
    private String episodePoster(Anime.Episode ep){String p=ep==null?"":ApiRepository.safeUrl(ep.poster);if(!p.isEmpty()&&!p.equals(anime.poster))return p;if(ep!=null&&!anime.screenshots.isEmpty()){int idx=(int)Math.floor(ep.number)-1;if(idx>=0)return anime.screenshots.get(idx%anime.screenshots.size());}return "";}
    private void screenshots(){ArrayList<String> urls=anime.screenshots;if(urls.isEmpty()){urls=new ArrayList<>();for(Anime.Episode e:anime.episodeList){if(e==null||e.poster==null||e.poster.isEmpty()||e.poster.equals(anime.poster))continue;if(!urls.contains(e.poster))urls.add(e.poster);if(urls.size()>=12)break;}}if(urls.isEmpty())return;Ui.space(body,24);body.addView(Ui.text(this,"Скриншоты",21,Ui.TEXT,true));Ui.space(body,12);HorizontalScrollView row=new HorizontalScrollView(this);row.setHorizontalScrollBarEnabled(false);LinearLayout list=Ui.row(this);for(int i=0;i<Math.min(12,urls.size());i++){FrameLayout frame=new FrameLayout(this);frame.setBackground(Ui.shape(Ui.CARD,15,this));frame.setClipToOutline(true);ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);frame.addView(img,new FrameLayout.LayoutParams(-1,-1));String url=urls.get(i);YoruApp.app().images.load(img,url,anime.key()+":shot:"+i);final String open=url;frame.setOnClickListener(v->Ui.openImage(this,open,YoruBrain.title(anime)));Ui.press(frame);LinearLayout.LayoutParams lp=Ui.lp(this,194,109);lp.rightMargin=Ui.dp(this,9);list.addView(frame,lp);}row.addView(list);body.addView(row,Ui.lp(this,-1,-2));}
    private void trailerBlock(){Ui.space(body,24);body.addView(Ui.text(this,"Трейлер",21,Ui.TEXT,true));Ui.space(body,12);String url=ApiRepository.safeUrl(anime.trailerUrl);if(url.isEmpty()){LinearLayout c=card();c.addView(Ui.text(this,"Прямой трейлер пока не найден Можно открыть поиск трейлера по названию",12,Ui.MUTED,false));Ui.space(c,10);c.addView(Ui.button(this,"Найти трейлер",false,this::trailer));body.addView(c);return;}body.addView(Ui.button(this,"Смотреть трейлер",false,this::trailer),Ui.lp(this,-1,-2));}
    private String ratingLine(){return anime!=null&&anime.score>0?String.format(Locale.US,"★ %.1f",anime.score):"рейтинг уточняется";}
    private String defaultVoiceName(){String own=YoruApp.app().store.voiceFor(anime);String raw=own.isEmpty()?YoruApp.app().store.voicePreference():own;String title=ApiRepository.voiceLabel(raw);return title.isEmpty()?"Все озвучки":title;}
    private void voiceInfoCard(){LinearLayout row=Ui.row(this);row.setPadding(Ui.dp(this,13),Ui.dp(this,10),Ui.dp(this,13),Ui.dp(this,10));row.setBackground(Ui.stroke(Ui.CARD,14,this));String saved=defaultVoiceName();String label=(saved.equals("Все озвучки")?"Все доступные озвучки будут показаны в плеере":"Выбрана озвучка: "+saved)+" · "+ratingLine()+" · Разрешение: "+qualityName(YoruApp.app().store.quality());TextView text=Ui.text(this,label,11,Ui.TEXT,false);text.setLineSpacing(Ui.dp(this,3),1);row.addView(text,new LinearLayout.LayoutParams(0,-2,1));TextView edit=Ui.text(this,"Настройки",10,Ui.PURPLE,true);edit.setPadding(Ui.dp(this,10),Ui.dp(this,8),Ui.dp(this,10),Ui.dp(this,8));edit.setBackground(Ui.stroke(Ui.SURFACE,10,this));Ui.press(edit);edit.setOnClickListener(v->watchDefaults());row.addView(edit);body.addView(row);}
    private void openWatch(double number,String playMode){if(anime.blocked)return;androidx.media3.exoplayer.offline.Download done=completed.get(DownloadHub.episodeKey(number));if(done!=null){Ui.openOffline(this,done.request.id,anime,number);return;}Ui.openPlayer(this,anime,"henta".equals(anime.source)?"henta":"yoru",number);}
    private boolean dead(){return isFinishing()||isDestroyed();}
    private String qualityName(int q){return QualityPlus.name(q);}
    private int qualityIndex(int q){return QualityPlus.index(q);}
    private void watchDefaults(){LinearLayout col=Ui.column(this);col.setPadding(Ui.dp(this,4),0,Ui.dp(this,4),0);Spinner voice=new Spinner(this);voice.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ApiRepository.VOICE_PREF_NAMES));int vi=0;String cur=YoruApp.app().store.voicePreference();for(int i=0;i<ApiRepository.VOICE_PREF_VALUES.length;i++)if(ApiRepository.voiceKey(ApiRepository.VOICE_PREF_VALUES[i]).equals(ApiRepository.voiceKey(cur)))vi=i;voice.setSelection(vi);col.addView(Ui.text(this,"Озвучка по умолчанию",11,Ui.MUTED,false));col.addView(voice,Ui.lp(this,-1,46));Ui.space(col,10);Spinner quality=new Spinner(this);quality.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,QualityPlus.LABELS));quality.setSelection(qualityIndex(YoruApp.app().store.quality()));col.addView(Ui.text(this,"Разрешение по умолчанию",11,Ui.MUTED,false));col.addView(quality,Ui.lp(this,-1,46));Switch only=new Switch(this);only.setText("Открывать только выбранную озвучку");only.setTextColor(Ui.TEXT);only.setTextSize(13);only.setTypeface(Ui.typeface(this,false));only.setChecked(YoruApp.app().store.onlyPreferredVoice());col.addView(only,Ui.lp(this,-1,52));Ui.custom(this,"Просмотр",col,"Сохранить",()->{int[] qualities=QualityPlus.values();String value=ApiRepository.VOICE_PREF_VALUES[voice.getSelectedItemPosition()];YoruApp.app().store.voicePreference(value);if(!value.isEmpty())YoruApp.app().store.rememberVoice(value);YoruApp.app().store.onlyPreferredVoice(only.isChecked()&&!value.isEmpty());YoruApp.app().store.settings(qualities[quality.getSelectedItemPosition()],YoruApp.app().store.autoNext());Ui.toast(this,"Просмотр обновлён");render();},"Сбросить",()->{YoruApp.app().store.voicePreference("");YoruApp.app().store.onlyPreferredVoice(false);YoruApp.app().store.settings(720,true);Ui.toast(this,"Настройки сброшены");render();},"Отмена");}

    @Override protected void onDestroy(){generation++;downloadsGeneration++;if(detailFuture!=null)detailFuture.cancel(true);if(earlyPlayback!=null)earlyPlayback.cancel(true);if(downloadFuture!=null)downloadFuture.cancel(true);super.onDestroy();}
}
