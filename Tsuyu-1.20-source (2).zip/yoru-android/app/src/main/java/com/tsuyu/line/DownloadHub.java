package com.tsuyu.line;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import androidx.media3.common.*;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.offline.*;
import androidx.media3.exoplayer.scheduler.Requirements;
import org.json.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class DownloadHub {
    public static final int USER_PAUSED=1;
    public final DownloadManager manager;
    public static final class AudioSelection {
        public final String groupId,id,label,language;
        public final int trackIndex,roleFlags,selectionFlags,channelCount;
        public AudioSelection(String groupId,int trackIndex,String id,String label,String language,int roleFlags,int selectionFlags,int channelCount){this.groupId=groupId==null?"":groupId;this.trackIndex=trackIndex;this.id=id==null?"":id;this.label=label==null?"":label;this.language=language==null?"":language;this.roleFlags=roleFlags;this.selectionFlags=selectionFlags;this.channelCount=channelCount;}
    }
    private final Context context;private final MediaCache caches;private final Handler main=new Handler(Looper.getMainLooper());private final Set<String> preparing=Collections.synchronizedSet(new HashSet<>());private final Map<String,DownloadRequest> replacement=new ConcurrentHashMap<>();private final ConcurrentHashMap<String,Download> completedIndex=new ConcurrentHashMap<>();private volatile long indexAt;private final AtomicBoolean indexing=new AtomicBoolean(false);
    public DownloadHub(Context c,MediaCache cache){context=c.getApplicationContext();caches=cache;manager=new DownloadManager(context,caches.database(),caches.offline(),caches.http(),Executors.newFixedThreadPool(3));manager.setMaxParallelDownloads(3);applyRequirements();manager.addListener(new DownloadManager.Listener(){@Override public void onDownloadChanged(DownloadManager dm,Download d,Exception error){refreshIndexAsync();}@Override public void onDownloadRemoved(DownloadManager dm,Download d){DownloadRequest pending=replacement.remove(d.request.id);if(pending!=null)dm.addDownload(pending);refreshIndexAsync();}});refreshIndexAsync();}
    public void applyRequirements(){manager.setRequirements(new Requirements(Requirements.NETWORK|(YoruApp.app().store.wifiDownloads()?Requirements.NETWORK_UNMETERED:0)));}
    public List<Download> all(){ArrayList<Download> list=new ArrayList<>();DownloadCursor cursor=null;try{cursor=manager.getDownloadIndex().getDownloads();while(cursor.moveToNext())list.add(cursor.getDownload());}catch(IOException ignored){}finally{if(cursor!=null)cursor.close();}list.sort((a,b)->Long.compare(b.startTimeMs,a.startTimeMs));return list;}
    public Download get(String id){try{return manager.getDownloadIndex().getDownload(id);}catch(IOException e){return null;}}
    public static JSONObject metadata(Download d){try{return new JSONObject(new String(d.request.data,StandardCharsets.UTF_8));}catch(Exception e){return new JSONObject();}}
    public static String status(Download d){switch(d.state){case Download.STATE_COMPLETED:return "Готово к просмотру офлайн";case Download.STATE_DOWNLOADING:return "Скачивается";case Download.STATE_QUEUED:return "В очереди / ожидание сети";case Download.STATE_STOPPED:return "Приостановлено";case Download.STATE_FAILED:return "Не удалось скачать";case Download.STATE_REMOVING:return "Удаляется";case Download.STATE_RESTARTING:return "Перезапускается";default:return "Подготовка";}}
    public static String idFor(Anime source,Anime.Episode ep,int quality){return idFor(source,ep,quality,null);}
    private static String idFor(Anime source,Anime.Episode ep,int quality,AudioSelection audio){String input=source.key()+"|"+ep.id+"|"+ep.number+"|"+quality+"|"+ep.name;if(audio!=null)input+="|audio:"+audio.groupId+"|"+audio.trackIndex+"|"+audio.id+"|"+audio.label+"|"+audio.language;try{byte[] hash=MessageDigest.getInstance("SHA-256").digest(input.getBytes(StandardCharsets.UTF_8));StringBuilder out=new StringBuilder();for(byte b:hash)out.append(String.format(Locale.ROOT,"%02x",b&255));return out.toString();}catch(Exception e){return input.replace(':','_');}}
    public boolean preparing(String id){return preparing.contains(id);}
    private static String episodePoster(Anime catalog,Anime.Episode ep){String p=ep==null?"":ApiRepository.safeUrl(ep.poster);if(!p.isEmpty())return p;if(catalog!=null&&catalog.screenshots.size()>=2&&ep!=null)return catalog.screenshots.get(Math.abs((int)Math.floor(ep.number)-1)%catalog.screenshots.size());return "";}
    public void enqueue(Anime catalog,Anime source,Anime.Episode ep,int quality){enqueue(catalog,source,ep,quality,null);}
    public void enqueue(Anime catalog,Anime source,Anime.Episode ep,int quality,AudioSelection requestedAudio){int used=quality;String url=ep.streams.get(used);if(url==null||ApiRepository.safeUrl(url).isEmpty()){used=QualityPlus.bestAtOrBelow(ep.streams.keySet(),quality);if(used>0)url=ep.streams.get(used);}if(url==null||ApiRepository.safeUrl(url).isEmpty()){Ui.toast(context,"Серия пока не подготовлена для загрузки");return;}final int finalQuality=used;String id=idFor(source,ep,finalQuality,requestedAudio);Download exists=get(id);if(exists!=null&&exists.state==Download.STATE_COMPLETED){Ui.toast(context,"Эта серия уже скачана");return;}if(exists!=null&&exists.state!=Download.STATE_FAILED&&exists.state!=Download.STATE_STOPPED&&exists.state!=Download.STATE_REMOVING){Ui.toast(context,"Эта серия уже в очереди");return;}if(!preparing.add(id)){Ui.toast(context,"Серия уже подготавливается");return;}if(context.getFilesDir().getUsableSpace()<100L*1024*1024){preparing.remove(id);Ui.toast(context,"Недостаточно свободного места");return;}
        Ui.toast(context,"Подготавливаем серию к скачиванию…");try{JSONObject meta=new JSONObject().put("anime",catalog.json()).put("source",source.json()).put("episode",ep.number).put("episodeId",ep.id).put("title",ep.name).put("voice",ep.name).put("audioTrack",requestedAudio==null?"":requestedAudio.label).put("audioGroup",requestedAudio==null?"":requestedAudio.groupId).put("audioIndex",requestedAudio==null?-1:requestedAudio.trackIndex).put("audioId",requestedAudio==null?"":requestedAudio.id).put("audioLanguage",requestedAudio==null?"":requestedAudio.language).put("audioRoleFlags",requestedAudio==null?0:requestedAudio.roleFlags).put("audioSelectionFlags",requestedAudio==null?0:requestedAudio.selectionFlags).put("audioChannelCount",requestedAudio==null?0:requestedAudio.channelCount).put("episodePoster",episodePoster(catalog,ep)).put("quality",finalQuality).put("created",System.currentTimeMillis());MediaItem item=item(url);TrackSelectionParameters.Builder selection=new TrackSelectionParameters.Builder(context).setPreferredAudioLanguage(requestedAudio!=null&&!requestedAudio.language.isEmpty()?requestedAudio.language:"ru");if(finalQuality>0)selection.setMaxVideoSize(Integer.MAX_VALUE,finalQuality);else selection.setForceLowestBitrate(true);DownloadHelper helper=DownloadHelper.forMediaItem(item,selection.build(),new DefaultRenderersFactory(context),caches.http());helper.prepare(new DownloadHelper.Callback(){@Override public void onPrepared(DownloadHelper h){try{if(requestedAudio!=null)applyAudioSelection(h,requestedAudio,selection);DownloadRequest request=h.getDownloadRequest(id,meta.toString().getBytes(StandardCharsets.UTF_8));Download current=get(id);if(current!=null&&(current.state==Download.STATE_FAILED||current.state==Download.STATE_REMOVING)){replacement.put(id,request);DownloadService.sendRemoveDownload(context,YoruDownloadService.class,id,true);}else DownloadService.sendAddDownload(context,YoruDownloadService.class,request,true);DownloadService.sendResumeDownloads(context,YoruDownloadService.class,true);SourceEngine.record(source.source,true,0,1,1,finalQuality);Ui.toast(context,YoruApp.app().store.wifiDownloads()&&YoruApp.app().traffic.metered()?"Добавлено Ожидаем Wi-Fi":"Серия добавлена в загрузки");}catch(Exception e){Ui.toast(context,"Не удалось начать загрузку Попробуйте другой вариант");}finally{preparing.remove(id);h.release();}}@Override public void onPrepareError(DownloadHelper h,IOException error){preparing.remove(id);h.release();SourceEngine.record(source.source,false,0,0,0,finalQuality);Ui.toast(context,"Серию не удалось подготовить для офлайн Попробуйте другой вариант");}});}catch(Exception e){preparing.remove(id);SourceEngine.record(source.source,false,0,0,0,quality);Ui.toast(context,"Эта загрузка сейчас недоступна");}}
    private static void applyAudioSelection(DownloadHelper helper,AudioSelection desired,TrackSelectionParameters.Builder base){
        TrackSelectionParameters baseParameters=base.build();
        for(int period=0;period<helper.getPeriodCount();period++){
            TrackSelectionOverride match=findAudioOverride(helper.getTracks(period),desired);
            if(match==null)continue;
            TrackSelectionParameters parameters=baseParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_AUDIO,false).setOverrideForType(match).build();
            helper.replaceTrackSelections(period,parameters);
        }
    }
    private static TrackSelectionOverride findAudioOverride(Tracks tracks,AudioSelection desired){
        if(tracks==null||desired==null)return null;
        TrackSelectionOverride fallback=null;
        for(Tracks.Group group:tracks.getGroups()){
            if(group.getType()!=C.TRACK_TYPE_AUDIO)continue;
            TrackGroup mediaGroup=group.getMediaTrackGroup();
            int preferred=desired.trackIndex;
            if(preferred>=0&&preferred<group.length&&sameAudioFormat(mediaGroup.getFormat(preferred),desired)){
                TrackSelectionOverride match=new TrackSelectionOverride(mediaGroup,preferred);
                if(sameGroup(mediaGroup,desired))return match;
                if(fallback==null)fallback=match;
            }
            for(int i=0;i<group.length;i++)if(sameAudioFormat(mediaGroup.getFormat(i),desired)){
                TrackSelectionOverride match=new TrackSelectionOverride(mediaGroup,i);
                if(sameGroup(mediaGroup,desired))return match;
                if(fallback==null)fallback=match;
            }
        }
        return fallback;
    }
    private static boolean sameGroup(TrackGroup group,AudioSelection desired){return desired.groupId.isEmpty()||desired.groupId.equals(group.id);}
    private static boolean sameAudioFormat(Format format,AudioSelection desired){
        if(format==null)return false;
        if(!desired.id.isEmpty()&&desired.id.equals(format.id))return true;
        boolean label=desired.label.isEmpty()||desired.label.equals(format.label);
        boolean language=desired.language.isEmpty()||desired.language.equalsIgnoreCase(format.language==null?"":format.language);
        boolean channels=desired.channelCount<=0||desired.channelCount==format.channelCount;
        boolean role=desired.roleFlags==0||desired.roleFlags==format.roleFlags;
        return label&&language&&channels&&role;
    }

    public static MediaItem item(String uri){MediaItem.Builder b=new MediaItem.Builder().setUri(uri);String path=Uri.parse(uri).getPath();String p=path==null?"":path.toLowerCase(Locale.ROOT);String lower=uri.toLowerCase(Locale.ROOT);if(p.endsWith(".m3u8")||lower.contains(".m3u8")||lower.contains("vid.php"))b.setMimeType(MimeTypes.APPLICATION_M3U8);else if(p.endsWith(".mpd")||lower.contains(".mpd"))b.setMimeType(MimeTypes.APPLICATION_MPD);else if(p.endsWith(".mp4")||lower.contains(".mp4"))b.setMimeType(MimeTypes.VIDEO_MP4);return b.build();}
    public MediaItem offlineItem(Download download){return item(download.request.uri.toString()).buildUpon().setStreamKeys(download.request.streamKeys).setCustomCacheKey(download.request.customCacheKey).build();}
    public void pause(String id){DownloadService.sendSetStopReason(context,YoruDownloadService.class,id,USER_PAUSED,true);}
    public void resume(String id){DownloadService.sendSetStopReason(context,YoruDownloadService.class,id,Download.STOP_REASON_NONE,true);DownloadService.sendResumeDownloads(context,YoruDownloadService.class,true);}
    public void remove(String id){replacement.remove(id);DownloadService.sendRemoveDownload(context,YoruDownloadService.class,id,true);}
    private static AudioSelection audioFromMetadata(JSONObject meta){
        if(meta==null||!meta.has("audioGroup"))return null;
        String group=meta.optString("audioGroup","");
        if(group.isEmpty()&&meta.optString("audioId","").isEmpty()&&meta.optString("audioTrack","").isEmpty())return null;
        return new AudioSelection(group,meta.optInt("audioIndex",-1),meta.optString("audioId",""),meta.optString("audioTrack",""),meta.optString("audioLanguage",""),meta.optInt("audioRoleFlags",0),meta.optInt("audioSelectionFlags",0),meta.optInt("audioChannelCount",0));
    }

    public void retry(String id){Download d=get(id);if(d==null)return;JSONObject meta=metadata(d);Anime catalog=Anime.from(meta.optJSONObject("anime"));double number=meta.optDouble("episode",1);int quality=meta.optInt("quality",720);String voice=meta.optString("voice","");Ui.toast(context,"Обновляем варианты загрузки…");YoruApp.app().io.execute(()->{try{YoruApp.app().api.clearMemory();List<ApiRepository.DownloadOption> options=YoruApp.app().api.downloadOptions(catalog,null,number,voice,quality,!voice.isEmpty());ApiRepository.DownloadOption selected=null;for(ApiRepository.DownloadOption option:options){boolean sameVoice=voice.isEmpty()||ApiRepository.voiceMatches(voice,option.voice+" "+option.episode.name);if(option.quality==quality&&sameVoice){selected=option;break;}}if(selected==null)for(ApiRepository.DownloadOption option:options)if(option.quality==quality){selected=option;break;}if(selected==null&&!options.isEmpty())selected=options.get(0);if(selected==null)throw new IOException();ApiRepository.DownloadOption ready=selected;AudioSelection audio=audioFromMetadata(meta);main.post(()->enqueue(catalog,ready.source,ready.episode,ready.quality,audio));}catch(Exception e){main.post(()->Ui.toast(context,"Tsuyu не смог обновить видео Можно удалить загрузку и выбрать другой вариант"));}});}

    public void pauseAll(){for(Download d:all())if(d!=null&&d.request!=null&&d.state!=Download.STATE_COMPLETED&&d.state!=Download.STATE_REMOVING)pause(d.request.id);}
    public void resumeAll(){try{DownloadService.sendSetStopReason(context,YoruDownloadService.class,null,Download.STOP_REASON_NONE,true);DownloadService.sendResumeDownloads(context,YoruDownloadService.class,true);}catch(Exception ignored){}}
    public void retryFailed(){for(Download d:all())if(d!=null&&d.request!=null&&d.state==Download.STATE_FAILED)retry(d.request.id);}
    public void removeCompleted(){for(Download d:all())if(d!=null&&d.request!=null&&d.state==Download.STATE_COMPLETED)remove(d.request.id);}
    public Download neighbour(Download current,int direction){JSONObject own=metadata(current);Anime a=Anime.from(own.optJSONObject("anime"));double number=own.optDouble("episode",1)+direction;Download best=null;for(Download d:all()){if(d.state!=Download.STATE_COMPLETED)continue;JSONObject m=metadata(d);Anime b=Anime.from(m.optJSONObject("anime"));if(a.key().equals(b.key())&&Double.compare(m.optDouble("episode",-1),number)==0){best=d;if(m.optInt("quality")==own.optInt("quality"))break;}}return best;}
    public void refreshIndexAsync(){if(!indexing.compareAndSet(false,true))return;YoruApp.app().ui.execute(()->{try{rebuildIndex();}finally{indexing.set(false);}});}
    private void rebuildIndex(){ConcurrentHashMap<String,Download> next=new ConcurrentHashMap<>();JSONArray mirror=new JSONArray();for(Download d:all()){if(d==null||d.request==null||d.state!=Download.STATE_COMPLETED)continue;JSONObject m=metadata(d);Anime parent=Anime.from(m.optJSONObject("anime")),source=Anime.from(m.optJSONObject("source"));double ep=m.optDouble("episode",-1);putIndex(next,parent,ep,d,m);putIndex(next,source,ep,d,m);try{mirror.put(new JSONObject().put("id",d.request.id).put("anime",parent.json()).put("source",source.json()).put("episode",ep).put("quality",m.optInt("quality",0)).put("updated",System.currentTimeMillis()));}catch(Exception ignored){}}completedIndex.clear();completedIndex.putAll(next);indexAt=System.currentTimeMillis();try{YoruApp.app().cache.offline(mirror.toString());}catch(Exception ignored){}}
    private static void putIndex(ConcurrentHashMap<String,Download> map,Anime a,double ep,Download d,JSONObject meta){if(!Anime.valid(a)||ep<0)return;String e=episodeKey(ep);ArrayList<String> keys=new ArrayList<>();keys.add(a.key());keys.add(SourceEngine.identity(a));if(a.malId>0)keys.add("mal:"+a.malId);if(a.anilistId>0)keys.add("ani:"+a.anilistId);if(a.kpId>0)keys.add("kp:"+a.kpId);for(String k:keys){if(k==null||k.isEmpty())continue;String id=k+"|"+e;Download old=map.get(id);if(old==null||metadata(old).optInt("quality")<meta.optInt("quality"))map.put(id,d);}}
    private ArrayList<String> lookupKeys(Anime a,double episode){ArrayList<String> keys=new ArrayList<>();if(!Anime.valid(a))return keys;String e=episodeKey(episode);keys.add(a.key()+"|"+e);keys.add(SourceEngine.identity(a)+"|"+e);if(a.malId>0)keys.add("mal:"+a.malId+"|"+e);if(a.anilistId>0)keys.add("ani:"+a.anilistId+"|"+e);if(a.kpId>0)keys.add("kp:"+a.kpId+"|"+e);return keys;}
    public HashMap<String,Download> completedEpisodes(Anime a){HashMap<String,Download> out=new HashMap<>();if(!Anime.valid(a))return out;if(indexAt==0||System.currentTimeMillis()-indexAt>90_000)refreshIndexAsync();String[] prefixes={a.key()+"|",SourceEngine.identity(a)+"|",a.malId>0?"mal:"+a.malId+"|":"",a.anilistId>0?"ani:"+a.anilistId+"|":"",a.kpId>0?"kp:"+a.kpId+"|":""};for(Map.Entry<String,Download> e:completedIndex.entrySet()){for(String p:prefixes)if(!p.isEmpty()&&e.getKey().startsWith(p)){String ep=e.getKey().substring(p.length());Download old=out.get(ep);if(old==null||metadata(old).optInt("quality")<metadata(e.getValue()).optInt("quality"))out.put(ep,e.getValue());break;}}return out;}
    public static String episodeKey(double episode){return Math.abs(episode-Math.floor(episode))<0.001?String.valueOf((int)Math.floor(episode)):String.valueOf(episode);}
    public Download findCompleted(Anime a,double episode){if(indexAt==0||System.currentTimeMillis()-indexAt>90_000)refreshIndexAsync();for(String key:lookupKeys(a,episode)){Download d=completedIndex.get(key);if(d!=null)return d;}if(Looper.myLooper()==Looper.getMainLooper())return null;HashMap<String,Download> rows=completedEpisodes(a);return rows.get(episodeKey(episode));}
}
