package com.tsuyu.line;

import android.app.*;
import android.app.job.*;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.os.*;
import android.widget.*;
import org.json.*;
import java.util.*;

final class ScheduledDownloads extends SQLiteOpenHelper {
    static final int JOB = 2710;
    static final long PERIOD = 15L * 60 * 1000;

    ScheduledDownloads(Context context) {
        super(context.getApplicationContext(), "scheduled-downloads.db", null, 1);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL(Sec.s("17213038211645373327380e45095e515c457c1a115921163d375235260228386069127d112a5959143d0c0e1745200e3d2d127e7d62743d2035397f4506020c0724011c1262777718533b3621732b363e29586b13165b53571600362d2d551d2a37522b2107295512414757381a0100551a2b373722311945377d641278013f395555371006522c3a1f203e776212781b275537201f294f520b11331126515857553f533c372116222620453a0431597c657e7a7853060d1427004326202c1f45377d641278013f3955553e00100104132e452d776866161a3c21593b06292f5e4517390018465556161d3d213c321637433c2a206b2b2c7e7c1b"));
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    static final class Plan {
        String id, voice, state, message;
        Anime anime;
        double episode;
        int quality;
        long due, next;
        String downloadId() { return "planned-" + id; }
        String label() {
            return YoruBrain.title(anime) + " · серия " + Ui.number(episode) + "\n"
                    + (voice.isEmpty() ? "Любая доступная озвучка" : voice) + " · "
                    + (quality == QualityPlus.BEST ? "Лучшее доступное" : QualityPlus.name(quality)) + "\n" + message;
        }
    }

    List<Plan> all() {
        ArrayList<Plan> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(Sec.s("0736393c36074549522326042859425c535827533a2b31163743303c5428171c53445752"), null)) {
            while (c.moveToNext()) {
                try {
                    Plan p = new Plan();
                    p.id = c.getString(c.getColumnIndexOrThrow("id"));
                    p.anime = Anime.from(new JSONObject(c.getString(c.getColumnIndexOrThrow("anime"))));
                    p.episode = c.getDouble(c.getColumnIndexOrThrow("episode"));
                    p.voice = c.getString(c.getColumnIndexOrThrow("voice"));
                    p.quality = c.getInt(c.getColumnIndexOrThrow("quality"));
                    p.due = c.getLong(c.getColumnIndexOrThrow("due"));
                    p.next = c.getLong(c.getColumnIndexOrThrow("next_check"));
                    p.state = c.getString(c.getColumnIndexOrThrow("state"));
                    p.message = c.getString(c.getColumnIndexOrThrow("message"));
                    if (Anime.valid(p.anime)) out.add(p);
                } catch (JSONException ignored) {}
            }
        }
        return out;
    }

    boolean exists(String id) {
        try (Cursor c = getReadableDatabase().rawQuery(Sec.s("0736393c3607450a164532192a3412405e573a00552e3d163726520c10765a"), new String[]{id})) {
            return c.moveToFirst();
        }
    }

    void add(Anime anime, double episode, String voice, int quality, long due) {
        if (!Anime.valid(anime) || !Double.isFinite(episode) || episode <= 0) throw new IllegalArgumentException();
        String identity = SourceEngine.identity(anime) + "|" + Double.toString(episode);
        String id = UUID.nameUUIDFromBytes(identity.getBytes(java.nio.charset.StandardCharsets.UTF_8)).toString();
        if (exists(id)) throw new IllegalStateException("already planned");
        ContentValues v = new ContentValues();
        v.put("id", id);
        v.put("anime", anime.json().toString());
        v.put("episode", episode);
        v.put("voice", voice);
        v.put("quality", quality);
        v.put("due", Math.max(0, due));
        v.put("next_check", Math.max(System.currentTimeMillis(), due));
        v.put("state", "waiting");
        v.put("message", "Ожидает выхода серии и выбранного варианта");
        v.put(Sec.s("37011018013601"), System.currentTimeMillis());
        getWritableDatabase().insertOrThrow("plans", null, v);
    }

    void update(String id, String state, String message, long next) {
        ContentValues v = new ContentValues();
        v.put("state", state);
        v.put("message", message);
        v.put("next_check", next);
        getWritableDatabase().update("plans", v, "id=?", new String[]{id});
    }

    void remove(String id) { getWritableDatabase().delete("plans", "id=?", new String[]{id}); }

    static boolean schedule(Context context) {
        Context c = context.getApplicationContext();
        try (ScheduledDownloads store = new ScheduledDownloads(c)) {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return false;
            boolean pending = false;
            for (Plan p : store.all()) if (!p.state.equals("queued")) { pending = true; break; }
            if (!pending) { js.cancel(JOB); return true; }
            JobInfo existing = js.getPendingJob(JOB);
            if (existing != null) return true;
            JobInfo job = new JobInfo.Builder(JOB, new ComponentName(c, ScheduledDownloadJob.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true)
                    .setPeriodic(PERIOD, 5L * 60 * 1000)
                    .setBackoffCriteria(PERIOD, JobInfo.BACKOFF_POLICY_EXPONENTIAL).build();
            return js.schedule(job)==JobScheduler.RESULT_SUCCESS;
        } catch(Exception e) { return false; }
    }

    static void choose(Activity activity, Anime anime, double episode, long due, String date) {
        if (!Anime.valid(anime)) return;
        LinearLayout col = Ui.column(activity);
        col.addView(Ui.text(activity, date == null || date.isEmpty() ? "Дата выхода уточняется" : date, 12, Ui.PURPLE, true));
        Ui.space(col,12);
        col.addView(Ui.text(activity, "Озвучка", 12, Ui.MUTED, false));
        Spinner voice = new Spinner(activity);
        String[] voices = ApiRepository.VOICE_PREF_NAMES.clone();
        voices[0] = "Любая доступная";
        voice.setAdapter(new ArrayAdapter<>(activity, android.R.layout.simple_spinner_dropdown_item, voices));
        String pref = YoruApp.app().store.voicePreference();
        for (int i=0;i<ApiRepository.VOICE_PREF_VALUES.length;i++) if (ApiRepository.VOICE_PREF_VALUES[i].equals(pref)) voice.setSelection(i);
        col.addView(voice, Ui.lp(activity,-1,48));
        col.addView(Ui.text(activity, "Качество", 12, Ui.MUTED, false));
        Spinner quality = new Spinner(activity);
        quality.setAdapter(new ArrayAdapter<>(activity,android.R.layout.simple_spinner_dropdown_item,QualityPlus.LABELS_WITH_BEST));
        quality.setSelection(QualityPlus.index(YoruApp.app().store.downloadResolution()));
        col.addView(quality,Ui.lp(activity,-1,48));
        Ui.space(col,10);
        col.addView(Ui.text(activity,Sec.s("97e3b7e8b6c2a7e0b1f5b6ffa6e9f085f1a696cf55bae591d3a0e2a7c088f5bb82f3a3f4d6b0e4bbf973a6f3b0ddb7dba7c5f1a0f08397e3b7c4b6c3a7deb1f5b6f545baa2f280f5c5b1febae591d4a0e3a7f488f5bb82f3a2f4e9b0e5bbc890f4a1f1a6e589eb59f1a0f08897e3b7ceb6c3a7d1b1f4b6c8a6e8f0b7f1a696c9b6e8b7d045a0e2a7cc6ba6e8f0b0f1a696c3b6e9b7e4a6f2b0e5b7dba7ccf1a1f0be97e3b7ccb6c3a7deb1f5b6f3a6e9f0851e1697e3b7c8b6c3a7d6b1f5b6fc45baa2f28df5c4b1cbbae591d1a0e2a7c888f5bb87f3a2f4e9b0e4bbfe73a6f3b0f1b7dba7c7f1a1f0b797e2b7fbb6c2a7e0b1f5b6f4a6e9f08df1a696cdb6e8b7d2a6f2b0e7b7daa7f512f3a2f4e5b0e4bbf690f5a1c6a6e589e6baa3f2bbf5c4b1c0bae591dc43b1f5b6f5a6e9f087f1a696c1b6e8b7d0a6f2b0e2b7dba7c3f1a0f08e74b0e5bbc890f5a1c745b7dba7caf1a0f08697e2b7f9b6c3a7d3b1f5b6f6a6e8f0b2f1a696cbb6e8b7d3a6f3b0dbb7dba7cbf1a0f08697e3b7c4b6c3a7d352a6e489fabaa3f2b2f5c4b1cbbae591d7a0e2a7c188f4bbb2f3a2f4eeb0e5bbcd73a6f3b0ddb7dba7cdf1a1f0b597e2b7fb5590f5a1c045b7daa7fdf1a0f08897e3b7c4b6c3a7d652a6e489dabaa3f2b2f5c4b1cd59b6c3a7deb1f5b6fba6e9f08bf1a696cbb6e8b7d4a6f3b0ddb7dba7c112f3a3f4d5b0e5bbc090f4a1f0a6e489dd4212715c52261c1c1d5590f5a1cea6e489dbbaa2f284f5c4b1c0bae491e743b1f5b6f3a6e8f0b512f5c4b1c2bae591d5a0e2a7c088f5bb87f3a3f4d4b0e5bbc390f5a1caa6e489d7baa2f282f5c5b1f7bae491e943b1f5b6e8a6e8f0b7f1a696cbb6e8b7d1a6f2b0eeb7dba7cbf1a0f08697e3b7ccb6c2a7e1b1f4b6caa6e8f0bf12f5c4b1c8bae591d5a0e3a7f588f4bbb0f3a3f4d4b0e5bbcb90f5a1cba6e489dfbaa2f2821697f1b7d2b6c3a7f4b1f5b6fba6e9f083f1a796f3b6e8b7d0a6f3b0d2b7dba7c3f1a0f08e74b0e4bbf790f5a1cca6e489debaa3f2bef5c4b1cfbae591db43b1f5b6f4a6e9f08e12613d5e3310b6d1a7d852a6e489fabaa2f28cf5c5b1f4bae591dea0e2a7c16ba6e9f08ff1a796f3b6e9b7eba6f3b0d8b7daa7faf1a0f08297e3b7c1b6c2a7e1b1f5b6fea6e9f08bf1a796ffb6e9b7eea6f3b0dbb7dba7c012f3a2f4eab0e4bbf490f4a1f0a6e489d5baa2f28ff5c4b1cbbae591d7a0e2a7ce88f5bb8a10f1a696ccb6e8b7d3a6f3b0ddb7dba7c2f1a0f08897e3b7cfb6c3a7d6b1f5b6f6a6e9f088f1a796fc55bae591dba0e3a7f688f5bb88f3a3f4d4b0e5bbcb90f5a1cba6e589e7baa2f28716000000000073a6f2b0e4b7dba7c4f1a0f08897e3b7cbb6c3a7d3"),11,Ui.MUTED,false));
        Ui.custom(activity,"Скачать серию " + Ui.number(episode) + " после выхода",col,"Запланировать",()->{
            String selectedVoice = ApiRepository.VOICE_PREF_VALUES[voice.getSelectedItemPosition()];
            int selectedQuality = QualityPlus.valuesWithBest()[quality.getSelectedItemPosition()];
            Runnable save = () -> {
                if (Build.VERSION.SDK_INT >= 33 && activity.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                    activity.requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},4101);
                YoruApp.app().io.execute(()->{
                    String message;
                    try (ScheduledDownloads store = new ScheduledDownloads(activity)) {
                        store.add(anime,episode,selectedVoice,selectedQuality,due);
                        boolean scheduled=schedule(activity);
                        message=scheduled?"Запланировано Карточка задания — в разделе «Загрузки»":Sec.s("97e3b7e6b6c3a7d8b1f5b6fba6e9f08d12f5c5b1f4bae591dba0e3a7f188f4bbb2f3a2f4e4b0e5bbc890f4a1e3a6e489d85512f3a2f4e9b0e5bbcb73240d16171b220159f1a0f08b97e3b7cc5590f4a1f2a6e489d5baa2f285f5c5b1f5bae591d0a0e3a7fc88f5bb8af3a2f4ef53b6e8b7d7a6f3b0dbb7dba7c4f1a0f08897e3b7cbb6c2a7e0b1f4b6c545baa2f28df5c5b1f5bae591dba0e2a7c688f5bb87f3a3f4d4b0e5bbcf90f4a1f145b7dba7e7f1a1f0b497e3b7c3b6c2a7e3b1f5b6f5a6e9f089f1a796f1b6e9b7e6453701100d3e45baa2f28df5c4b1cbbae591d2a0e2a7c288f5bb87");
                    } catch (IllegalStateException e) { message="Эта серия уже запланирована Отмените задание на его карточке в «Загрузках»"; }
                    catch (Exception e) { message="Не удалось сохранить план скачивания"; }
                    String result=message;
                    YoruApp.app().main.post(()->{if(!activity.isDestroyed())Ui.toast(activity,result);});
                });
            };
            if (!YoruApp.app().store.wifiDownloads()) Ui.confirm(activity,"Автоскачивание через мобильную сеть?","Когда серия появится, загрузка может использовать мобильный интернет Ограничить её Wi-Fi можно в настройках","Запланировать",save,"Отмена");
            else save.run();
        },null,null,"Отмена");
    }

    static void showQueue(Activity activity) {
        YoruApp.app().io.execute(()->{
            List<Plan> rows;
            try (ScheduledDownloads store = new ScheduledDownloads(activity)) { rows=store.all(); }
            catch (Exception e) { YoruApp.app().main.post(()->{if(!activity.isDestroyed())Ui.toast(activity,"Не удалось прочитать очередь");}); return; }
            YoruApp.app().main.post(()->{
                if(activity.isFinishing()||activity.isDestroyed())return;
                if(rows.isEmpty()){Ui.message(activity,"Будущие скачивания","Выберите будущую серию в карточке аниме или нажмите кнопку скачивания у события в календаре");return;}
                String[] labels=new String[rows.size()];
                for(int i=0;i<rows.size();i++)labels[i]=rows.get(i).label();
                Ui.choices(activity,"Будущие скачивания",labels,index->{
                    Plan p=rows.get(index);
                    Ui.confirm(activity,p.state.equals("queued")?"Убрать запись плана?":"Отменить ожидание серии?",p.label()+"\nУже переданная в загрузки серия управляется отдельно в списке загрузок","Убрать",()->YoruApp.app().io.execute(()->{
                        try(ScheduledDownloads store=new ScheduledDownloads(activity)){store.remove(p.id);schedule(activity);}
                        catch(Exception e){YoruApp.app().main.post(()->Ui.toast(activity,"Не удалось удалить план"));return;}
                        YoruApp.app().main.post(()->{if(!activity.isDestroyed())showQueue(activity);});
                    }),"Назад");
                });
            });
        });
    }
}
