package com.tsuyu.line;

/**
 * The native runtime checks are kept separate from application data handling.
 * No Java-side string or asset obfuscation is used.
 */
public final class NativeChecks {
    private static volatile boolean nativeLoaded;

    static {
        try {
            System.loadLibrary("c++_shared");
            nativeLoaded = true;
        } catch (Throwable ignored) {
            nativeLoaded = false;
        }
    }

    private static native boolean c();

    private NativeChecks() {}

    /** Returns the result of the optional native runtime check. */
    public static boolean check() {
        if (nativeLoaded) {
            try {
                return c();
            } catch (Throwable ignored) {
                // A missing optional native check must not break playback.
            }
        }
        return true;
    }
}
