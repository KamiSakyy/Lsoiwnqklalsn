package com.tsuyu.line;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.*;
import android.net.*;
import android.net.http.SslError;
import android.os.*;
import android.util.Rational;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import androidx.media3.common.*;
import androidx.media3.exoplayer.*;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.offline.Download;
import androidx.media3.ui.PlayerView;
import java.util.*;
import java.security.SecureRandom;

public final class PlayerActivity extends Activity {
    private final TaskQueue.Scope playbackTasks=new TaskQueue.Scope();
    private void playbackTask(Runnable work){playbackTasks.submit(YoruApp.app().io,work,()->error("Очередь занята Повторите запуск серии"));}

    private Anime anime;private Anime.Playback playback;private Anime.Episode episode;
    private String mode="auto",dubbing="",yummyVersion="",currentUrl="",currentVariantKey="",bridgeNonce="",prewarmKey="";private int generation,quality=720,seekMs,rescueTries;private double wantedEpisode=1;private boolean nativeMode,setup,playing,pausedByLife,enteringPip,destroyed,trustedKodik,openingSkipped;private long lastSaved,lastBridge,lastSoftSaved,lastPrewarmAt,sleepAt;private int browserTime,browserDuration;
    private LinearLayout root,main,selectors,epRow,qualityRow,topControls,bottomControls,nextList;private FrameLayout stage,overlayRoot,playerControls;private PlayerView video;private ExoPlayer player;private String offlineId;private Download offlineDownload;private boolean registeredPlayer,webConfirmed,yummyFrame,webActuallyPlaying,webPausedByLife;private WebView web;private LinearLayout loading;private TextView status,title,skip,downloadButton,speedButton,qualityButton,voiceButton,seekHint,timeLabel;private SeekBar timeline;private View prev,next;private float speed=1f,touchStartX,touchStartY,touchStartBrightness;private int touchStartVolume;private boolean swipeAdjusting,seekingByUser;private Spinner sourceSelect,episodeSelect,voiceSelect,qualitySelect;
    private View customView,fullView;private GestureDetector gestures;private ViewGroup fullParent;private int fullIndex,oldSystemUi,oldOrientation=ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;private ViewGroup.LayoutParams fullParams;private boolean fullPlayer,fillVideo;private Ui.Icon playPauseIcon,fullscreenIcon,resizeIcon;private WebChromeClient.CustomViewCallback customCallback;private final Handler timer=new Handler(Looper.getMainLooper());private final Runnable hideControls=()->{if(playerControls!=null&&isPlayingNow()&&!isInPictureInPictureMode()&&!seekingByUser)playerControls.setVisibility(View.GONE);};private final LinkedHashMap<String,String> capturedDownloads=new LinkedHashMap<>();private static final class AudioChoice {
        final Tracks.Group group;
        final int index;
        final Anime.Variant variant;
        final String label;
        final boolean direct;
        AudioChoice(Tracks.Group g,int i,String l){group=g;index=i;variant=null;label=l;direct=false;}
        AudioChoice(Anime.Variant v,String l){this(v,l,false);}
        AudioChoice(Anime.Variant v,String l,boolean d){group=null;index=-1;variant=v;label=l;direct=d;}
    }
    private final ArrayList<AudioChoice> audioChoices=new ArrayList<>();
    private String audioSignature="";
    private boolean audioPreferenceApplied;
private static PlayerActivity active;private static final String ACTION_TOGGLE="com.tsuyu.line.PIP_TOGGLE",ACTION_BACK="com.tsuyu.line.PIP_BACK",ACTION_FORWARD="com.tsuyu.line.PIP_FORWARD";
    private final Runnable networkPolicy=()->{};
        private final Runnable tick=new Runnable(){public void run(){if(destroyed)return;if(sleepAt>0&&System.currentTimeMillis()>=sleepAt){sleepAt=0;if(nativeMode&&player!=null)player.pause();else if(web!=null&&yummyFrame)web.evaluateJavascript("if(window.__yoruPause)window.__yoruPause();",null);Ui.toast(PlayerActivity.this,"Таймер сна поставил просмотр на паузу");updatePlayerControls();}if(nativeMode&&video!=null){if(player.isPlaying())playing=true;softSave();updateTimeline();maybePrewarmNextThrottled();if(episode!=null){int now=(int)(player.getCurrentPosition()/1000);boolean inOpening=episode.openingEnd>episode.openingStart&&now>=episode.openingStart&&now<episode.openingEnd;skip.setVisibility(inOpening?View.VISIBLE:View.GONE);if(inOpening&&YoruApp.app().store.autoSkipOpening()&&!openingSkipped){openingSkipped=true;player.seekTo(episode.openingEnd*1000L);Ui.toast(PlayerActivity.this,"Заставка пропущена");}}}timer.postDelayed(this,1000);}};
    @Override public void onCreate(Bundle state){super.onCreate(state);if(!Ui.allow(this))return;try{YoruApp.app().focusNow("player");}catch(Exception ignored){}offlineId=getIntent().getStringExtra("downloadId");anime=Ui.intentAnime(this);if(offlineId!=null){offlineDownload=YoruApp.app().downloads().get(offlineId);if(offlineDownload!=null)anime=Anime.from(DownloadHub.metadata(offlineDownload).optJSONObject("anime"));}if(!Anime.valid(anime)){finish();return;}registeredPlayer=true;active=this;YoruApp.app().activePlayers++;YoruApp.app().traffic.addListener(networkPolicy);String requestedMode=getIntent().getStringExtra("mode");mode="yoru";JSONObject old=YoruApp.app().store.progress(anime);wantedEpisode=getIntent().getDoubleExtra("episode",old.optDouble("episode",1));if(!Double.isFinite(wantedEpisode)||wantedEpisode<0)wantedEpisode=1;long customSeek=getIntent().getLongExtra("seekMs",-1);if(customSeek>=0)seekMs=(int)customSeek;else seekMs=Double.compare(wantedEpisode,old.optDouble("episode",-1))==0?old.optInt("time")*1000:0;quality=YoruApp.app().store.quality();speed=YoruApp.app().store.playbackSpeed();getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);int sleep=YoruApp.app().store.sleepTimer();if(sleep>0)sleepAt=System.currentTimeMillis()+sleep*60L*1000L;build();if(offlineId!=null)loadOffline(offlineId);else loadMode(mode);timer.postDelayed(tick,1000);}
    private void build(){root=Ui.base(this);LinearLayout top=Ui.row(this);top.setPadding(Ui.dp(this,13),Ui.dp(this,8),Ui.dp(this,13),Ui.dp(this,8));top.addView(Ui.iconButton(this,"back","Назад",this::finish),Ui.lp(this,44,44));title=Ui.text(this,YoruBrain.title(anime),15,Ui.TEXT,true);title.setMaxLines(2);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1);tp.leftMargin=Ui.dp(this,12);tp.rightMargin=Ui.dp(this,8);top.addView(title,tp);top.addView(Ui.iconButton(this,"heart","В коллекцию",()->Ui.bucketDialog(this,anime,()->{})),Ui.lp(this,44,44));root.addView(top,Ui.lp(this,-1,-2));ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);main=Ui.column(this);main.setPadding(Ui.dp(this,12),Ui.dp(this,10),Ui.dp(this,12),Ui.dp(this,24));scroll.addView(main);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));sourceSelect=new Spinner(this);Ui.space(main,2);stage=new FrameLayout(this);stage.setBackground(Ui.shape(Color.BLACK,22,this));stage.setClipToOutline(true);stage.setElevation(Ui.dp(this,10));stage.setMinimumHeight(Ui.dp(this,220));main.addView(stage,Ui.lp(this,-1,Math.max(220,(getResources().getConfiguration().screenWidthDp-24)*9/16)));DefaultLoadControl control=new DefaultLoadControl.Builder().setBufferDurationsMs(6500,32000,450,950).setBackBuffer(12000,false).build();player=new ExoPlayer.Builder(this).setLoadControl(control).build();video=new PlayerView(this);video.setPlayer(player);video.setControllerShowTimeoutMs(2500);video.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);video.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT);video.setUseController(false);video.setKeepContentOnPlayerReset(true);gestures=new GestureDetector(this,new GestureDetector.SimpleOnGestureListener(){@Override public boolean onDown(MotionEvent e){return true;}@Override public boolean onSingleTapConfirmed(MotionEvent e){toggleControls();return true;}@Override public boolean onDoubleTap(MotionEvent e){quickSeek(e.getX()<stage.getWidth()/2?-10000:10000);return true;}});View.OnTouchListener touch=(v,e)->handleTouch(e);video.setOnTouchListener(touch);stage.setOnTouchListener(touch);stage.setOnLongClickListener(v->{toggleResize();showControls();return true;});stage.addView(video,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));loading=Ui.column(this);loading.setGravity(Gravity.CENTER);loading.setBackgroundColor(0x66000000);FrameLayout loadCircle=new FrameLayout(this);loadCircle.setBackground(Ui.shape(0x14FFFFFF,54,this));loadCircle.setElevation(Ui.dp(this,10));ProgressBar bar=new ProgressBar(this);loadCircle.addView(bar,new FrameLayout.LayoutParams(Ui.dp(this,38),Ui.dp(this,38),Gravity.CENTER));loading.addView(loadCircle,Ui.lp(this,70,70));stage.addView(loading,new FrameLayout.LayoutParams(-1,-1));buildPlayerControls();stage.addView(playerControls,new FrameLayout.LayoutParams(-1,-1));status=Ui.text(this,"",11,Ui.MUTED,false);status.setPadding(Ui.dp(this,2),Ui.dp(this,13),Ui.dp(this,2),Ui.dp(this,12));main.addView(status);selectors=Ui.column(this);selectors.setPadding(Ui.dp(this,13),Ui.dp(this,10),Ui.dp(this,13),Ui.dp(this,10));selectors.setBackground(Ui.stroke(0xff101012,18,this));main.addView(selectors);episodeSelect=makeEpisodeSpinner();Ui.space(selectors,8);voiceSelect=makeSpinner(selectors,"Озвучка");qualityRow=Ui.row(this);qualityRow.addView(Ui.text(this,"Разрешение",11,Ui.MUTED,false));qualitySelect=new Spinner(this);LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(0,Ui.dp(this,42),1);qp.leftMargin=Ui.dp(this,10);qualityRow.addView(qualitySelect,qp);selectors.addView(qualityRow);Ui.space(main,11);epRow=Ui.row(this);epRow.setVisibility(View.GONE);skip=Ui.button(this,"Пропустить начало",false,()->{if(nativeMode&&episode!=null)player.seekTo(episode.openingEnd*1000L);});skip.setTextColor(0xffa78bfa);skip.setBackground(Ui.stroke(0x33a78bfa,12,this));skip.setVisibility(View.GONE);Ui.space(main,10);main.addView(skip);Ui.space(main,18);nextList=Ui.column(this);main.addView(nextList);renderNextEpisodes();Ui.space(main,10);main.addView(Ui.text(this,"Если текущий вариант не откроется, Tsuyu подберёт запасной внутри выбранной озвучки",12,Ui.MUTED,false));
        episodeSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int pos,long id){if(!setup&&playback!=null&&playback.video!=null&&pos<playback.video.episodeList.size()){Anime.Episode e=playback.video.episodeList.get(pos);if(episode!=e){seekMs=resumeFor(e.number);loadEpisode(e);}}}public void onNothingSelected(AdapterView<?> p){}});
        voiceSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int pos,long id){if(setup||!nativeMode||pos<0||pos>=audioChoices.size())return;selectAudioTrack(pos);}public void onNothingSelected(AdapterView<?> p){}});
        qualitySelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int pos,long id){if(!setup&&episode!=null&&nativeMode&&pos<episode.streams.size()){int selected=new ArrayList<>(episode.streams.keySet()).get(pos);if(selected!=quality){save(true);seekMs=(int)player.getCurrentPosition();quality=selected;playNative(episode.streams.get(quality));}}}public void onNothingSelected(AdapterView<?> p){}});
        player.addListener(new Player.Listener(){@Override public void onTracksChanged(Tracks tracks){if(nativeMode)renderAudioTracks(tracks);}@Override public void onPlaybackStateChanged(int state){if(!nativeMode)return;if(state==Player.STATE_READY){loading.setVisibility(View.GONE);long duration=player.getDuration();if(seekMs>0&&(duration==C.TIME_UNSET||seekMs<duration-1000))player.seekTo(seekMs);seekMs=0;player.play();playing=true;getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);status.setText(offlineId!=null?"Офлайн · серия "+number(wantedEpisode):nativeStatus());SourceEngine.record(activeSourceId(),true,0,playback==null||playback.video==null?0:playback.video.episodeList.size(),episode==null?0:episode.streams.size()+episode.variants.size(),quality);updateTimeline();showControls();save(true);updatePipActions();}else if(state==Player.STATE_ENDED){save(true);if(offlineId!=null?YoruApp.app().store.autoNext():YoruApp.app().autoNextAllowed())move(1);}}@Override public void onIsPlayingChanged(boolean active){if(active)playing=true;updatePlayerControls();updatePipActions();}@Override public void onPlayerError(PlaybackException error){if(nativeMode){if(rescuePlayback())return;SourceEngine.record(activeSourceId(),false,0,0,0,quality);PlayerActivity.this.error(offlineId!=null?"Не удалось прочитать скачанную серию Удалите её и скачайте заново":"Не удалось воспроизвести видео Попробуйте другое качество или озвучку");}}});
    }


    private android.graphics.drawable.Drawable playerButtonBg(int radius,boolean accent){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,accent?new int[]{0xffa78bfa,0xff8b5cf6}:new int[]{0x22a78bfa,0x10a78bfa});g.setCornerRadius(Ui.dp(this,radius));g.setStroke(Ui.dp(this,1),accent?0xff8b5cf6:0x33a78bfa);return g;}
    private FrameLayout controlButton(String icon,String desc,Runnable action){return controlButton(icon,desc,false,action);}
    private FrameLayout controlButton(String icon,String desc,boolean accent,Runnable action){FrameLayout b=new FrameLayout(this);b.setBackground(playerButtonBg(accent?30:25,accent));b.setElevation(Ui.dp(this,accent?9:6));b.setClickable(true);b.setFocusable(true);b.setContentDescription(desc);Ui.Icon i=new Ui.Icon(this,icon);i.color=accent?0xffffffff:0xffa78bfa;b.addView(i,new FrameLayout.LayoutParams(Ui.dp(this,30),Ui.dp(this,30),Gravity.CENTER));Ui.press(b);b.setOnClickListener(v->{action.run();showControls();});return b;}
    private TextView controlText(String text,String desc,Runnable action){TextView b=Ui.text(this,text,12,0xffa78bfa,true);b.setGravity(Gravity.CENTER);b.setBackground(playerButtonBg(22,false));b.setElevation(Ui.dp(this,5));b.setContentDescription(desc);Ui.press(b);b.setOnClickListener(v->{action.run();showControls();});return b;}
    private void buildPlayerControls(){playerControls=new FrameLayout(this);playerControls.setPadding(Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,8));playerControls.setClickable(false);LinearLayout top=Ui.row(this);topControls=top;top.setGravity(Gravity.CENTER_VERTICAL);speedButton=controlText(speedLabel(),"Скорость просмотра",this::cycleSpeed);top.addView(speedButton,Ui.lp(this,54,42));LinearLayout.LayoutParams qp=Ui.lp(this,62,42);qp.leftMargin=Ui.dp(this,6);qualityButton=controlText(qualityLabel(),"Разрешение",this::chooseQualityOverlay);top.addView(qualityButton,qp);LinearLayout.LayoutParams vp=Ui.lp(this,82,42);vp.leftMargin=Ui.dp(this,6);voiceButton=controlText(voiceLabel(),"Озвучка",this::chooseVoiceOverlay);top.addView(voiceButton,vp);top.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));FrameLayout pip=controlButton("pip","Картинка в картинке",this::enterPip);top.addView(pip,Ui.lp(this,42,42));LinearLayout.LayoutParams fp=Ui.lp(this,42,42);fp.leftMargin=Ui.dp(this,6);FrameLayout full=controlButton("expand","Полный экран",this::fullScreen);fullscreenIcon=(Ui.Icon)full.getChildAt(0);top.addView(full,fp);FrameLayout.LayoutParams topLp=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP);playerControls.addView(top,topLp);LinearLayout rail=Ui.column(this);rail.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);timeLabel=Ui.text(this,"0:00 / 0:00",11,Ui.TEXT,true);timeLabel.setGravity(Gravity.CENTER);timeline=new SeekBar(this);timeline.setMax(1000);timeline.setPadding(0,0,0,0);if(Build.VERSION.SDK_INT>=21){timeline.setProgressTintList(android.content.res.ColorStateList.valueOf(0xffa78bfa));timeline.setThumbTintList(android.content.res.ColorStateList.valueOf(0xffa78bfa));}timeline.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean fromUser){if(fromUser&&nativeMode&&player!=null){long d=player.getDuration();if(d!=C.TIME_UNSET&&d>0)timeLabel.setText(Ui.time((int)(d*p/1000/1000))+" / "+Ui.time((int)(d/1000)));}}public void onStartTrackingTouch(SeekBar b){seekingByUser=true;showControls();}public void onStopTrackingTouch(SeekBar b){try{if(nativeMode&&player!=null){long d=player.getDuration();if(d!=C.TIME_UNSET&&d>0)player.seekTo(d*b.getProgress()/1000);player.play();}}catch(Exception ignored){}seekingByUser=false;updateTimeline();showControls();}});rail.addView(timeLabel,Ui.lp(this,-1,18));rail.addView(timeline,Ui.lp(this,-1,36));FrameLayout.LayoutParams railLp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);railLp.bottomMargin=Ui.dp(this,68);playerControls.addView(rail,railLp);LinearLayout bottom=Ui.row(this);bottomControls=bottom;bottom.setGravity(Gravity.CENTER);prev=controlButton("prevEpisode","Предыдущая серия",()->move(-1));bottom.addView(prev,Ui.lp(this,46,46));LinearLayout.LayoutParams bp=Ui.lp(this,48,48);bp.leftMargin=Ui.dp(this,8);bottom.addView(controlButton("rewind","Назад на 10 секунд",()->seekBy(-10)),bp);LinearLayout.LayoutParams pp=Ui.lp(this,56,56);pp.leftMargin=Ui.dp(this,8);FrameLayout play=controlButton("play","Пауза или продолжить",true,this::togglePlay);playPauseIcon=(Ui.Icon)play.getChildAt(0);bottom.addView(play,pp);LinearLayout.LayoutParams fw=Ui.lp(this,48,48);fw.leftMargin=Ui.dp(this,8);bottom.addView(controlButton("forward","Вперёд на 10 секунд",()->seekBy(10)),fw);LinearLayout.LayoutParams np=Ui.lp(this,46,46);np.leftMargin=Ui.dp(this,8);next=controlButton("nextEpisode","Следующая серия",()->move(1));bottom.addView(next,np);LinearLayout.LayoutParams rp=Ui.lp(this,46,46);rp.leftMargin=Ui.dp(this,8);FrameLayout resize=controlButton("fit","Масштаб кадра",this::toggleResize);resizeIcon=(Ui.Icon)resize.getChildAt(0);bottom.addView(resize,rp);FrameLayout.LayoutParams bottomLp=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);bottomLp.bottomMargin=Ui.dp(this,8);playerControls.addView(bottom,bottomLp);seekHint=Ui.text(this,"",22,0xffffffff,true);seekHint.setGravity(Gravity.CENTER);seekHint.setPadding(Ui.dp(this,18),Ui.dp(this,12),Ui.dp(this,18),Ui.dp(this,12));seekHint.setBackground(playerButtonBg(24,true));seekHint.setVisibility(View.GONE);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER);playerControls.addView(seekHint,hp);updatePlayerControls();}
    private boolean isPlayingNow(){return nativeMode&&player!=null?player.isPlaying():webActuallyPlaying;}
    private void updatePlayerControls(){if(speedButton!=null){speedButton.setText(speedLabel());speedButton.setVisibility(nativeMode?View.VISIBLE:View.GONE);}if(qualityButton!=null){qualityButton.setText(qualityLabel());qualityButton.setVisibility(nativeMode&&episode!=null&&!episode.streams.isEmpty()?View.VISIBLE:View.GONE);}if(voiceButton!=null){voiceButton.setText(voiceLabel());voiceButton.setVisibility(episode!=null&&!audioChoices.isEmpty()?View.VISIBLE:View.GONE);}if(bottomControls!=null)bottomControls.setVisibility(nativeMode?View.VISIBLE:View.GONE);if(timeline!=null)timeline.setVisibility(nativeMode?View.VISIBLE:View.GONE);if(timeLabel!=null)timeLabel.setVisibility(nativeMode?View.VISIBLE:View.GONE);if(playPauseIcon!=null)playPauseIcon.setKind(isPlayingNow()?"pause":"play");if(fullscreenIcon!=null)fullscreenIcon.setKind(fullPlayer?"shrink":"expand");if(resizeIcon!=null)resizeIcon.setKind(fillVideo?"shrink":"fit");if(playerControls!=null)playerControls.bringToFront();}
    private void updateTimeline(){try{if(player==null||timeline==null||timeLabel==null||!nativeMode)return;if(seekingByUser)return;long d=player.getDuration(),p=player.getCurrentPosition();if(d==C.TIME_UNSET||d<=0){timeline.setProgress(0);timeLabel.setText(Ui.time((int)(p/1000))+" / —");return;}timeline.setProgress((int)Math.max(0,Math.min(1000,p*1000/Math.max(1,d))));timeLabel.setText(Ui.time((int)(p/1000))+" / "+Ui.time((int)(d/1000)));}catch(Exception ignored){}}
    private void showControls(){if(playerControls==null||isInPictureInPictureMode())return;playerControls.setVisibility(View.VISIBLE);updatePlayerControls();timer.removeCallbacks(hideControls);if(isPlayingNow())timer.postDelayed(hideControls,1000);}
    private void toggleControls(){if(playerControls==null)return;if(playerControls.getVisibility()==View.VISIBLE)playerControls.setVisibility(View.GONE);else showControls();}
    private void attachControls(FrameLayout host){if(playerControls==null||host==null)return;ViewParent old=playerControls.getParent();if(old instanceof ViewGroup)((ViewGroup)old).removeView(playerControls);host.addView(playerControls,new FrameLayout.LayoutParams(-1,-1));showControls();}
    private void togglePlay(){try{if(nativeMode&&player!=null){if(player.isPlaying())player.pause();else player.play();}else if(web!=null&&yummyFrame){if(webActuallyPlaying){web.evaluateJavascript("if(window.__yoruPause)window.__yoruPause();",null);webActuallyPlaying=false;}else{web.evaluateJavascript("if(window.__yoruPlay)window.__yoruPlay();",null);webActuallyPlaying=true;playing=true;}}updatePlayerControls();updatePipActions();}catch(Exception ignored){}}
    private Spinner makeSpinner(LinearLayout col,String name){col.addView(Ui.text(this,name,10,Ui.MUTED,false));Spinner s=new Spinner(this);col.addView(s,Ui.lp(this,-1,44));return s;}
    private Spinner makeEpisodeSpinner(){selectors.addView(Ui.text(this,"Серия",10,Ui.MUTED,false));LinearLayout row=Ui.row(this);Spinner s=new Spinner(this);row.addView(s,new LinearLayout.LayoutParams(0,Ui.dp(this,44),1));downloadButton=Ui.button(this,downloadButtonTitle(),false,this::downloadCurrent);downloadButton.setTextColor(0xffa78bfa);downloadButton.setBackground(Ui.stroke(0x33a78bfa,12,this));downloadButton.setEnabled(offlineId==null);downloadButton.setMaxLines(2);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(Ui.dp(this,138),-2);bp.leftMargin=Ui.dp(this,8);row.addView(downloadButton,bp);selectors.addView(row,Ui.lp(this,-1,-2));return s;}
    private String nativeStatus(){String label=ApiRepository.voiceTitle((dubbing==null||dubbing.isEmpty())?(episode==null?"":episode.name):dubbing);String size=Ui.videoSizeHint(quality,episode==null?0:episode.duration);return "Серия "+number(wantedEpisode)+(label.isEmpty()?"":" · "+label)+(quality>0?" · "+QualityPlus.name(quality):"")+(size.isEmpty()?"":" · "+size);}
    private String qualityLabel(){return quality>0?quality+"p":"Качество";}
    private String voiceLabel(){String v=ApiRepository.voiceTitle(dubbing);if(v.isEmpty()&&episode!=null){v=ApiRepository.voiceTitle(episode.name);if(v.isEmpty())v=ApiRepository.cleanLabel(episode.name);}if(v.isEmpty()&&!yummyVersion.isEmpty())v=yummyVersion;if(v.isEmpty())return "Озвучка";return v.length()>9?v.substring(0,8)+"…":v;}
    private void chooseQualityOverlay(){if(episode==null){Ui.toast(this,"Серия ещё не выбрана");return;}if(nativeMode&&!episode.streams.isEmpty()){ArrayList<Integer> qs=new ArrayList<>(episode.streams.keySet());ArrayList<String> labels=new ArrayList<>();int curIndex=0;for(int i=0;i<qs.size();i++){int q=qs.get(i);labels.add(QualityPlus.streamLabel(q));if(q==quality)curIndex=i;}Ui.singleChoice(this,"Разрешение видео",labels.toArray(new String[0]),curIndex,"Выбрать",pos->{if(pos<0||pos>=qs.size())return;int sel=qs.get(pos);if(qualitySelect!=null&&pos<qualitySelect.getCount())qualitySelect.setSelection(pos);if(sel!=quality){save(true);seekMs=player!=null?(int)player.getCurrentPosition():0;quality=sel;playNative(episode.streams.get(quality));updatePlayerControls();}});}else{Ui.toast(this,"Для текущего видео доступно только исходное разрешение");}}
    private void chooseVoiceOverlay(){if(episode==null||audioChoices.isEmpty()){Ui.toast(this,"Для текущей серии нет доступных дорожек озвучки");return;}String[] names=new String[audioChoices.size()];int selected=voiceSelect==null?0:Math.max(0,Math.min(audioChoices.size()-1,voiceSelect.getSelectedItemPosition()));for(int i=0;i<audioChoices.size();i++)names[i]=audioChoices.get(i).label;Ui.singleChoice(this,"Дорожка озвучки",names,selected,"Выбрать",this::selectAudioTrack);}
    private void setVoiceSelectorVisible(boolean visible){
        if(voiceSelect==null||selectors==null)return;
        voiceSelect.setVisibility(visible?View.VISIBLE:View.GONE);
        int labelIndex=selectors.indexOfChild(voiceSelect)-1;
        if(labelIndex>=0)selectors.getChildAt(labelIndex).setVisibility(visible?View.VISIBLE:View.GONE);
    }

    private String audioLanguage(String language){
        if(language==null||language.trim().isEmpty()||language.equalsIgnoreCase("und"))return "";
        String l=language.toLowerCase(Locale.ROOT);
        if(l.equals("ru")||l.equals("rus"))return "Русская";
        if(l.equals("uk")||l.equals("ukr"))return "Украинская";
        if(l.equals("en")||l.equals("eng"))return "English";
        if(l.equals("ja")||l.equals("jpn"))return "日本語";
        if(l.equals("zh")||l.equals("zho")||l.equals("chi"))return "中文";
        if(l.equals("ko")||l.equals("kor"))return "한국어";
        return language;
    }

    private String audioTrackLabel(Format format,HashMap<String,Integer> seen){
        String label=format==null?"":format.label==null?"":format.label.trim();
        if(label.isEmpty()||label.equalsIgnoreCase("und"))label=audioLanguage(format==null?"":format.language);
        if(label.isEmpty())label="Дорожка озвучки";
        return label;
    }

    private boolean isAudioGroup(Tracks.Group group){
        if(group==null)return false;
        if(group.getType()==C.TRACK_TYPE_AUDIO)return true;
        for(int i=0;i<group.length;i++){
            Format f=group.getTrackFormat(i);
            if(f!=null&&(MimeTypes.getTrackType(f.sampleMimeType)==C.TRACK_TYPE_AUDIO||MimeTypes.getTrackType(f.containerMimeType)==C.TRACK_TYPE_AUDIO))return true;
        }
        return false;
    }

    private String episodeVoiceLabel(Anime.Variant variant){
        if(variant==null)return "";
        String raw=variant.name==null?"":variant.name.trim();
        String label=ApiRepository.voiceLabel(raw);
        if(label.isEmpty()){
            String display=variant.displayName==null?"":variant.displayName.trim();
            int separator=display.indexOf(" · ");
            if(separator>0)display=display.substring(0,separator).trim();
            label=ApiRepository.voiceLabel(display);
        }
        // A provider may expose a valid episode URL without a translation title. Keep one
        // real audio choice instead of turning it into the false "no voices" state.
        return label.isEmpty()?"Озвучка":label;
    }

    private boolean genericAudioLabel(String label){
        if(label==null)return true;
        String v=label.toLowerCase(Locale.ROOT).replace('ё','е').trim();
        return v.equals("озвучка")||v.equals("дорожка озвучки")||v.equals("аудиодорожка")||v.startsWith("дорожка озвучки ·");
    }

    private String voiceChoiceKey(String label){
        if(genericAudioLabel(label))return "generic-audio";
        String key=ApiRepository.voiceKey(label);
        if(!key.isEmpty())return key;
        return label==null?"":label.toLowerCase(Locale.ROOT).replace('ё','е').replaceAll("\\s+","");
    }

    private void appendEpisodeVoices(ArrayList<AudioChoice> found){
        if(episode==null||episode.variants.isEmpty())return;
        HashSet<String> seen=new HashSet<>();
        for(AudioChoice choice:found)seen.add(voiceChoiceKey(choice.label));
        for(Anime.Variant variant:SourceEngine.sortVariants(episode.variants)){
            String url=ApiRepository.embed(variant.url);
            if(url.isEmpty())url=ApiRepository.safeUrl(variant.url);
            if(url.isEmpty())continue;
            String label=episodeVoiceLabel(variant),key=voiceChoiceKey(label);
            if(key.isEmpty()||!seen.add(key))continue;
            found.add(new AudioChoice(variant,label));
        }
    }

    private String audioSignature(ArrayList<AudioChoice> choices){
        StringBuilder b=new StringBuilder();
        for(AudioChoice choice:choices){
            if(choice.group!=null)b.append("track:").append(choice.group.getMediaTrackGroup().id).append('#').append(choice.index);
            else b.append("voice:").append(choice.variant==null?"":choice.variant.url);
            b.append('#').append(choice.label).append('|');
        }
        return b.toString();
    }

    private void publishAudioChoices(ArrayList<AudioChoice> found,int selected,boolean applyPreferred,boolean preferredMatch){
        if(found.isEmpty()){
            audioChoices.clear();
            audioSignature="";
            setVoiceSelectorVisible(false);
            updatePlayerControls();
            return;
        }
        selected=Math.max(0,Math.min(selected,found.size()-1));
        String signature=audioSignature(found);
        boolean changed=!signature.equals(audioSignature)||audioChoices.size()!=found.size();
        audioChoices.clear();
        audioChoices.addAll(found);
        audioSignature=signature;
        setVoiceSelectorVisible(true);
        if(changed){
            setup=true;
            ArrayList<String> labels=new ArrayList<>();
            for(AudioChoice choice:audioChoices)labels.add(choice.label);
            voiceSelect.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));
            voiceSelect.setSelection(selected);
            setup=false;
        }else if(voiceSelect.getSelectedItemPosition()!=selected){
            setup=true;
            voiceSelect.setSelection(selected);
            setup=false;
        }
        AudioChoice choice=audioChoices.get(selected);
        if(applyPreferred&&!audioPreferenceApplied){
            audioPreferenceApplied=true;
            if(preferredMatch&&choice.group!=null&&!choice.group.isTrackSelected(choice.index))selectAudioTrack(selected);
        }
        dubbing=choice.label;
        updatePlayerControls();
    }

    private void appendCurrentStreamVoice(ArrayList<AudioChoice> found){
        if(!found.isEmpty()||episode==null||episode.streams.isEmpty())return;
        String label=ApiRepository.voiceLabel(dubbing);
        if(label.isEmpty())label="Озвучка";
        String url=episode.streams.get(quality);
        if(url==null||url.isEmpty())url=episode.streams.firstEntry().getValue();
        if(ApiRepository.safeUrl(url).isEmpty())return;
        Anime.Variant direct=new Anime.Variant(label,"",url);direct.displayName=label;
        found.add(new AudioChoice(direct,label,true));
    }

    private void renderEpisodeVoices(){
        if(voiceSelect==null||offlineId!=null||episode==null){setVoiceSelectorVisible(false);return;}
        ArrayList<AudioChoice> found=new ArrayList<>();
        HashSet<String> seen=new HashSet<>();
        for(Anime.Variant variant:SourceEngine.sortVariants(episode.variants)){
            String label=episodeVoiceLabel(variant);
            String url=ApiRepository.embed(variant.url);
            if(url.isEmpty())url=ApiRepository.safeUrl(variant.url);
            if(url.isEmpty())continue;
            String key=voiceChoiceKey(label);
            if(key.isEmpty()||!seen.add(key))continue;
            found.add(new AudioChoice(variant,label));
        }
        if(found.isEmpty())appendCurrentStreamVoice(found);
        if(found.isEmpty()){publishAudioChoices(found,0,false,false);return;}
        String current=dubbing==null?"":dubbing;
        String preferred=YoruApp.app().store.voiceFor(anime);
        if(preferred==null||preferred.isEmpty())preferred=YoruApp.app().store.voicePreference();
        int selected=0;
        for(int i=0;i<found.size();i++){
            if(!current.isEmpty()&&(ApiRepository.voiceMatches(current,found.get(i).label)||current.equalsIgnoreCase(found.get(i).label))){selected=i;break;}
            if(preferred!=null&&!preferred.isEmpty()&&(ApiRepository.voiceMatches(preferred,found.get(i).label)||preferred.equalsIgnoreCase(found.get(i).label)))selected=i;
        }
        // The selected variant is already applied by loadEpisode/showVariant. Do not start a
        // second asynchronous playback from the track-list callback.
        publishAudioChoices(found,selected,false,false);
    }

    private void renderAudioTracks(Tracks tracks){
        if(voiceSelect==null||offlineId!=null){setVoiceSelectorVisible(false);return;}
        ArrayList<AudioChoice> found=new ArrayList<>();
        HashMap<String,Integer> seen=new HashMap<>();
        if(tracks!=null)for(Tracks.Group group:tracks.getGroups()){
            if(!isAudioGroup(group))continue;
            for(int i=0;i<group.length;i++){
                // Tracks.Group is already the set of tracks exposed by the current
                // episode. Renderer capability flags can be stale for HLS/DASH audio,
                // so do not hide a real audio entry only because Media3 reports it as
                // unsupported at this instant.
                Format format=group.getTrackFormat(i);
                if(format==null)continue;
                String label=audioTrackLabel(format,seen);
                String key=voiceChoiceKey(label);
                if(key.isEmpty()||seen.containsKey(key))continue;
                seen.put(key,1);
                found.add(new AudioChoice(group,i,label));
            }
        }
        // A provider may expose the current manifest's tracks and the other dubs as
        // episode-level URLs. Keep both concrete choices, removing only duplicate voice
        // names; never replace them with provider/player names.
        appendEpisodeVoices(found);
        if(found.isEmpty()){
            appendCurrentStreamVoice(found);
            if(found.isEmpty()){renderEpisodeVoices();return;}
        }
        int selected=0;
        boolean currentMatch=false;
        if(dubbing!=null&&!dubbing.isEmpty())for(int i=0;i<found.size();i++)if(ApiRepository.voiceMatches(dubbing,found.get(i).label)||dubbing.equalsIgnoreCase(found.get(i).label)){selected=i;currentMatch=true;break;}
        if(!currentMatch)for(int i=0;i<found.size();i++)if(found.get(i).group!=null&&found.get(i).group.isTrackSelected(found.get(i).index)){selected=i;break;}
        String preferred=YoruApp.app().store.voiceFor(anime);
        if(preferred==null||preferred.isEmpty())preferred=YoruApp.app().store.voicePreference();
        boolean preferredMatch=false;
        if(preferred!=null&&!preferred.isEmpty())for(int i=0;i<found.size();i++)if(ApiRepository.voiceMatches(preferred,found.get(i).label)||preferred.equalsIgnoreCase(found.get(i).label)){selected=i;preferredMatch=true;break;}
        publishAudioChoices(found,selected,preferred==null||preferred.isEmpty()||preferredMatch,preferredMatch);
    }

    private void selectAudioTrack(int position){
        if(player==null||position<0||position>=audioChoices.size())return;
        AudioChoice choice=audioChoices.get(position);
        try{
            if(choice.variant!=null){
                seekMs=player==null?seekMs:(int)Math.max(0,player.getCurrentPosition());
                dubbing=choice.label;
                if(anime!=null){YoruApp.app().store.setVoiceFor(anime,choice.label);YoruApp.app().store.rememberVoice(choice.label);}
                if(voiceSelect!=null&&voiceSelect.getSelectedItemPosition()!=position){setup=true;voiceSelect.setSelection(position);setup=false;}
                if(choice.direct){if(status!=null&&nativeMode)status.setText(nativeStatus());return;}
                showVariant(choice.variant);
                return;
            }
            player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO,false)
                    .setOverrideForType(new TrackSelectionOverride(choice.group.getMediaTrackGroup(),choice.index))
                    .build());
            dubbing=choice.label;
            if(anime!=null){
                YoruApp.app().store.setVoiceFor(anime,choice.label);
                YoruApp.app().store.rememberVoice(choice.label);
            }
            if(voiceSelect!=null&&voiceSelect.getSelectedItemPosition()!=position){setup=true;voiceSelect.setSelection(position);setup=false;}
            if(status!=null&&nativeMode)status.setText(nativeStatus());
        }catch(Exception ignored){
            Ui.toast(this,"Не удалось выбрать дорожку озвучки");
        }
    }

    private DownloadHub.AudioSelection currentAudioSelection(){
        if(audioChoices.isEmpty())return null;
        int position=voiceSelect==null?0:voiceSelect.getSelectedItemPosition();
        if(position<0||position>=audioChoices.size())position=0;
        AudioChoice choice=audioChoices.get(position);
        if(choice.group==null)return null;
        Format format=choice.group.getTrackFormat(choice.index);
        return new DownloadHub.AudioSelection(choice.group.getMediaTrackGroup().id,choice.index,format==null?"":format.id,format==null?"":format.label,format==null?"":format.language,format==null?0:format.roleFlags,format==null?0:format.selectionFlags,format==null?0:format.channelCount);
    }

    private int resumeFor(double ep){JSONObject h=YoruApp.app().store.progress(anime);if(Double.compare(h.optDouble("episode",-1),ep)!=0)return 0;int time=h.optInt("time"),duration=h.optInt("duration");if(duration>120&&time>duration-45)return 0;return time*1000;}
    private void showLoading(String titleText,String subText){if(loading!=null)loading.setVisibility(View.VISIBLE);}
    private void loadMode(String selected){mode="yoru";save(true);seekMs=resumeFor(wantedEpisode);stopMedia();nativeMode=false;dubbing="";yummyVersion="";playbackTasks.cancel();int gen=++generation;showLoading("Ищем озвучки","");status.setText("Открываем серию…");setup=true;selectors.setVisibility(View.GONE);epRow.setVisibility(View.GONE);skip.setVisibility(View.GONE);setup=false;playbackTask(()->{try{Anime.Playback ready=YoruApp.app().api.playback(anime,"yoru");YoruApp.app().main.post(()->{if(gen!=generation||isFinishing())return;playback=ready;anime=ready.catalog;title.setText(YoruBrain.title(anime));if(ready.video!=null&&!ready.video.episodeList.isEmpty()){setup=true;selectors.setVisibility(View.VISIBLE);epRow.setVisibility(View.VISIBLE);ArrayList<String> labels=new ArrayList<>();int index=0;for(int i=0;i<ready.video.episodeList.size();i++){Anime.Episode e=ready.video.episodeList.get(i);boolean hasContent=!e.streams.isEmpty()||!e.variants.isEmpty()||(e.lazy!=null&&!e.lazy.isEmpty()&&!"future".equals(e.lazy))||(e.resolverUrl!=null&&!e.resolverUrl.isEmpty());if(hasContent)e.future=false;labels.add(YoruApp.app().store.spoilerSafe()?"Серия "+number(e.number):e.label());if(Double.compare(e.number,wantedEpisode)==0&&!e.future)index=i;}while(index<ready.video.episodeList.size()&&ready.video.episodeList.get(index).future&&index>0)index--;episodeSelect.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));episodeSelect.setSelection(index);setup=false;loadEpisode(ready.video.episodeList.get(index));}else{episode=null;selectors.setVisibility(View.GONE);epRow.setVisibility(View.GONE);String url=ready.directUrl;if(ready.directKodik&&!Uri.parse(url).getPath().startsWith("/video/"))url=Uri.parse(url).buildUpon().appendQueryParameter("episode",number(wantedEpisode)).build().toString();showWeb(url,ready.directKodik);}});}catch(Exception e){YoruApp.app().main.post(()->{if(gen==generation&&!isFinishing())error("Сейчас не удалось открыть видео Попробуйте ещё раз");});}});}
    private void loadEpisode(Anime.Episode e){if(e==null){error("Серия не найдена");return;}ApiRepository.normalizeEpisode(e);boolean hasContent=!e.streams.isEmpty()||!e.variants.isEmpty()||(e.lazy!=null&&!e.lazy.isEmpty()&&!"future".equals(e.lazy))||(e.resolverUrl!=null&&!e.resolverUrl.isEmpty());if(hasContent)e.future=false;if(e.future){error(e!=null&&!e.airDate.isEmpty()?"Серия "+number(e.number)+": "+e.airDate:"Серия ещё не вышла");return;}save(true);dubbing="";yummyVersion="";resetFrameDownloads();stopMedia();episode=e;wantedEpisode=e.number;browserTime=0;browserDuration=0;playing=false;openingSkipped=false;rescueTries=0;currentVariantKey="";playbackTasks.cancel();int gen=++generation;showLoading("Готовим серию "+number(e.number),"yoru".equals(e.lazy)?"Готовим просмотр":"Готовим просмотр");status.setText("Открываем серию "+number(e.number)+"…");playbackTask(()->{try{YoruApp.app().api.loadEpisode(e);Anime.Variant fastVariant=null;TreeMap<Integer,String> fastStreams=null;boolean preferVariants=preferVariantPlayback(e);if((e.streams.isEmpty()||preferVariants)&&!e.variants.isEmpty()){fastVariant=preferredVariant(e);if(fastVariant!=null)try{fastStreams=YoruApp.app().api.resolveStreams(fastVariant.url);}catch(Exception ignored){}}final Anime.Variant readyVariant=fastVariant;final TreeMap<Integer,String> readyStreams=fastStreams;YoruApp.app().main.post(()->{if(gen!=generation||episode!=e||isFinishing())return;setup=true;qualityRow.setVisibility(e.streams.isEmpty()?View.GONE:View.VISIBLE);setVoiceSelectorVisible(false);audioChoices.clear();audioSignature="";audioPreferenceApplied=false;if(!e.streams.isEmpty()&&!preferVariantPlayback(e)){dubbing=playback!=null&&playback.video!=null?ApiRepository.sourceVoice(playback.video.source):"";if(dubbing.isEmpty())dubbing="Озвучка";yummyVersion="";updateDownloadButton();ArrayList<Integer> qs=new ArrayList<>(e.streams.keySet());if(!e.streams.containsKey(quality)){quality=qs.get(0);quality=QualityPlus.bestAtOrBelow(qs,YoruApp.app().store.quality());}ArrayList<String> names=new ArrayList<>();for(int q:qs)names.add(QualityPlus.streamLabel(q));qualitySelect.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));qualitySelect.setSelection(qs.indexOf(quality));setup=false;playNative(e.streams.get(quality));}else if(!e.variants.isEmpty()){ArrayList<Anime.Variant> available=SourceEngine.sortVariants(e.variants);Anime.Variant selectedVariant=readyVariant!=null?readyVariant:(available.isEmpty()?null:preferredVariant(e));if(selectedVariant==null&&!available.isEmpty())selectedVariant=available.get(0);setup=false;if(selectedVariant==null){error("Для этой серии пока нет доступного видео");return;}if(readyVariant!=null&&readyStreams!=null&&!readyStreams.isEmpty())startResolvedVariant(readyVariant,readyStreams);else showVariant(selectedVariant);}else{setup=false;error("Для этой серии пока нет доступного видео");}updateNext();});}catch(Exception err){YoruApp.app().main.post(()->{if(gen==generation&&!isFinishing())error("Серия сейчас недоступна Попробуйте другую озвучку");});}});}
    private boolean preferVariantPlayback(Anime.Episode e){return e!=null&&e.streams.isEmpty()&&!e.variants.isEmpty();}
    private Anime.Variant preferredVariant(Anime.Episode e){if(e==null||e.variants.isEmpty())return null;SecureStore store=YoruApp.app().store;String own=store.voiceFor(anime);String preferred=own.isEmpty()?store.voicePreference():own;boolean strict=store.onlyPreferredVoice()&&!ApiRepository.voiceKey(preferred).isEmpty();Anime.Variant first=null,favorite=null;for(Anime.Variant v:SourceEngine.sortVariants(e.variants)){if(v==null)continue;if(first==null)first=v;String raw=v.name+" "+v.displayName+" "+v.player;if(store.voicePriority(raw)>=0&&favorite==null)favorite=v;if(!preferred.isEmpty()&&(preferred.startsWith("src:")?preferred.equals("src:"+SourceEngine.sourceId(v.player)):ApiRepository.voiceMatches(preferred,raw)))return v;}if(strict)return null;return favorite!=null?favorite:first;}
    private void startResolvedVariant(Anime.Variant v,TreeMap<Integer,String> streams){if(v==null||streams==null||streams.isEmpty()){if(!rescuePlayback())error("Эта озвучка сейчас не открылась");return;}String vt=episodeVoiceLabel(v);dubbing=vt;yummyVersion=ApiRepository.cleanLabel(v.player);updateDownloadButton();if(episode!=null){episode.streams.clear();episode.openingStart=v.openingStart;episode.openingEnd=v.openingEnd;}String safe=ApiRepository.embed(v.url);if(safe.isEmpty())safe=ApiRepository.safeUrl(v.url);currentUrl=safe;currentVariantKey=safe;nativeMode=false;yummyFrame=false;trustedKodik=false;video.setVisibility(View.VISIBLE);if(web!=null)web.setVisibility(View.GONE);playVariantNative(streams);}
    private void showVariant(Anime.Variant v){String vt=episodeVoiceLabel(v);dubbing=vt;yummyVersion=ApiRepository.cleanLabel(v.player);updateDownloadButton();if(episode!=null){episode.streams.clear();episode.openingStart=v.openingStart;episode.openingEnd=v.openingEnd;}String safe=ApiRepository.embed(v.url);if(safe.isEmpty())safe=ApiRepository.safeUrl(v.url);if(safe.isEmpty()){error("Эта озвучка сейчас не открылась");return;}playbackTasks.cancel();int gen=++generation;currentUrl=safe;nativeMode=false;yummyFrame=false;trustedKodik=false;video.setVisibility(View.VISIBLE);if(web!=null)web.setVisibility(View.GONE);showLoading("Готовим озвучку","Пробуем открыть её сразу во встроенном плеере");status.setText("Готовим озвучку…");currentVariantKey=safe;String expected=safe;playbackTask(()->{try{TreeMap<Integer,String> streams=YoruApp.app().api.resolveStreams(v.url);YoruApp.app().main.post(()->{if(gen!=generation||destroyed||isFinishing()||!expected.equals(currentUrl))return;if(streams!=null&&!streams.isEmpty())playVariantNative(streams);else if(!rescuePlayback())error("Эта озвучка сейчас не открылась");});}catch(Exception ignored){YoruApp.app().main.post(()->{if(gen==generation&&!destroyed&&!isFinishing()&&expected.equals(currentUrl)&&!rescuePlayback())error("Эта озвучка сейчас не открылась");});}});}
    private boolean rescuePlayback(){if(offlineId!=null||episode==null||rescueTries>=10)return false;rescueTries++;SourceEngine.record(activeSourceId(),false,0,0,0,quality);status.setText("Подбираем другой рабочий вариант…");try{if(nativeMode&&episode.streams.size()>1){int nextQuality=0;for(Integer q:episode.streams.keySet())if(q!=null&&q>0&&q<quality)nextQuality=Math.max(nextQuality,q);if(nextQuality==0)for(Integer q:episode.streams.keySet())if(q!=null&&q!=quality){nextQuality=q;break;}if(nextQuality>0&&episode.streams.containsKey(nextQuality)){seekMs=player==null?seekMs:(int)player.getCurrentPosition();quality=nextQuality;setup=true;ArrayList<Integer> qs=new ArrayList<>(episode.streams.keySet());if(qualitySelect!=null)qualitySelect.setSelection(Math.max(0,qs.indexOf(nextQuality)));setup=false;playNative(episode.streams.get(nextQuality));return true;}}String current=currentVariantKey==null?"":currentVariantKey;String ownVoice=YoruApp.app().store.voiceFor(anime);String pref=ownVoice.isEmpty()?YoruApp.app().store.voicePreference():ownVoice;boolean strict=YoruApp.app().store.onlyPreferredVoice()&&!ApiRepository.voiceKey(pref).isEmpty();String activeVoice=ApiRepository.voiceTitle(dubbing);if(!activeVoice.isEmpty()){pref=activeVoice;strict=true;}for(Anime.Variant v:SourceEngine.sortVariants(episode.variants)){String raw=v.name+" "+v.displayName+" "+v.player;if(strict&&!ApiRepository.voiceMatches(pref,raw))continue;String key=ApiRepository.embed(v.url);if(key.isEmpty())key=ApiRepository.safeUrl(v.url);if(key.isEmpty()||key.equals(current))continue;seekMs=nativeMode&&player!=null?(int)player.getCurrentPosition():browserTime*1000;showVariant(v);return true;}if(strict)for(Anime.Variant v:SourceEngine.sortVariants(episode.variants)){String key=ApiRepository.embed(v.url);if(key.isEmpty())key=ApiRepository.safeUrl(v.url);if(key.isEmpty()||key.equals(current))continue;try{YoruApp.app().store.onlyPreferredVoice(false);}catch(Exception ignored){}seekMs=nativeMode&&player!=null?(int)player.getCurrentPosition():browserTime*1000;showVariant(v);return true;}}catch(Exception ignored){}return false;}
    private void softSave(){long now=System.currentTimeMillis();if(now-lastSoftSaved<7000L)return;lastSoftSaved=now;save(false);}
    private void maybePrewarmNextThrottled(){long now=System.currentTimeMillis();if(now-lastPrewarmAt<12000L)return;lastPrewarmAt=now;maybePrewarmNext();}
    private void destroyWebForNative(){try{if(web!=null){web.stopLoading();web.loadUrl("about:blank");web.removeAllViews();web.destroy();web=null;}}catch(Exception ignored){}}
    private void maybePrewarmNext(){if(destroyed||offlineId!=null||episode==null||playback==null||playback.video==null||!nativeMode||player==null||!player.isPlaying())return;long duration=player.getDuration(),position=player.getCurrentPosition();if(duration!=C.TIME_UNSET&&duration>0){if(position<Math.min(duration*6/10,Math.max(0,duration-180000)))return;}else if(position<720000)return;Anime.Episode nextEpisode=null;for(Anime.Episode row:playback.video.episodeList)if(row!=null&&!row.future&&row.number>wantedEpisode+0.001){nextEpisode=row;break;}if(nextEpisode==null)return;String key=anime.key()+":"+activeSourceId()+":"+number(nextEpisode.number);if(key.equals(prewarmKey))return;prewarmKey=key;Anime.Episode warm=nextEpisode;playbackTask(()->{try{YoruApp.app().api.loadEpisode(warm);Anime.Variant pv=preferredVariant(warm);if(pv!=null)try{TreeMap<Integer,String> st=YoruApp.app().api.resolveStreams(pv.url);if(!st.isEmpty())warm.streams.putAll(st);}catch(Exception ignored){}int quality=0;for(Integer q:warm.streams.keySet())if(q!=null)quality=Math.max(quality,q);if(!warm.streams.isEmpty()||!warm.variants.isEmpty())SourceEngine.record(warm.lazy==null||warm.lazy.isEmpty()?activeSourceId():warm.lazy,true,0,0,warm.streams.size()+warm.variants.size(),quality);}catch(Exception ignored){}});}
    private String speedLabel(){return speed==Math.round(speed)?String.format(Locale.US,"%.0f×",speed):String.format(Locale.US,"%.2f×",speed).replace(".00","");}
    private void cycleSpeed(){float[] values={1f,1.1f,1.25f,1.5f,1.75f,2f,2.25f,2.5f};int index=0;for(int i=0;i<values.length;i++)if(Math.abs(values[i]-speed)<0.01f){index=i;break;}speed=values[(index+1)%values.length];YoruApp.app().store.playbackSpeed(speed);if(player!=null)player.setPlaybackSpeed(speed);if(speedButton!=null)speedButton.setText(speedLabel());Ui.toast(this,"Скорость "+speedLabel());}
    private boolean handleTouch(MotionEvent e){if(e==null)return false;if(e.getAction()==MotionEvent.ACTION_DOWN){touchStartX=e.getX();touchStartY=e.getY();swipeAdjusting=false;AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);touchStartVolume=am==null?0:am.getStreamVolume(AudioManager.STREAM_MUSIC);touchStartBrightness=getWindow().getAttributes().screenBrightness;if(touchStartBrightness<0)touchStartBrightness=.5f;}else if(e.getAction()==MotionEvent.ACTION_MOVE&&nativeMode&&stage!=null){float dx=e.getX()-touchStartX,dy=e.getY()-touchStartY;if(Math.abs(dy)>Ui.dp(this,28)&&Math.abs(dy)>Math.abs(dx)*1.35f){swipeAdjusting=true;if(touchStartX>stage.getWidth()/2f){AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);if(am!=null){int max=Math.max(1,am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));int vol=Math.max(0,Math.min(max,touchStartVolume+(int)Math.round((-dy/Math.max(1,stage.getHeight()))*max)));am.setStreamVolume(AudioManager.STREAM_MUSIC,vol,0);status.setText("Громкость "+Math.round(vol*100f/max)+"%");}}else{float value=Math.max(.05f,Math.min(1f,touchStartBrightness-dy/Math.max(1,stage.getHeight())));WindowManager.LayoutParams lp=getWindow().getAttributes();lp.screenBrightness=value;getWindow().setAttributes(lp);status.setText("Яркость "+Math.round(value*100)+"%");}showControls();return true;}}else if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){if(swipeAdjusting){swipeAdjusting=false;return true;}}return gestures==null||gestures.onTouchEvent(e);}
    private void quickSeek(long delta){if(nativeMode&&player!=null){long pos=Math.max(0,player.getCurrentPosition()+delta);long dur=player.getDuration();if(dur!=C.TIME_UNSET)pos=Math.min(pos,Math.max(0,dur-500));player.seekTo(pos);flashSeek(delta<0?"−10":"+10");showControls();}}
    private void playVariantNative(TreeMap<Integer,String> streams){if(streams==null||streams.isEmpty()){error("Текущая озвучка пока не открылась во встроенном просмотре");return;}if(episode!=null){episode.streams.clear();episode.streams.putAll(streams);}ArrayList<Integer> qs=new ArrayList<>(streams.keySet());if(!streams.containsKey(quality)){quality=qs.get(0);quality=QualityPlus.bestAtOrBelow(qs,YoruApp.app().store.quality());}ArrayList<String> names=new ArrayList<>();for(int q:qs)names.add(QualityPlus.streamLabel(q));setup=true;qualityRow.setVisibility(View.VISIBLE);qualitySelect.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));qualitySelect.setSelection(qs.indexOf(quality));setup=false;status.setText(nativeStatus());playNative(streams.get(quality));}
    private void playNative(String url){destroyWebForNative();resetFrameDownloads();stopMedia();currentUrl=url;nativeMode=true;audioChoices.clear();audioSignature="";audioPreferenceApplied=false;setVoiceSelectorVisible(false);updatePlayerControls();if(status!=null&&offlineId==null)status.setText(nativeStatus());video.setVisibility(View.VISIBLE);if(web!=null)web.setVisibility(View.GONE);showLoading("Запускаем плеер Tsuyu",nativeStatus());player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().clearOverridesOfType(C.TRACK_TYPE_AUDIO).setTrackTypeDisabled(C.TRACK_TYPE_AUDIO,false).setPreferredAudioLanguage("ru").setMaxVideoSize(Integer.MAX_VALUE,Integer.MAX_VALUE).setForceLowestBitrate(false).build());player.setMediaSource(new DefaultMediaSourceFactory(YoruApp.app().mediaCache.onlineFactory()).createMediaSource(DownloadHub.item(url)));player.setPlaybackSpeed(speed);player.prepare();player.play();video.requestFocus();}
    private void showWeb(String url,boolean external){
        if(rescuePlayback())return;
        String safe=ApiRepository.embed(url);
        if(safe.isEmpty())safe=ApiRepository.safeUrl(url);
        if(safe.isEmpty()){loading.setVisibility(View.GONE);error("Просмотр не передал рабочую ссылку");return;}
        playbackTasks.cancel();
        stopMedia();
        currentUrl=safe;currentVariantKey=safe;nativeMode=false;trustedKodik=external;yummyFrame=true;webActuallyPlaying=false;
        video.setVisibility(View.GONE);
        if(web==null){
            web=new WebView(this);
            web.setBackgroundColor(Color.BLACK);
            configureWeb();
            stage.addView(web,1,new FrameLayout.LayoutParams(-1,-1));
        }
        web.setVisibility(View.VISIBLE);
        loading.setVisibility(View.VISIBLE);
        showLoading("Открываем просмотр","Подготавливаем встроенное видео");
        status.setText("Открываем внешний просмотр…");
        bridgeNonce=Long.toHexString(System.nanoTime())+Long.toHexString(new SecureRandom().nextLong());
        web.removeJavascriptInterface("YoruPlayback");
        web.addJavascriptInterface(new PlaybackBridge(),"YoruPlayback");
        web.loadDataWithBaseURL(YummyFrame.BASE,YummyFrame.html(safe,bridgeNonce,Math.max(0,seekMs/1000),wantedEpisode),"text/html","UTF-8",null);
        updatePlayerControls();
    }

    private String downloadButtonTitle(){if(offlineId!=null)return "Скачана";return "Скачать";}
    private void updateDownloadButton(){if(downloadButton!=null)downloadButton.setText(downloadButtonTitle());}
    private void downloadCurrent(){if(offlineId!=null)return;if(nativeMode&&episode!=null&&!dubbing.isEmpty()&&!episode.streams.isEmpty())DownloadActions.prepareNativeCurrent(this,anime,playback,wantedEpisode,episode,dubbing,yummyVersion,currentAudioSelection());else if(nativeMode)DownloadActions.prepare(this,anime,playback,wantedEpisode);else Ui.toast(this,"Сначала запустите серию в плеере Tsuyu");}
    private ArrayList<String> frameDownloadUrls(){synchronized(capturedDownloads){return new ArrayList<>(capturedDownloads.values());}}
    private void resetFrameDownloads(){synchronized(capturedDownloads){capturedDownloads.clear();}updateDownloadButton();}
    private void captureDownloadCandidate(String raw){String safe=ApiRepository.safeUrl(raw);if(safe.isEmpty())return;if(VideoResolver.downloadable(safe))addFrameDownload(safe);}
    private void addFrameDownload(String safe){safe=ApiRepository.safeUrl(safe);if(safe.isEmpty())return;boolean first=false;synchronized(capturedDownloads){first=capturedDownloads.isEmpty();if(capturedDownloads.size()<80)capturedDownloads.put(safe,safe);}if(first)YoruApp.app().main.post(()->{if(!destroyed&&!nativeMode&&downloadButton!=null){updateDownloadButton();status.setText("Внешний просмотр · вариант для скачивания найден");}});}
    private void configureWeb(){if(web==null)return;WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setJavaScriptCanOpenWindowsAutomatically(false);s.setSupportMultipleWindows(false);s.setGeolocationEnabled(false);s.setMediaPlaybackRequiresUserGesture(false);s.setSafeBrowsingEnabled(true);s.setBuiltInZoomControls(false);s.setDisplayZoomControls(false);s.setLoadWithOverviewMode(true);s.setUseWideViewPort(true);CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);web.setDownloadListener((u,ua,cd,mime,len)->Ui.toast(this,"Загрузка из внешнего просмотра отключена"));web.setWebViewClient(new WebViewClient(){
        @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest request){String m=request.getMethod();if(m==null||m.equalsIgnoreCase("GET")||m.equalsIgnoreCase("HEAD"))captureDownloadCandidate(request.getUrl().toString());return null;}
        @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest request){String u=request.getUrl().toString();if(u.equals("about:blank"))return false;if(ApiRepository.safeUrl(u).isEmpty())return true;if(request.isForMainFrame()&&!allowedNavigation(request.getUrl()))return true;return false;}
        @Override public void onReceivedSslError(WebView v,SslErrorHandler handler,SslError error){handler.cancel();if(!PlayerActivity.this.rescuePlayback())PlayerActivity.this.error("Не удалось безопасно подключиться к просмотру");}
        @Override public void onReceivedError(WebView v,WebResourceRequest req,WebResourceError error){if(req.isForMainFrame()&&!req.getUrl().toString().equals("about:blank")&&!PlayerActivity.this.rescuePlayback())PlayerActivity.this.error("Просмотр не загрузился Попробуйте другую озвучку");}
        @Override public void onPageFinished(WebView v,String url){if(destroyed||nativeMode||url.equals("about:blank"))return;loading.setVisibility(View.GONE);if(yummyFrame)status.setText("Внешний просмотр · серия "+number(wantedEpisode));}
    });web.setWebChromeClient(new WebChromeClient(){@Override public boolean onCreateWindow(WebView v,boolean dialog,boolean user,Message msg){return false;}@Override public void onPermissionRequest(PermissionRequest request){request.deny();}@Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback cb){cb.invoke(origin,false,false);}@Override public void onShowCustomView(View view,CustomViewCallback callback){if(customView!=null){callback.onCustomViewHidden();return;}ViewGroup decor=(ViewGroup)getWindow().getDecorView();oldSystemUi=decor.getSystemUiVisibility();oldOrientation=getRequestedOrientation();customView=view;customCallback=callback;overlayRoot=new FrameLayout(PlayerActivity.this);overlayRoot.setBackgroundColor(Color.BLACK);overlayRoot.setKeepScreenOn(true);overlayRoot.addView(view,new FrameLayout.LayoutParams(-1,-1));decor.addView(overlayRoot,new FrameLayout.LayoutParams(-1,-1));attachControls(overlayRoot);getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);immersive();}@Override public void onHideCustomView(){hideCustom();}});}
    private boolean allowedNavigation(Uri target){if(target.toString().startsWith(YummyFrame.BASE))return true;String host=target.getHost();if(host==null)return false;host=host.toLowerCase(Locale.ROOT);String original=Uri.parse(currentUrl).getHost();if(host.equals(original))return true;String[] suffixes="kodikplayer.com,kodik.info,kodikres.com,stravers.live,ortified.ws,obrut.show,tazaromikaz.link,geralovod.link,factorios.live,horsez.org,ylitron.pro,yani.tv,yummyani.me,aksor.tv,aksor.yani.tv,player.aksor.tv,alloha.yani.tv,cdnvideohub.com,plapi.cdnvideohub.com,aniboom.one,sibnet.ru,video.sibnet.ru,vk.com,vkvideo.ru,video1.anilib.me,video2.anilib.me".split(",");for(String h:suffixes)if(host.equals(h)||host.endsWith("."+h))return true;return false;}
    private final class PlaybackBridge {@JavascriptInterface public void onEvent(String payload){if(payload==null||payload.length()>3000||destroyed||!yummyFrame)return;try{JSONObject j=new JSONObject(payload);final String nonce=j.optString("n");if(!bridgeNonce.equals(nonce))return;final String kind=j.optString("kind");if(kind.equals("ready")){YoruApp.app().main.post(()->{if(!destroyed&&yummyFrame&&bridgeNonce.equals(nonce)){loading.setVisibility(View.GONE);status.setText("Внешний просмотр · серия "+number(wantedEpisode));SourceEngine.record(activeSourceId(),true,0,playback==null||playback.video==null?0:playback.video.episodeList.size(),episode==null?0:episode.variants.size(),0);}});return;}if(!trustedKodik)return;if(kind.equals("state")){boolean active=j.optBoolean("playing");YoruApp.app().main.post(()->{if(destroyed||!yummyFrame||!bridgeNonce.equals(nonce))return;webActuallyPlaying=active;if(active)playing=true;save(true);});}else if(kind.equals("time")){long now=SystemClock.elapsedRealtime();if(now-lastBridge<400)return;lastBridge=now;double t=j.optDouble("time",-1),d=j.optDouble("duration",-1);if(!Double.isFinite(t)||!Double.isFinite(d)||t<0||d<1||d>100000||t>d+5)return;boolean active=j.optBoolean("playing");YoruApp.app().main.post(()->{if(destroyed||!yummyFrame||!bridgeNonce.equals(nonce))return;browserTime=(int)t;browserDuration=(int)d;webActuallyPlaying=active;if(active)playing=true;save(false);});}else if(kind.equals("episode")){double ep=j.optDouble("episode",-1);if(ep<0||ep>100000||!Double.isFinite(ep))return;YoruApp.app().main.post(()->{if(destroyed||!yummyFrame||!bridgeNonce.equals(nonce))return;if(Math.abs(ep-wantedEpisode)>.001){wantedEpisode=ep;browserTime=0;browserDuration=0;if(playback!=null&&playback.video!=null)for(int i=0;i<playback.video.episodeList.size();i++){Anime.Episode found=playback.video.episodeList.get(i);if(Double.compare(found.number,ep)==0){episode=found;setup=true;episodeSelect.setSelection(i);setup=false;break;}}}status.setText("Внешний просмотр · серия "+number(ep));});}else if(kind.equals("url")){String u=j.optString("url","");YoruApp.app().main.post(()->{if(!destroyed&&bridgeNonce.equals(nonce))captureDownloadCandidate(u);});}else if(kind.equals("ended")){YoruApp.app().main.post(()->{if(!destroyed&&bridgeNonce.equals(nonce)&&playback!=null&&playback.video!=null&&YoruApp.app().autoNextAllowed())move(1);});}}catch(Exception ignored){}}}
    private void loadOffline(String id){save(true);stopMedia();Download d=YoruApp.app().downloads().get(id);if(d==null||d.state!=Download.STATE_COMPLETED){error("Эта серия ещё не скачана полностью");return;}offlineId=id;offlineDownload=d;JSONObject m=DownloadHub.metadata(d);anime=Anime.from(m.optJSONObject("anime"));wantedEpisode=m.optDouble("episode",1);episode=new Anime.Episode();episode.number=wantedEpisode;episode.id=id;episode.name=m.optString("title","");quality=m.optInt("quality",0);dubbing=ApiRepository.voiceTitle(m.optString("voice",""));title.setText(YoruBrain.title(anime));seekMs=resumeFor(wantedEpisode);nativeMode=true;trustedKodik=false;currentUrl=d.request.uri.toString();video.setVisibility(View.VISIBLE);if(web!=null)web.setVisibility(View.GONE);selectors.setVisibility(View.GONE);epRow.setVisibility(View.VISIBLE);sourceSelect.setEnabled(false);loading.setVisibility(View.VISIBLE);player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setMaxVideoSize(Integer.MAX_VALUE,Integer.MAX_VALUE).setForceLowestBitrate(false).build());player.setMediaSource(new DefaultMediaSourceFactory(YoruApp.app().mediaCache.offlineFactory()).createMediaSource(YoruApp.app().downloads().offlineItem(d)));player.setPlaybackSpeed(speed);player.prepare();player.play();prev.setEnabled(YoruApp.app().downloads().neighbour(d,-1)!=null);next.setEnabled(YoruApp.app().downloads().neighbour(d,1)!=null);prev.setAlpha(prev.isEnabled()?1:.4f);next.setAlpha(next.isEnabled()?1:.4f);status.setText("Офлайн · серия "+number(wantedEpisode));}
    private void updateNext(){if(playback==null||playback.video==null||episode==null){renderNextEpisodes();return;}int i=playback.video.episodeList.indexOf(episode);prev.setEnabled(i>0);prev.setAlpha(i>0?1:.4f);boolean hasNext=false;for(int n=i+1;n<playback.video.episodeList.size();n++)if(!playback.video.episodeList.get(n).future){hasNext=true;break;}next.setEnabled(i>=0&&hasNext);next.setAlpha(next.isEnabled()?1:.4f);renderNextEpisodes();}
    private void renderNextEpisodes(){if(nextList==null)return;nextList.removeAllViews();if(playback==null||playback.video==null||episode==null)return;ArrayList<Anime.Episode> rows=playback.video.episodeList;int index=rows.indexOf(episode);if(index<0||index+1>=rows.size())return;LinearLayout head=Ui.row(this);head.addView(Ui.text(this,"Следующие серии",17,Ui.TEXT,true),new LinearLayout.LayoutParams(0,-2,1));TextView all=Ui.text(this,(rows.size()-index-1)+" дальше",10,Ui.PURPLE,true);head.addView(all);nextList.addView(head);Ui.space(nextList,10);for(int n=index+1;n<Math.min(rows.size(),index+5);n++){Anime.Episode e=rows.get(n);LinearLayout line=Ui.row(this);line.setGravity(Gravity.CENTER_VERTICAL);line.setPadding(Ui.dp(this,9),Ui.dp(this,8),Ui.dp(this,12),Ui.dp(this,8));line.setBackground(Ui.stroke(Ui.CARD,13,this));FrameLayout frame=new FrameLayout(this);frame.setBackground(Ui.shape(Ui.SURFACE,10,this));frame.setClipToOutline(true);ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);frame.addView(img,new FrameLayout.LayoutParams(-1,-1));String poster=ApiRepository.safeUrl(e.poster);if(poster.isEmpty()||poster.equals(anime.poster)){int idx=(int)Math.floor(e.number)-1;if(idx>=0&&!anime.screenshots.isEmpty())poster=anime.screenshots.get(idx%anime.screenshots.size());else poster="";}YoruApp.app().images.load(img,poster,anime.key()+":next:"+number(e.number));LinearLayout.LayoutParams fp=Ui.lp(this,70,42);fp.rightMargin=Ui.dp(this,10);line.addView(frame,fp);TextView text=Ui.text(this,(YoruApp.app().store.spoilerSafe()?"Серия "+number(e.number):e.label()),12,Ui.TEXT,true);text.setMaxLines(2);line.addView(text,new LinearLayout.LayoutParams(0,-2,1));Ui.Icon icon=new Ui.Icon(this,"play");icon.color=Ui.PURPLE;line.addView(icon,Ui.lp(this,22,22));final Anime.Episode target=e;line.setOnClickListener(v->{save(true);seekMs=resumeFor(target.number);loadEpisode(target);});Ui.press(line);nextList.addView(line,Ui.lp(this,-1,-2));Ui.space(nextList,7);}}
    private void move(int delta){if(offlineId!=null){Download next=YoruApp.app().downloads().neighbour(offlineDownload,delta);if(next!=null)loadOffline(next.request.id);else Ui.toast(this,"Следующая серия не скачана");return;}if(playback==null||playback.video==null||episode==null)return;int i=playback.video.episodeList.indexOf(episode)+delta;while(i>=0&&i<playback.video.episodeList.size()&&playback.video.episodeList.get(i).future)i+=delta>=0?1:-1;if(i>=0&&i<playback.video.episodeList.size()){save(true);seekMs=0;setup=true;episodeSelect.setSelection(i);setup=false;loadEpisode(playback.video.episodeList.get(i));}else if(delta>0)openNextQueued();}
    private void openNextQueued(){List<Anime> q=YoruApp.app().store.watchQueue();if(q.isEmpty())return;for(int i=0;i<q.size();i++)if(q.get(i).key().equals(anime.key())){if(i+1<q.size()){Ui.toast(this,"Открываем следующий тайтл из плана");Ui.openPlayer(this,q.get(i+1),"yoru",1);}return;}}
    private void error(String message){loading.setVisibility(View.GONE);status.setText(message);Ui.toast(this,message);}
    private void flashSeek(String text){if(seekHint==null)return;seekHint.animate().cancel();seekHint.setText(text);seekHint.setAlpha(1f);seekHint.setVisibility(View.VISIBLE);seekHint.animate().alpha(0f).setStartDelay(420).setDuration(260).withEndAction(()->{if(seekHint!=null)seekHint.setVisibility(View.GONE);}).start();}
    private void seekBy(int seconds){try{if(nativeMode&&player!=null){long d=player.getDuration(),to=Math.max(0,player.getCurrentPosition()+seconds*1000L);if(d!=C.TIME_UNSET&&d>1000)to=Math.min(d-1000,to);player.seekTo(to);player.play();flashSeek(seconds<0?"−10":"+10");}else if(web!=null&&trustedKodik)web.evaluateJavascript("if(window.__yoruSeek)window.__yoruSeek("+seconds+");",null);}catch(Exception ignored){}}
    private void smartExpand(){boolean active=fullPlayer&&fillVideo;if(!fullPlayer&&customView==null)fullScreen();fillVideo=!active;if(video!=null)video.setResizeMode(fillVideo?androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM:androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT);updatePlayerControls();Ui.toast(this,fillVideo?"Умное заполнение экрана":"Полный кадр без обрезки");}
    private void toggleResize(){fillVideo=!fillVideo;if(video!=null)video.setResizeMode(fillVideo?androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM:androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT);Ui.toast(this,fillVideo?"Видео заполняет экран":"Видео показывает полный кадр");}
    private void immersive(){View decor=getWindow().getDecorView();if(Build.VERSION.SDK_INT>=30){getWindow().setDecorFitsSystemWindows(false);WindowInsetsController c=getWindow().getInsetsController();if(c!=null){c.hide(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}}decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}
    private void restoreBars(View decor){if(Build.VERSION.SDK_INT>=30){getWindow().setDecorFitsSystemWindows(true);WindowInsetsController c=getWindow().getInsetsController();if(c!=null)c.show(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());}decor.setSystemUiVisibility(oldSystemUi);}
    private void enterPip(){enterPip(false);}
    private void enterPip(boolean quiet){if(Build.VERSION.SDK_INT<26||destroyed)return;if(!getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)){if(!quiet)Ui.toast(this,"PiP не поддерживается устройством");return;}try{if(customView==null&&!fullPlayer)fullScreen();enteringPip=enterPictureInPictureMode(pipParams());}catch(Exception e){if(!quiet)Ui.toast(this,"Не удалось открыть PiP");}}
    private PictureInPictureParams pipParams(){PictureInPictureParams.Builder b=new PictureInPictureParams.Builder().setAspectRatio(new Rational(16,9));ArrayList<RemoteAction> actions=new ArrayList<>();actions.add(pipRemote(ACTION_BACK,R.drawable.ic_pip_rewind,"−10"));actions.add(pipRemote(ACTION_TOGGLE,isPlayingNow()?R.drawable.ic_pip_pause:R.drawable.ic_pip_play,isPlayingNow()?"Пауза":"Продолжить"));actions.add(pipRemote(ACTION_FORWARD,R.drawable.ic_pip_forward,"+10"));b.setActions(actions);if(Build.VERSION.SDK_INT>=31)b.setAutoEnterEnabled(true);return b.build();}
    private RemoteAction pipRemote(String action,int icon,String title){Intent intent=new Intent(this,PlayerActionReceiver.class).setAction(action).setPackage(getPackageName());PendingIntent pi=PendingIntent.getBroadcast(this,action.hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);return new RemoteAction(android.graphics.drawable.Icon.createWithResource(this,icon),title,title,pi);}
    private void updatePipActions(){if(Build.VERSION.SDK_INT>=26&&isInPictureInPictureMode())try{setPictureInPictureParams(pipParams());}catch(Exception ignored){}}
    public static void pipAction(String action){PlayerActivity a=active;if(a==null||action==null)return;a.runOnUiThread(()->{if(ACTION_TOGGLE.equals(action))a.togglePlay();else if(ACTION_BACK.equals(action))a.seekBy(-10);else if(ACTION_FORWARD.equals(action))a.seekBy(10);a.updatePipActions();});}
    private void save(boolean force){if(!playing||anime==null)return;long now=System.currentTimeMillis();if(!force&&now-lastSaved<3500)return;lastSaved=now;boolean saved=false;if(nativeMode&&video!=null){YoruApp.app().store.progress(anime,wantedEpisode,(int)(player.getCurrentPosition()/1000),player.getDuration()==C.TIME_UNSET?0:(int)Math.max(0,player.getDuration()/1000),offlineId==null?"auto":"offline",dubbing,true);saved=true;}else if(trustedKodik){YoruApp.app().store.progress(anime,wantedEpisode,browserTime,browserDuration,playback!=null&&playback.directKodik?"kodik":mode,dubbing,true);saved=true;}if(saved)YoruWidgetProvider.refresh(this);}
    private void stopMedia(){playing=false;trustedKodik=false;yummyFrame=false;webActuallyPlaying=false;bridgeNonce="";if(video!=null){try{player.stop();player.clearMediaItems();}catch(Exception ignored){}}if(web!=null){web.removeJavascriptInterface("YoruPlayback");web.stopLoading();web.loadUrl("about:blank");}getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}
    private void fullScreen(){if(customView!=null){hideCustom();return;}if(fullPlayer){hideFullPlayer();return;}View target=nativeMode?video:web;if(target==null)return;fullView=target;fullParent=(ViewGroup)target.getParent();if(fullParent==null)return;ViewGroup decor=(ViewGroup)getWindow().getDecorView();oldSystemUi=decor.getSystemUiVisibility();oldOrientation=getRequestedOrientation();fullIndex=fullParent.indexOfChild(target);fullParams=target.getLayoutParams();fullParent.removeView(target);overlayRoot=new FrameLayout(this);overlayRoot.setBackgroundColor(Color.BLACK);overlayRoot.setKeepScreenOn(true);overlayRoot.setFocusable(true);overlayRoot.setFocusableInTouchMode(true);overlayRoot.addView(target,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));decor.addView(overlayRoot,new FrameLayout.LayoutParams(-1,-1));attachControls(overlayRoot);fullPlayer=true;getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);immersive();if(nativeMode&&video!=null)video.setUseController(false);overlayRoot.requestFocus();}
    private void hideFullPlayer(){if(!fullPlayer)return;ViewGroup decor=(ViewGroup)getWindow().getDecorView();try{if(overlayRoot!=null&&fullView!=null){overlayRoot.removeView(fullView);decor.removeView(overlayRoot);if(fullParent!=null){if(fullIndex>=0&&fullIndex<=fullParent.getChildCount())fullParent.addView(fullView,fullIndex,fullParams);else fullParent.addView(fullView,fullParams);}}}catch(Exception ignored){}attachControls(stage);restoreBars(decor);getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);setRequestedOrientation(oldOrientation);overlayRoot=null;fullView=null;fullParent=null;fullParams=null;fullPlayer=false;updatePlayerControls();}
    private void hideCustom(){if(customView==null)return;View decor=getWindow().getDecorView();try{if(overlayRoot!=null)((ViewGroup)decor).removeView(overlayRoot);}catch(Exception ignored){}customView=null;attachControls(stage);if(customCallback!=null)customCallback.onCustomViewHidden();customCallback=null;restoreBars(decor);getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);setRequestedOrientation(oldOrientation);overlayRoot=null;}
    private String activeSourceId(){String id=playback!=null&&!playback.provider.isEmpty()?playback.provider:mode;if(id==null||id.isEmpty()||"auto".equals(id)||"all".equals(id)||"offline".equals(id))id="yoru";return SourceEngine.sourceId(id);}
    private static String number(double n){return n==Math.floor(n)?String.valueOf((int)n):String.valueOf(n);}
    @Override public void onConfigurationChanged(android.content.res.Configuration c){super.onConfigurationChanged(c);if(stage!=null&&stage.getLayoutParams()!=null){boolean landscape=c.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE;stage.getLayoutParams().height=Ui.dp(this,landscape?Math.max(200,c.screenHeightDp-85):Math.max(200,(c.screenWidthDp-24)*9/16));stage.requestLayout();}if(fullPlayer||customView!=null)immersive();}
    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus&&(fullPlayer||customView!=null))immersive();}
    @Override protected void onUserLeaveHint(){super.onUserLeaveHint();if(Build.VERSION.SDK_INT>=26&&((nativeMode&&player!=null&&player.isPlaying())||webActuallyPlaying))enterPip(true);}
    @Override public void onPictureInPictureModeChanged(boolean inMode,android.content.res.Configuration config){super.onPictureInPictureModeChanged(inMode,config);enteringPip=inMode;if(playerControls!=null)playerControls.setVisibility(inMode?View.GONE:View.VISIBLE);if(!inMode)showControls();}
    @Override protected void onPause(){super.onPause();YoruApp.app().store.playbackSpeed(speed);save(true);if(!fullPlayer)getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(enteringPip||isInPictureInPictureMode())return;if(nativeMode){if(player!=null){pausedByLife=player.isPlaying();player.pause();}}else if(web!=null){webPausedByLife=webActuallyPlaying;web.evaluateJavascript("if(window.__yoruPause)window.__yoruPause();",null);web.onPause();} }
    @Override protected void onResume(){super.onResume();if(video!=null&&pausedByLife&&nativeMode){player.play();pausedByLife=false;}if(web!=null){web.onResume();if(webPausedByLife&&yummyFrame){web.evaluateJavascript("if(window.__yoruPlay)window.__yoruPlay();",null);webPausedByLife=false;}}}
    @Override public void onBackPressed(){if(customView!=null){hideCustom();return;}if(fullPlayer){hideFullPlayer();return;}super.onBackPressed();}
    @Override protected void onDestroy(){save(true);destroyed=true;generation++;playbackTasks.cancel();timer.removeCallbacksAndMessages(null);if(fullPlayer)hideFullPlayer();stopMedia();if(web!=null){try{android.view.ViewParent p=web.getParent();if(p instanceof android.view.ViewGroup)((android.view.ViewGroup)p).removeView(web);}catch(Exception ignored){}web.destroy();}if(player!=null)player.release();if(active==this)active=null;if(registeredPlayer){YoruApp.app().activePlayers--;YoruApp.app().traffic.removeListener(networkPolicy);}super.onDestroy();}
}
